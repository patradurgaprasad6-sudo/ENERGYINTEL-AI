import React from "react";
import {
  Flame,
  Clock,
  Zap,
  TrendingDown,
  ShieldAlert,
  ArrowRight,
  Sun,
  Users,
  Fan,
  Coins,
  CheckCircle2
} from "lucide-react";
import {
  ResponsiveContainer,
  AreaChart,
  Area,
  ReferenceLine,
  XAxis,
  YAxis,
  Tooltip,
  CartesianGrid
} from "recharts";
import { useEnergy } from "../context/EnergyContext";

export function PeakDemandPage() {
  const { hourlyData, tariffINR } = useEnergy();

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 p-5 rounded-2xl bg-gradient-to-r from-amber-950/50 via-slate-900 to-rose-950/40 border border-amber-500/30">
        <div>
          <div className="flex items-center gap-2">
            <span className="px-2.5 py-0.5 rounded-full bg-amber-950 border border-amber-700 text-amber-300 font-mono text-[10px] font-bold uppercase tracking-wider">
              MAXIMUM DEMAND SHAVING
            </span>
            <span className="text-xs text-amber-300">
              Utility Peak Surcharge Avoidance
            </span>
          </div>
          <h1 className="text-2xl font-black text-white mt-1">
            Peak Demand Prediction & Load Shifting
          </h1>
          <p className="text-xs text-slate-300 mt-0.5">
            Predicting coincident electrical peaks to prevent utility contracted maximum demand (MD) penalty penalties.
          </p>
        </div>

        {/* Peak Prediction Highlight Box */}
        <div className="p-4 rounded-xl bg-slate-900/90 border border-amber-500/40 text-right min-w-[210px]">
          <span className="text-[10px] text-slate-400 font-mono uppercase">Expected Peak Window</span>
          <div className="text-xl font-black text-amber-400 font-mono mt-0.5">
            13:00 – 15:00
          </div>
          <span className="text-xs text-rose-400 font-mono font-bold">
            Projected Peak: 118.0 kW
          </span>
        </div>
      </div>

      {/* 3 Core Highlight Cards (Requirement 33) */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        {/* Card 1: Expected Peak Time */}
        <div className="p-5 rounded-2xl bg-[#0b1329] border border-amber-500/40 space-y-2">
          <div className="flex items-center justify-between">
            <span className="text-xs font-mono font-bold text-slate-400 uppercase">
              EXPECTED PEAK TIME
            </span>
            <Clock className="w-5 h-5 text-amber-400" />
          </div>
          <div className="text-3xl font-black text-white font-mono">
            13:00 – 15:00
          </div>
          <p className="text-xs text-slate-400">
            Coincident window where external solar radiation and lecture hall density overlap.
          </p>
        </div>

        {/* Card 2: Expected Peak Load */}
        <div className="p-5 rounded-2xl bg-[#0b1329] border border-rose-500/40 space-y-2">
          <div className="flex items-center justify-between">
            <span className="text-xs font-mono font-bold text-slate-400 uppercase">
              EXPECTED PEAK LOAD
            </span>
            <Flame className="w-5 h-5 text-rose-400" />
          </div>
          <div className="text-3xl font-black text-rose-400 font-mono">
            118 kW
          </div>
          <p className="text-xs text-slate-400">
            Baseline Contracted Sanctioned Demand: 100 kW. Exceeding risks high penalty surcharge.
          </p>
        </div>

        {/* Card 3: Root Cause Factors */}
        <div className="p-5 rounded-2xl bg-[#0b1329] border border-slate-800 space-y-2">
          <span className="text-xs font-mono font-bold text-slate-400 uppercase">
            CONTRIBUTING FACTORS
          </span>
          <ul className="text-xs text-slate-300 space-y-1.5 pt-1">
            <li className="flex items-center gap-2">
              <Sun className="w-3.5 h-3.5 text-amber-400" />
              <span>High ambient thermal heat (37°C peak)</span>
            </li>
            <li className="flex items-center gap-2">
              <Users className="w-3.5 h-3.5 text-cyan-400" />
              <span>Afternoon lab session overlap (92% occupancy)</span>
            </li>
            <li className="flex items-center gap-2">
              <Fan className="w-3.5 h-3.5 text-blue-400" />
              <span>All 4 Block chiller compressors cycling at 100%</span>
            </li>
          </ul>
        </div>
      </div>

      {/* Peak Demand Profile Chart with Sanctioned Limit */}
      <div className="bg-[#0b1329] border border-slate-800 rounded-2xl p-5 shadow-xl space-y-4">
        <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-2 border-b border-slate-800 pb-3">
          <div>
            <h2 className="text-base font-bold text-white flex items-center gap-2">
              <Flame className="w-4 h-4 text-amber-400" />
              <span>Diurnal Load Profile & Peak Threshold Shaving</span>
            </h2>
            <p className="text-xs text-slate-400">
              Contracted demand ceiling at 100 kW. Red dashed zone indicates critical peak surcharge exposure.
            </p>
          </div>
          <span className="text-[11px] font-mono px-2.5 py-1 rounded bg-rose-950 text-rose-300 border border-rose-800 font-bold">
            Sanctioned Cap: 100 kW
          </span>
        </div>

        <div className="h-72 w-full">
          <ResponsiveContainer width="100%" height="100%">
            <AreaChart data={hourlyData} margin={{ top: 10, right: 10, left: -20, bottom: 0 }}>
              <defs>
                <linearGradient id="peakGradient" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="5%" stopColor="#f59e0b" stopOpacity={0.4} />
                  <stop offset="95%" stopColor="#f59e0b" stopOpacity={0.0} />
                </linearGradient>
              </defs>
              <CartesianGrid strokeDasharray="3 3" stroke="#1e293b" opacity={0.6} />
              <XAxis dataKey="hour" stroke="#64748b" tick={{ fontSize: 11 }} />
              <YAxis stroke="#64748b" tick={{ fontSize: 11 }} />
              <Tooltip
                contentStyle={{
                  backgroundColor: "#070b14",
                  borderColor: "#334155",
                  borderRadius: "0.75rem",
                  fontSize: "12px",
                  color: "#f8fafc"
                }}
                formatter={(val) => [`${val} kW`, "Campus Load"]}
              />
              <ReferenceLine y={100} stroke="#f43f5e" strokeDasharray="4 4" label={{ value: "Contracted Cap (100 kW)", fill: "#f43f5e", fontSize: 11 }} />
              <Area
                type="monotone"
                dataKey="actual"
                stroke="#f59e0b"
                strokeWidth={2.5}
                fillOpacity={1}
                fill="url(#peakGradient)"
              />
            </AreaChart>
          </ResponsiveContainer>
        </div>
      </div>

      {/* AI Peak Shaving Strategies (Requirement 33) */}
      <div className="space-y-3">
        <h2 className="text-base font-bold text-white flex items-center gap-2">
          <CheckCircle2 className="w-4 h-4 text-emerald-400" />
          <span>AI Peak Shaving Recommendations</span>
        </h2>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <div className="p-4 rounded-xl bg-slate-900 border border-slate-800 space-y-2">
            <span className="text-xs font-mono font-bold text-cyan-400 uppercase">
              1. THERMAL PRE-COOLING (11:30 - 12:30)
            </span>
            <p className="text-xs text-slate-300">
              Pre-chill Block A and Block B classrooms to 21°C prior to the 13:00 peak, then float thermostat setpoints to 24.5°C during peak utility tariff hours.
            </p>
            <div className="text-[11px] font-mono text-emerald-400 font-semibold pt-1">
              Estimated Peak Reduction: -16.4 kW
            </div>
          </div>

          <div className="p-4 rounded-xl bg-slate-900 border border-slate-800 space-y-2">
            <span className="text-xs font-mono font-bold text-purple-400 uppercase">
              2. LAB EQUIPMENT STAGGERING
            </span>
            <p className="text-xs text-slate-300">
              Shift heavy 3D printing and oven baking schedules in Block B Engineering Labs to either morning (10:00) or evening (16:30) batches.
            </p>
            <div className="text-[11px] font-mono text-emerald-400 font-semibold pt-1">
              Estimated Peak Reduction: -8.5 kW
            </div>
          </div>

          <div className="p-4 rounded-xl bg-slate-900 border border-slate-800 space-y-2">
            <span className="text-xs font-mono font-bold text-amber-400 uppercase">
              3. SMART WATER PUMP ISOLATION
            </span>
            <p className="text-xs text-slate-300">
              Interlock campus hydro-pneumatic pumping stations to suspend overhead reservoir refills strictly between 13:00–15:00.
            </p>
            <div className="text-[11px] font-mono text-emerald-400 font-semibold pt-1">
              Estimated Peak Reduction: -7.2 kW
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
