import React, { useState, useMemo } from "react";
import {
  Lightbulb,
  Sparkles,
  ArrowUpDown,
  CheckCircle2,
  AlertTriangle,
  Coins,
  Zap,
  Leaf,
  Filter,
  CheckCheck,
  Building,
  RotateCcw
} from "lucide-react";
import { useEnergy } from "../context/EnergyContext";

export function RecommendationsPage() {
  const {
    recommendations,
    appliedRecommendations,
    applyRecommendation,
    tariffINR,
    potentialSavingsINR
  } = useEnergy();

  const [sortBy, setSortBy] = useState("energy"); // "energy" | "cost" | "priority" | "ease"
  const [filterCategory, setFilterCategory] = useState("all");

  // Sorted and filtered recommendations
  const sortedRecommendations = useMemo(() => {
    let list = [...recommendations];

    if (filterCategory !== "all") {
      list = list.filter(r => r.category === filterCategory);
    }

    list.sort((a, b) => {
      if (sortBy === "energy") {
        return b.energySavingKWh - a.energySavingKWh;
      }
      if (sortBy === "cost") {
        return b.costSavingINR - a.costSavingINR;
      }
      if (sortBy === "priority") {
        const order = { CRITICAL: 4, HIGH: 3, MEDIUM: 2, LOW: 1 };
        return order[b.priority] - order[a.priority];
      }
      return 0;
    });

    return list;
  }, [recommendations, sortBy, filterCategory]);

  const categories = ["all", "HVAC Optimization", "Lighting Schedule", "Peak Demand", "Plug Load Management", "BMS Automation"];

  const priorityStyles = {
    CRITICAL: "bg-rose-500/20 text-rose-300 border-rose-500/50",
    HIGH: "bg-amber-500/20 text-amber-300 border-amber-500/50",
    MEDIUM: "bg-blue-500/20 text-blue-300 border-blue-500/50",
    LOW: "bg-slate-800 text-slate-300 border-slate-700"
  };

  const totalPossibleDailyKWh = recommendations.reduce((acc, r) => acc + r.energySavingKWh, 0);
  const totalPossibleDailyINR = Math.round(totalPossibleDailyKWh * tariffINR);

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 p-5 rounded-2xl bg-gradient-to-r from-yellow-950/40 via-slate-900 to-amber-950/40 border border-yellow-500/30">
        <div>
          <div className="flex items-center gap-2">
            <span className="px-2.5 py-0.5 rounded-full bg-yellow-950 border border-yellow-700 text-yellow-300 font-mono text-[10px] font-bold uppercase tracking-wider">
              AI PRESCRIPTIVE ENGINE
            </span>
            <span className="text-xs text-yellow-300">
              Sorted by Maximized Conservation ROI
            </span>
          </div>
          <h1 className="text-2xl font-black text-white mt-1">
            Prioritized AI Optimization Actions
          </h1>
          <p className="text-xs text-slate-300 mt-0.5">
            Every recommendation explains the root cause problem, underlying reason, and concrete action for facility leadership.
          </p>
        </div>

        {/* Aggregate Potential Savings Box */}
        <div className="p-4 rounded-xl bg-slate-900/90 border border-yellow-500/40 text-right min-w-[210px]">
          <span className="text-[10px] text-slate-400 font-mono uppercase">Full Portfolio Potential</span>
          <div className="text-2xl font-black text-emerald-400 font-mono mt-0.5">
            +{totalPossibleDailyKWh.toFixed(1)} kWh/day
          </div>
          <span className="text-xs text-cyan-400 font-mono font-bold">
            ₹{totalPossibleDailyINR.toLocaleString()} / day saved
          </span>
        </div>
      </div>

      {/* Sorting & Filter Controls (Requirement 28) */}
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 p-3 rounded-xl bg-[#0b1329] border border-slate-800">
        <div className="flex items-center gap-2 flex-wrap">
          <span className="text-xs font-mono text-slate-400 flex items-center gap-1">
            <Filter className="w-3.5 h-3.5" /> Filter:
          </span>
          {categories.map((cat) => (
            <button
              key={cat}
              onClick={() => setFilterCategory(cat)}
              className={`px-2.5 py-1 rounded-lg text-xs font-medium transition cursor-pointer ${
                filterCategory === cat
                  ? "bg-yellow-500/20 text-yellow-300 border border-yellow-500/50"
                  : "bg-slate-900 text-slate-400 hover:text-white"
              }`}
            >
              {cat === "all" ? "All Categories" : cat}
            </button>
          ))}
        </div>

        <div className="flex items-center gap-2">
          <span className="text-xs font-mono text-slate-400 flex items-center gap-1">
            <ArrowUpDown className="w-3.5 h-3.5" /> Sort by:
          </span>
          <select
            value={sortBy}
            onChange={(e) => setSortBy(e.target.value)}
            className="bg-slate-950 text-slate-200 border border-slate-700 rounded-lg px-2.5 py-1 text-xs font-medium focus:outline-none focus:border-cyan-400"
          >
            <option value="energy">⚡ Energy Saving (kWh)</option>
            <option value="cost">💰 Cost Saving (₹)</option>
            <option value="priority">🚨 Severity / Priority</option>
          </select>
        </div>
      </div>

      {/* Recommendations Cards Grid (Requirement 27) */}
      <div className="space-y-4">
        {sortedRecommendations.map((rec, index) => {
          const isApplied = appliedRecommendations.has(rec.id);
          return (
            <div
              key={rec.id}
              className={`p-6 rounded-2xl bg-[#0b1329] border transition-all space-y-4 ${
                isApplied
                  ? "border-emerald-500/50 bg-emerald-950/10"
                  : index === 0
                  ? "border-yellow-500/60 shadow-xl shadow-yellow-500/10"
                  : "border-slate-800 hover:border-slate-700"
              }`}
            >
              <div className="flex flex-col md:flex-row items-start md:items-center justify-between gap-3">
                <div className="space-y-1">
                  <div className="flex items-center gap-2 flex-wrap">
                    <span className="text-xs font-mono font-bold text-slate-500">#{index + 1}</span>
                    <span className={`text-[10px] font-mono px-2 py-0.5 rounded border font-bold uppercase ${priorityStyles[rec.priority]}`}>
                      {rec.priority} PRIORITY
                    </span>
                    <span className="text-xs font-mono px-2 py-0.5 rounded bg-slate-900 text-cyan-300 border border-slate-800">
                      {rec.category}
                    </span>
                    <span className="text-xs text-slate-400 font-mono">
                      📍 {rec.building} — {rec.floor}
                    </span>
                  </div>
                  <h3 className="text-lg font-bold text-white mt-1">
                    {rec.title}
                  </h3>
                </div>

                {/* Savings Metrics Badges */}
                <div className="flex items-center gap-3">
                  <div className="p-2.5 rounded-xl bg-slate-950 border border-slate-800 text-right">
                    <span className="text-[10px] text-slate-400 font-mono uppercase">Energy Savings</span>
                    <div className="text-base font-black text-emerald-400 font-mono">
                      +{rec.energySavingKWh} kWh/day
                    </div>
                  </div>
                  <div className="p-2.5 rounded-xl bg-slate-950 border border-slate-800 text-right">
                    <span className="text-[10px] text-slate-400 font-mono uppercase">Cost Savings</span>
                    <div className="text-base font-black text-cyan-400 font-mono">
                      ₹{rec.costSavingINR}/day
                    </div>
                  </div>
                </div>
              </div>

              {/* Problem / Reason / Action 3-Column Box (Requirement 27) */}
              <div className="grid grid-cols-1 md:grid-cols-3 gap-3 pt-2">
                <div className="p-3.5 rounded-xl bg-slate-950/70 border border-slate-800/80 space-y-1">
                  <span className="text-xs font-mono font-bold text-rose-400 uppercase">
                    1. PROBLEM (What is happening?)
                  </span>
                  <p className="text-xs text-slate-300 leading-relaxed">
                    {rec.problem}
                  </p>
                </div>

                <div className="p-3.5 rounded-xl bg-slate-950/70 border border-slate-800/80 space-y-1">
                  <span className="text-xs font-mono font-bold text-amber-400 uppercase">
                    2. REASON (Why is it happening?)
                  </span>
                  <p className="text-xs text-slate-300 leading-relaxed">
                    {rec.reason}
                  </p>
                </div>

                <div className="p-3.5 rounded-xl bg-slate-950/70 border border-emerald-900/60 space-y-1">
                  <span className="text-xs font-mono font-bold text-emerald-400 uppercase">
                    3. ACTION (Facility Manager Execution)
                  </span>
                  <p className="text-xs text-slate-200 leading-relaxed">
                    {rec.action}
                  </p>
                </div>
              </div>

              {/* Footer Execution Action Strip */}
              <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 pt-2 border-t border-slate-800 text-xs">
                <div className="flex items-center gap-4 text-slate-400">
                  <span>
                    Implementation: <strong className="text-slate-200">{rec.easeOfImplementation}</strong>
                  </span>
                  <span>•</span>
                  <span>
                    Carbon Offset: <strong className="text-emerald-400 font-mono">+{rec.co2SavingKg} kg CO₂/day</strong>
                  </span>
                </div>

                <button
                  onClick={() => applyRecommendation(rec.id)}
                  disabled={isApplied}
                  className={`px-4 py-2 rounded-xl text-xs font-bold uppercase tracking-wider flex items-center gap-2 cursor-pointer transition ${
                    isApplied
                      ? "bg-emerald-500/20 text-emerald-300 border border-emerald-500/50 cursor-default"
                      : "bg-cyan-500 hover:bg-cyan-400 text-black shadow-md shadow-cyan-500/20 hover:scale-105"
                  }`}
                >
                  {isApplied ? (
                    <>
                      <CheckCheck className="w-4 h-4 text-emerald-400" />
                      <span>Action Implemented & Verified</span>
                    </>
                  ) : (
                    <>
                      <CheckCircle2 className="w-4 h-4 text-black" />
                      <span>Implement Recommendation</span>
                    </>
                  )}
                </button>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
}
