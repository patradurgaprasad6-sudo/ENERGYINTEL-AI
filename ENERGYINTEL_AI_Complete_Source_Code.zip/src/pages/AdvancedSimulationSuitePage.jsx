import React, { useState } from "react";
import {
  Sliders,
  Flame,
  AlertOctagon,
  Sparkles,
  ExternalLink,
  Play,
  RotateCcw,
  Zap,
  Thermometer,
  Users,
  Activity,
  CheckCircle2,
  Clock,
  Radio,
  ShieldAlert
} from "lucide-react";
import { useEnergy } from "../context/EnergyContext";
import { ANOMALY_CASES } from "../services/aiAnomalyService";

export function AdvancedSimulationSuitePage({ isStandalone = false }) {
  const {
    currentPowerKW,
    todayEnergyKWh,
    occupancyMultiplier,
    triggerIncreaseOccupancy,
    tempOffset,
    triggerIncreaseTemperature,
    isPeakLoadActive,
    triggerPeakLoad,
    activeAnomaly,
    triggerAnomaly,
    activeWastageScenario,
    triggerWastageScenario,
    resetSimulation
  } = useEnergy();

  const [simulationLog, setSimulationLog] = useState([
    { id: 1, time: "09:20:14", event: "Simulation Engine Initialized", level: "INFO", latency: "1.2 ms" },
    { id: 2, time: "09:22:45", event: "Trident Campus Baseline Telemetry Stream Synchronized", level: "INFO", latency: "2.8 ms" },
    { id: 3, time: "09:25:10", event: "Multivariate Regression Model Active (Degree-Day Coefficient 0.042)", level: "INFO", latency: "3.1 ms" }
  ]);

  const [activePreset, setActivePreset] = useState("normal");

  const openInNewTab = () => {
    window.open(`${window.location.origin}/?view=simulations`, "_blank");
  };

  const logEvent = (eventName, level = "EVENT", latency = "4.2 ms") => {
    const time = new Date().toTimeString().split(" ")[0];
    setSimulationLog(prev => [
      { id: Date.now(), time, event: eventName, level, latency },
      ...prev.slice(0, 24)
    ]);
  };

  const runScenarioPreset = (presetKey) => {
    setActivePreset(presetKey);

    if (presetKey === "heatwave") {
      logEvent("Extreme Heatwave (42°C Ambient) Applied: HVAC COP degraded by 24%", "WARN", "3.4 ms");
      triggerIncreaseTemperature();
    } else if (presetKey === "exam_peak") {
      logEvent("Exam Week Full Capacity (100% Occupancy) Engaged: All lighting & PC circuits active", "WARN", "2.9 ms");
      triggerIncreaseOccupancy();
    } else if (presetKey === "compressor_lock") {
      logEvent("FAULT INJECTED: Chiller B2 Compressor Rotor Lock (+56% Spike to 128 kW)", "CRITICAL", "1.8 ms");
      triggerAnomaly();
    } else if (presetKey === "ghost_load") {
      logEvent("Weekend Ghost Load Injected: Auditorium AHU cycling during Sunday closure", "WARN", "4.1 ms");
      triggerWastageScenario(ANOMALY_CASES.WEEKEND_ANOMALY);
    } else if (presetKey === "peak_shaving") {
      logEvent("AI Peak Shaving Engaged: Pre-cooling classrooms by 1.5°C before utility peak", "SUCCESS", "2.1 ms");
      triggerPeakLoad();
    } else {
      resetSimulation();
      logEvent("Simulation parameters restored to baseline campus operations", "INFO", "1.1 ms");
    }
  };

  return (
    <div className={`space-y-6 ${isStandalone ? 'p-6 max-w-7xl mx-auto' : ''}`}>
      {/* Header */}
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 p-5 rounded-2xl bg-gradient-to-r from-purple-950/60 via-slate-900 to-indigo-950/50 border border-purple-500/40 shadow-xl">
        <div>
          <div className="flex items-center gap-2">
            <span className="px-2.5 py-0.5 rounded-full bg-purple-950 border border-purple-700 text-purple-300 font-mono text-[10px] font-bold uppercase tracking-wider flex items-center gap-1.5">
              <Sliders className="w-3.5 h-3.5 text-purple-400" />
              ADVANCED STRESS-TEST BENCH
            </span>
            <span className="text-[11px] font-mono text-cyan-400 font-semibold">
              FAULT INJECTION & SCENARIO ENGINE
            </span>
          </div>
          <h1 className="text-2xl font-black text-white mt-1">
            Campus Simulation & Stress Testing Laboratory
          </h1>
          <p className="text-xs text-slate-300 mt-0.5">
            Subject the campus energy grid to synthetic micro-bursts, climate shocks, equipment failure, and automated peak-shaving responses.
          </p>
        </div>

        <div className="flex items-center gap-2">
          {!isStandalone && (
            <button
              onClick={openInNewTab}
              className="px-3.5 py-2 rounded-xl bg-purple-500/20 hover:bg-purple-500/30 text-purple-300 border border-purple-500/50 text-xs font-bold flex items-center gap-1.5 cursor-pointer transition shadow-md shadow-purple-500/20"
              title="Open Simulation Suite in a dedicated separate browser tab"
            >
              <ExternalLink className="w-3.5 h-3.5" />
              <span>Open in New Browser Tab ↗</span>
            </button>
          )}

          <button
            onClick={() => runScenarioPreset("normal")}
            className="px-3.5 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-semibold flex items-center gap-1.5 cursor-pointer"
          >
            <RotateCcw className="w-3.5 h-3.5" />
            <span>Reset Scenario Baseline</span>
          </button>
        </div>
      </div>

      {/* 5 Scenario Presets Grid */}
      <div className="space-y-3">
        <h2 className="text-sm font-bold text-white uppercase font-mono flex items-center gap-2">
          <Sparkles className="w-4 h-4 text-cyan-400" />
          <span>Macro Stress-Test Scenarios (Click to Inject into Live Campus)</span>
        </h2>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {/* Preset 1 */}
          <div
            onClick={() => runScenarioPreset("heatwave")}
            className="p-5 rounded-2xl bg-[#0b1329] border border-orange-500/40 hover:border-orange-400 transition cursor-pointer space-y-2 group shadow-lg"
          >
            <div className="flex justify-between items-center">
              <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-orange-950 text-orange-300 border border-orange-800 font-bold uppercase">
                CLIMATE SHOCK
              </span>
              <Thermometer className="w-5 h-5 text-orange-400 group-hover:scale-110 transition" />
            </div>
            <h3 className="text-base font-bold text-white">1. Extreme Heatwave (42°C Ambient)</h3>
            <p className="text-xs text-slate-400 leading-relaxed">
              Elevates ambient heat index, increasing building envelope thermal gain and reducing chiller refrigeration COP by 24%.
            </p>
          </div>

          {/* Preset 2 */}
          <div
            onClick={() => runScenarioPreset("exam_peak")}
            className="p-5 rounded-2xl bg-[#0b1329] border border-cyan-500/40 hover:border-cyan-400 transition cursor-pointer space-y-2 group shadow-lg"
          >
            <div className="flex justify-between items-center">
              <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-cyan-950 text-cyan-300 border border-cyan-800 font-bold uppercase">
                OCCUPANCY SURGE
              </span>
              <Users className="w-5 h-5 text-cyan-400 group-hover:scale-110 transition" />
            </div>
            <h3 className="text-base font-bold text-white">2. Exam Week Peak (100% Capacity)</h3>
            <p className="text-xs text-slate-400 leading-relaxed">
              Fills all 12 floors across 4 blocks with 3,570 active students, maxing out classroom lighting, lecture hall projection, and device plug loads.
            </p>
          </div>

          {/* Preset 3 */}
          <div
            onClick={() => runScenarioPreset("compressor_lock")}
            className="p-5 rounded-2xl bg-[#0b1329] border border-rose-500/50 hover:border-rose-400 transition cursor-pointer space-y-2 group shadow-lg"
          >
            <div className="flex justify-between items-center">
              <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-rose-950 text-rose-300 border border-rose-800 font-bold uppercase">
                ELECTRICAL ANOMALY
              </span>
              <AlertOctagon className="w-5 h-5 text-rose-400 group-hover:scale-110 transition" />
            </div>
            <h3 className="text-base font-bold text-white">3. Chiller Compressor Locked Rotor</h3>
            <p className="text-xs text-slate-400 leading-relaxed">
              Simulates a mechanical compressor seizure in Block B Floor 2 causing an instantaneous +56% surge to 128.4 kW.
            </p>
          </div>

          {/* Preset 4 */}
          <div
            onClick={() => runScenarioPreset("ghost_load")}
            className="p-5 rounded-2xl bg-[#0b1329] border border-purple-500/40 hover:border-purple-400 transition cursor-pointer space-y-2 group shadow-lg"
          >
            <div className="flex justify-between items-center">
              <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-purple-950 text-purple-300 border border-purple-800 font-bold uppercase">
                AFTER-HOURS WASTE
              </span>
              <Activity className="w-5 h-5 text-purple-400 group-hover:scale-110 transition" />
            </div>
            <h3 className="text-base font-bold text-white">4. Weekend Auditorium Ghost Load</h3>
            <p className="text-xs text-slate-400 leading-relaxed">
              Maintains 600-seater Block C auditorium chillers cycling on Sunday when the campus facility is officially locked and empty.
            </p>
          </div>

          {/* Preset 5 */}
          <div
            onClick={() => runScenarioPreset("peak_shaving")}
            className="p-5 rounded-2xl bg-[#0b1329] border border-emerald-500/40 hover:border-emerald-400 transition cursor-pointer space-y-2 group shadow-lg"
          >
            <div className="flex justify-between items-center">
              <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-emerald-950 text-emerald-300 border border-emerald-800 font-bold uppercase">
                PEAK SHAVING
              </span>
              <Zap className="w-5 h-5 text-emerald-400 group-hover:scale-110 transition" />
            </div>
            <h3 className="text-base font-bold text-white">5. Autonomous Thermal Pre-Cooling</h3>
            <p className="text-xs text-slate-400 leading-relaxed">
              Activates AI pre-cooling between 11:30–12:30, flattening the 13:00–15:00 peak from 118 kW down to 101.6 kW.
            </p>
          </div>
        </div>
      </div>

      {/* Real-Time Simulation Event Journal */}
      <div className="bg-[#0b1329] border border-slate-800 rounded-2xl p-5 shadow-xl space-y-3 font-mono">
        <div className="flex items-center justify-between text-xs text-slate-400 border-b border-slate-800 pb-2">
          <div className="flex items-center gap-2">
            <Radio className="w-4 h-4 text-cyan-400 animate-pulse" />
            <span className="font-bold text-white">Simulation Engine Execution Journal</span>
          </div>
          <span className="text-[10px] text-slate-500">Millisecond Timestamped</span>
        </div>

        <div className="space-y-2 max-h-64 overflow-y-auto">
          {simulationLog.map(item => (
            <div
              key={item.id}
              className={`p-2.5 rounded-xl border text-xs flex items-center justify-between gap-3 ${
                item.level === "CRITICAL"
                  ? "bg-rose-950/30 border-rose-800 text-rose-300"
                  : item.level === "WARN"
                  ? "bg-amber-950/30 border-amber-800 text-amber-300"
                  : item.level === "SUCCESS"
                  ? "bg-emerald-950/30 border-emerald-800 text-emerald-300"
                  : "bg-slate-950 border-slate-800 text-slate-300"
              }`}
            >
              <div className="flex items-center gap-2.5">
                <span className="text-[10px] font-bold text-slate-500">{item.time}</span>
                <span
                  className={`text-[9px] px-1.5 py-0.5 rounded font-bold ${
                    item.level === "CRITICAL"
                      ? "bg-rose-500 text-black"
                      : item.level === "WARN"
                      ? "bg-amber-500 text-black"
                      : item.level === "SUCCESS"
                      ? "bg-emerald-500 text-black"
                      : "bg-slate-800 text-slate-400"
                  }`}
                >
                  {item.level}
                </span>
                <span>{item.event}</span>
              </div>
              <span className="text-[10px] text-slate-500">Latency: {item.latency}</span>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
