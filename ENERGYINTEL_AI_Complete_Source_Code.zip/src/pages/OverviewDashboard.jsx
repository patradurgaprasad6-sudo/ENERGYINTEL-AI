import React, { useState } from "react";
import {
  Zap,
  Activity,
  Brain,
  AlertTriangle,
  TrendingDown,
  Coins,
  Leaf,
  ShieldCheck,
  Building2,
  Layers,
  Sparkles,
  ArrowRight,
  Maximize2,
  Clock,
  Flame,
  CheckCircle2,
  SlidersHorizontal
} from "lucide-react";
import {
  ResponsiveContainer,
  AreaChart,
  Area,
  LineChart,
  Line,
  BarChart,
  Bar,
  XAxis,
  YAxis,
  Tooltip,
  Legend,
  CartesianGrid,
  ReferenceArea
} from "recharts";
import { useEnergy } from "../context/EnergyContext";
import { KpiCard } from "../components/KpiCard";

export function OverviewDashboard({ setCurrentTab }) {
  const {
    campusConfig,
    currentPowerKW,
    todayEnergyKWh,
    predictedTomorrowKWh,
    potentialWastageKWh,
    energyEfficiencyPct,
    estimatedCostINR,
    potentialSavingsINR,
    carbonEmissionKg,
    carbonSavingsKg,
    sustainabilityScore,
    hourlyData,
    weeklyData,
    monthlyData,
    selectedBuilding,
    setSelectedBuilding,
    selectedFloor,
    setSelectedFloor,
    activeAnomaly,
    activeWastageScenario,
    startAiDemo,
    recommendations,
    applyRecommendation,
    appliedRecommendations,
    alerts,
    isPeakLoadActive,
    tariffINR,
    setTariffINR
  } = useEnergy();

  const [timeRange, setTimeRange] = useState("hourly"); // "hourly" | "daily" | "weekly" | "monthly"
  const [showTariffModal, setShowTariffModal] = useState(false);
  const [tempTariff, setTempTariff] = useState(tariffINR);

  // Active top anomaly or high alert
  const topCriticalAlert = alerts.find(a => a.severity === "CRITICAL" || a.severity === "HIGH");

  return (
    <div className="space-y-6">
      {/* Top Banner: Campus Status + High Value AI Demo Banner */}
      <div className="relative overflow-hidden rounded-2xl bg-gradient-to-r from-blue-950/60 via-slate-900 to-cyan-950/50 border border-cyan-500/30 p-5 shadow-xl">
        <div className="flex flex-col lg:flex-row items-start lg:items-center justify-between gap-4">
          <div className="space-y-1">
            <div className="flex items-center gap-2 flex-wrap">
              <span className="px-2.5 py-0.5 rounded-full bg-cyan-950 border border-cyan-700 text-cyan-300 font-mono text-[10px] font-bold uppercase tracking-wider">
                CAMPUS OPERATIONS INTELLIGENCE
              </span>
              <span className="text-xs text-slate-400">
                Trident Campus • 3,250 Students • 320 Faculty • 185,000 sq.ft
              </span>
            </div>
            <h1 className="text-xl sm:text-2xl font-black text-white tracking-tight">
              Real-Time Campus Electricity Intelligence
            </h1>
            <p className="text-xs text-slate-300 max-w-2xl">
              Converting multi-sensor telemetry into predictive demand forecasts, real-time wastage isolation, and automated cost-saving recommendations.
            </p>
          </div>

          <div className="flex items-center gap-2 flex-wrap">
            <button
              onClick={startAiDemo}
              className="px-4 py-2.5 rounded-xl bg-gradient-to-r from-cyan-500 to-blue-600 hover:from-cyan-400 hover:to-blue-500 text-black font-extrabold text-xs uppercase tracking-wider shadow-lg shadow-cyan-500/30 flex items-center gap-2 cursor-pointer transition transform hover:scale-[1.02]"
            >
              <Sparkles className="w-4 h-4 text-black fill-current" />
              <span>RUN AI DEMO (10-STEP SEQUENCE)</span>
            </button>
          </div>
        </div>
      </div>

      {/* Critical Alert Bar if Anomaly or Wastage Active (Requirement 23, 37) */}
      {(activeAnomaly || activeWastageScenario || topCriticalAlert) && (
        <div className="rounded-2xl bg-gradient-to-r from-rose-950/70 to-slate-900 border-2 border-rose-500/80 p-4 shadow-lg shadow-rose-950/40 animate-pulse">
          <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3">
            <div className="flex items-center gap-3">
              <div className="p-2.5 rounded-xl bg-rose-500/20 text-rose-300 border border-rose-500/40">
                <AlertTriangle className="w-5 h-5 text-rose-400 animate-bounce" />
              </div>
              <div>
                <div className="flex items-center gap-2">
                  <span className="text-xs font-bold font-mono px-2 py-0.5 rounded bg-rose-500 text-black uppercase">
                    AI ANOMALY ALERT
                  </span>
                  <span className="text-xs text-rose-200 font-semibold">
                    {topCriticalAlert ? topCriticalAlert.title : "Abnormal Energy Spike Detected"}
                  </span>
                </div>
                <p className="text-xs text-slate-300 mt-0.5">
                  {topCriticalAlert ? topCriticalAlert.description : "Block B Floor 2 power surge (+56% above baseline). Potential compressor failure or zero-occupancy AC overrun."}
                </p>
              </div>
            </div>

            <button
              onClick={() => setCurrentTab("wastage")}
              className="px-3.5 py-1.5 rounded-xl bg-rose-600 hover:bg-rose-500 text-white font-bold text-xs flex items-center gap-1.5 cursor-pointer whitespace-nowrap"
            >
              <span>Investigate Wastage</span>
              <ArrowRight className="w-3.5 h-3.5" />
            </button>
          </div>
        </div>
      )}

      {/* 8 Primary Dashboard KPI Cards (Requirement 13) */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        {/* KPI 1: Current Consumption */}
        <KpiCard
          title="Current Consumption"
          value={currentPowerKW}
          unit="kW"
          trend={activeAnomaly ? "+56%" : isPeakLoadActive ? "+43%" : "+2.1%"}
          trendType={activeAnomaly || isPeakLoadActive ? "bad" : "neutral"}
          icon={Zap}
          subtitle="Real-time campus draw"
          badgeText={activeAnomaly ? "SPIKE" : isPeakLoadActive ? "PEAK" : "LIVE"}
          badgeColor={activeAnomaly ? "rose" : isPeakLoadActive ? "amber" : "cyan"}
          color="cyan"
        />

        {/* KPI 2: Today's Energy */}
        <KpiCard
          title="Today's Energy"
          value={todayEnergyKWh.toLocaleString()}
          unit="kWh"
          trend="Cumulative draw"
          trendType="neutral"
          icon={Activity}
          subtitle="Baseline: ~1,200 kWh"
          badgeText="TODAY"
          badgeColor="blue"
          color="blue"
        />

        {/* KPI 3: Predicted Tomorrow */}
        <KpiCard
          title="Predicted Tomorrow"
          value={predictedTomorrowKWh.toLocaleString()}
          unit="kWh"
          trend="+10.6% vs Today"
          trendType="bad"
          icon={Brain}
          subtitle="Thermodynamic model"
          badgeText="AI FORECAST"
          badgeColor="purple"
          color="purple"
          onClick={() => setCurrentTab("predictions")}
        />

        {/* KPI 4: Potential Wastage */}
        <KpiCard
          title="Potential Wastage"
          value={potentialWastageKWh}
          unit="kWh"
          trend={`${Math.round((potentialWastageKWh / todayEnergyKWh) * 100)}% of Total`}
          trendType="bad"
          icon={AlertTriangle}
          subtitle="Preventable waste"
          badgeText="ACTIONABLE"
          badgeColor="rose"
          color="rose"
          onClick={() => setCurrentTab("wastage")}
        />

        {/* KPI 5: Energy Efficiency */}
        <KpiCard
          title="Energy Efficiency"
          value={`${energyEfficiencyPct}%`}
          trend="+4.2% optimized"
          trendType="good"
          icon={ShieldCheck}
          subtitle="Campus energy benchmark"
          badgeText="SCORE: GOOD"
          badgeColor="green"
          color="green"
        />

        {/* KPI 6: Estimated Cost */}
        <KpiCard
          title="Estimated Cost"
          value={`₹${estimatedCostINR.toLocaleString()}`}
          trend={`@ ₹${tariffINR}/kWh`}
          trendType="neutral"
          icon={Coins}
          subtitle="Daily campus electricity bill"
          badgeText="BILLING"
          badgeColor="amber"
          color="amber"
          onClick={() => setShowTariffModal(true)}
        />

        {/* KPI 7: Potential Savings */}
        <KpiCard
          title="Potential Savings"
          value={`₹${potentialSavingsINR.toLocaleString()}`}
          unit="/ day"
          trend={`₹${(potentialSavingsINR * 30).toLocaleString()}/mo`}
          trendType="good"
          icon={Coins}
          subtitle="Direct financial ROI"
          badgeText="OPPORTUNITY"
          badgeColor="green"
          color="green"
          onClick={() => setCurrentTab("recommendations")}
        />

        {/* KPI 8: Carbon Emission */}
        <KpiCard
          title="Carbon Emission"
          value={carbonEmissionKg.toLocaleString()}
          unit="kg CO₂"
          trend={`-${carbonSavingsKg} kg Savable`}
          trendType="good"
          icon={Leaf}
          subtitle="Factor: 0.82 kg/kWh"
          badgeText="SCOPE 2"
          badgeColor="green"
          color="green"
          onClick={() => setCurrentTab("costcarbon")}
        />
      </div>

      {/* Large Interactive Energy Consumption Chart (Requirement 18) */}
      <div className="bg-[#0b1329] border border-slate-800 rounded-2xl p-5 shadow-xl space-y-4">
        <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 pb-2 border-b border-slate-800/80">
          <div>
            <div className="flex items-center gap-2">
              <h2 className="text-base font-bold text-white">
                Energy Consumption & Baseline Telemetry
              </h2>
              <span className="text-[10px] font-mono px-2 py-0.5 rounded-full bg-slate-800 text-slate-300">
                Interactive Graph
              </span>
            </div>
            <p className="text-xs text-slate-400 mt-0.5">
              Compare actual power consumption against baseline and AI forecasted curves.
              <span className="ml-2 inline-flex items-center gap-1.5 text-cyan-400/90 font-mono text-[11px]">
                <span className="w-1.5 h-1.5 rounded-full bg-cyan-400 inline-block animate-ping"></span>
                Official Hours: 09:00–18:00 | Lunch: 13:00–14:00 | Standby, Transition, Dispersal &amp; Baseload: &lt; 1 kW Each
              </span>
            </p>
          </div>

          {/* Time range toggles (Hourly, Daily, Weekly, Monthly) */}
          <div className="flex items-center gap-1 bg-slate-950 p-1 rounded-xl border border-slate-800 text-xs">
            {["hourly", "daily", "weekly", "monthly"].map((tab) => (
              <button
                key={tab}
                onClick={() => setTimeRange(tab)}
                className={`px-3 py-1 rounded-lg font-medium uppercase tracking-wider text-[11px] font-mono transition cursor-pointer ${
                  timeRange === tab
                    ? "bg-cyan-500/20 text-cyan-300 border border-cyan-500/40 font-bold"
                    : "text-slate-400 hover:text-white"
                }`}
              >
                {tab}
              </button>
            ))}
          </div>
        </div>

        {/* Recharts Area / Line Chart */}
        <div className="h-80 w-full">
          <ResponsiveContainer width="100%" height="100%">
            {timeRange === "hourly" ? (
              <AreaChart data={hourlyData} margin={{ top: 10, right: 10, left: -20, bottom: 0 }}>
                <defs>
                  <linearGradient id="actualColor" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#00f0ff" stopOpacity={0.4} />
                    <stop offset="95%" stopColor="#00f0ff" stopOpacity={0.0} />
                  </linearGradient>
                  <linearGradient id="predictedColor" x1="0" y1="0" x2="0" y2="1">
                    <stop offset="5%" stopColor="#8b5cf6" stopOpacity={0.3} />
                    <stop offset="95%" stopColor="#8b5cf6" stopOpacity={0.0} />
                  </linearGradient>
                </defs>
                <CartesianGrid strokeDasharray="3 3" stroke="#1e293b" opacity={0.6} />
                <XAxis dataKey="hour" stroke="#64748b" tick={{ fontSize: 11 }} />
                <YAxis stroke="#64748b" tick={{ fontSize: 11 }} />
                <Tooltip
                  contentStyle={{
                    backgroundColor: "#070b14",
                    borderColor: "#334155",
                    borderRadius: "0.75rem",
                    fontSize: "12px",
                    color: "#f8fafc"
                  }}
                  formatter={(val, name) => [`${val} kW`, name]}
                />
                <Legend wrapperStyle={{ fontSize: "11px", paddingTop: "8px" }} />
                <ReferenceArea x1="09:00" x2="18:00" stroke="#00f0ff" strokeOpacity={0.15} fill="#00f0ff" fillOpacity={0.04} />
                <ReferenceArea x1="13:00" x2="14:00" stroke="#a855f7" strokeOpacity={0.25} fill="#a855f7" fillOpacity={0.07} />
                <Area
                  type="monotone"
                  dataKey="actual"
                  name="Actual Consumption (kW)"
                  stroke="#00f0ff"
                  strokeWidth={2.5}
                  fillOpacity={1}
                  fill="url(#actualColor)"
                />
                <Line
                  type="monotone"
                  dataKey="baseline"
                  name="Baseline Standard (kW)"
                  stroke="#64748b"
                  strokeWidth={1.5}
                  strokeDasharray="4 4"
                  dot={false}
                />
                <Line
                  type="monotone"
                  dataKey="predicted"
                  name="AI Predicted Demand (kW)"
                  stroke="#a855f7"
                  strokeWidth={2}
                  strokeDasharray="2 2"
                  dot={false}
                />
              </AreaChart>
            ) : timeRange === "weekly" || timeRange === "daily" ? (
              <BarChart data={weeklyData} margin={{ top: 10, right: 10, left: -20, bottom: 0 }}>
                <CartesianGrid strokeDasharray="3 3" stroke="#1e293b" opacity={0.6} />
                <XAxis dataKey="day" stroke="#64748b" tick={{ fontSize: 11 }} />
                <YAxis stroke="#64748b" tick={{ fontSize: 11 }} />
                <Tooltip
                  contentStyle={{
                    backgroundColor: "#070b14",
                    borderColor: "#334155",
                    borderRadius: "0.75rem",
                    fontSize: "12px",
                    color: "#f8fafc"
                  }}
                  formatter={(val, name) => [`${val} kWh`, name]}
                />
                <Legend wrapperStyle={{ fontSize: "11px", paddingTop: "8px" }} />
                <Bar dataKey="actual" name="Actual Energy (kWh)" fill="#00f0ff" radius={[4, 4, 0, 0]} />
                <Bar dataKey="predicted" name="AI Forecast (kWh)" fill="#8b5cf6" radius={[4, 4, 0, 0]} />
                <Bar dataKey="wastage" name="Detected Wastage (kWh)" fill="#f43f5e" radius={[4, 4, 0, 0]} />
              </BarChart>
            ) : (
              <BarChart data={monthlyData} margin={{ top: 10, right: 10, left: -10, bottom: 0 }}>
                <CartesianGrid strokeDasharray="3 3" stroke="#1e293b" opacity={0.6} />
                <XAxis dataKey="month" stroke="#64748b" tick={{ fontSize: 11 }} />
                <YAxis stroke="#64748b" tick={{ fontSize: 11 }} />
                <Tooltip
                  contentStyle={{
                    backgroundColor: "#070b14",
                    borderColor: "#334155",
                    borderRadius: "0.75rem",
                    fontSize: "12px",
                    color: "#f8fafc"
                  }}
                  formatter={(val, name) => [`${val} kWh`, name]}
                />
                <Legend wrapperStyle={{ fontSize: "11px", paddingTop: "8px" }} />
                <Bar dataKey="consumed" name="Monthly Consumed (kWh)" fill="#3b82f6" radius={[4, 4, 0, 0]} />
                <Bar dataKey="wastage" name="Avoidable Wastage (kWh)" fill="#f59e0b" radius={[4, 4, 0, 0]} />
              </BarChart>
            )}
          </ResponsiveContainer>
        </div>

        {/* Chart Context Footer */}
        <div className="flex flex-wrap items-center justify-between text-xs text-slate-400 pt-2 border-t border-slate-800/80">
          <div className="flex items-center gap-4">
            <span className="flex items-center gap-1.5">
              <span className="w-2.5 h-2.5 rounded-full bg-cyan-400"></span> Actual Load
            </span>
            <span className="flex items-center gap-1.5">
              <span className="w-2.5 h-2.5 rounded-full bg-purple-400"></span> AI Prediction
            </span>
            <span className="flex items-center gap-1.5">
              <span className="w-2.5 h-2.5 rounded-full bg-slate-500"></span> Baseline (Idle)
            </span>
          </div>
          <span className="font-mono text-cyan-400 text-[11px]">
            Peak Period Today: 13:00 – 15:00 (Thermal & Academic Maximum)
          </span>
        </div>
      </div>

      {/* Campus Building Overview Cards (Requirement 25) */}
      <div className="space-y-3">
        <div className="flex items-center justify-between">
          <div>
            <h2 className="text-base font-bold text-white flex items-center gap-2">
              <Building2 className="w-5 h-5 text-cyan-400" />
              <span>Campus Building Intelligence Drill-Down</span>
            </h2>
            <p className="text-xs text-slate-400">
              Select any building to isolate floor-level telemetry, occupancy, and wastage risks
            </p>
          </div>
          <button
            onClick={() => setCurrentTab("building")}
            className="text-xs text-cyan-400 hover:text-cyan-300 font-semibold flex items-center gap-1 cursor-pointer"
          >
            <span>Full Floor Plans</span>
            <ArrowRight className="w-3.5 h-3.5" />
          </button>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          {campusConfig.buildings.map((b) => {
            const isSelected = selectedBuilding === b.id;
            return (
              <div
                key={b.id}
                onClick={() => {
                  setSelectedBuilding(b.id);
                  setCurrentTab("building");
                }}
                className={`p-5 rounded-2xl border transition-all cursor-pointer ${
                  isSelected
                    ? "bg-slate-900 border-cyan-400 shadow-lg shadow-cyan-500/20"
                    : "bg-[#0b1329] border-slate-800 hover:border-slate-700 hover:bg-slate-900/60"
                }`}
              >
                <div className="flex items-start justify-between">
                  <div>
                    <span className="text-xs font-mono font-bold text-cyan-400">BLOCK {b.code}</span>
                    <h3 className="text-base font-bold text-white mt-0.5">{b.name}</h3>
                    <p className="text-xs text-slate-400 mt-1">{b.type}</p>
                  </div>
                  <div className="p-2 rounded-xl bg-slate-800/80 text-slate-300">
                    <Building2 className="w-5 h-5" />
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-2 mt-4 pt-3 border-t border-slate-800">
                  <div className="p-2.5 rounded-xl bg-slate-950/80">
                    <span className="text-[10px] text-slate-400 uppercase font-mono">Current Power</span>
                    <div className="text-lg font-black text-cyan-300 font-mono mt-0.5">
                      {b.nominalPowerKW} kW
                    </div>
                  </div>
                  <div className="p-2.5 rounded-xl bg-slate-950/80">
                    <span className="text-[10px] text-slate-400 uppercase font-mono">Efficiency</span>
                    <div className="text-lg font-black text-emerald-400 font-mono mt-0.5">
                      {b.nominalEfficiency}%
                    </div>
                  </div>
                </div>

                <div className="mt-3 flex items-center justify-between text-xs text-slate-400 pt-1">
                  <span>3 Floors • {b.floors.length} Monitored Zones</span>
                  <span className="text-cyan-400 font-medium flex items-center gap-1 group">
                    <span>Inspect</span>
                    <ArrowRight className="w-3.5 h-3.5" />
                  </span>
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* High-Impact AI Recommendations Quick List (Requirement 27, 28) */}
      <div className="bg-[#0b1329] border border-slate-800 rounded-2xl p-5 shadow-xl space-y-4">
        <div className="flex items-center justify-between">
          <div>
            <h2 className="text-base font-bold text-white flex items-center gap-2">
              <Sparkles className="w-5 h-5 text-yellow-400" />
              <span>Prioritized AI Optimization Actions</span>
            </h2>
            <p className="text-xs text-slate-400">
              Ranked by kilowatt-hour conservation potential and implementation ease
            </p>
          </div>
          <button
            onClick={() => setCurrentTab("recommendations")}
            className="text-xs text-cyan-400 hover:text-cyan-300 font-semibold flex items-center gap-1 cursor-pointer"
          >
            <span>View All ({recommendations.length})</span>
            <ArrowRight className="w-3.5 h-3.5" />
          </button>
        </div>

        <div className="space-y-3">
          {recommendations.slice(0, 3).map((rec) => {
            const isApplied = appliedRecommendations.has(rec.id);
            return (
              <div
                key={rec.id}
                className="p-4 rounded-xl bg-slate-900/80 border border-slate-800 flex flex-col md:flex-row items-start md:items-center justify-between gap-4"
              >
                <div className="space-y-1 max-w-2xl">
                  <div className="flex items-center gap-2 flex-wrap">
                    <span
                      className={`text-[10px] font-mono px-2 py-0.5 rounded font-bold uppercase ${
                        rec.priority === "CRITICAL"
                          ? "bg-rose-500/20 text-rose-300 border border-rose-500/50"
                          : rec.priority === "HIGH"
                          ? "bg-amber-500/20 text-amber-300 border border-amber-500/50"
                          : "bg-cyan-500/20 text-cyan-300 border border-cyan-500/50"
                      }`}
                    >
                      {rec.priority} PRIORITY
                    </span>
                    <span className="text-xs text-slate-300 font-semibold">{rec.title}</span>
                    <span className="text-xs text-slate-500">•</span>
                    <span className="text-xs text-cyan-400 font-mono">{rec.building} — {rec.floor}</span>
                  </div>
                  <p className="text-xs text-slate-300">
                    <strong className="text-slate-100">Action:</strong> {rec.action}
                  </p>
                </div>

                <div className="flex items-center gap-3 w-full md:w-auto justify-between md:justify-end">
                  <div className="text-right">
                    <div className="text-xs font-mono font-bold text-emerald-400">
                      +{rec.energySavingKWh} kWh / day
                    </div>
                    <div className="text-[11px] font-mono text-cyan-400">
                      Save ₹{rec.costSavingINR}/day
                    </div>
                  </div>

                  <button
                    onClick={() => applyRecommendation(rec.id)}
                    disabled={isApplied}
                    className={`px-3 py-1.5 rounded-xl font-bold text-xs uppercase tracking-wider transition cursor-pointer flex items-center gap-1.5 ${
                      isApplied
                        ? "bg-emerald-500/20 border border-emerald-500/50 text-emerald-300 cursor-default"
                        : "bg-cyan-500 hover:bg-cyan-400 text-black shadow-md shadow-cyan-500/20"
                    }`}
                  >
                    {isApplied ? (
                      <>
                        <CheckCircle2 className="w-3.5 h-3.5" />
                        <span>Applied</span>
                      </>
                    ) : (
                      <span>Apply Action</span>
                    )}
                  </button>
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* Editable Tariff Modal (Requirement 29) */}
      {showTariffModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 backdrop-blur-sm p-4">
          <div className="bg-[#0b1329] border border-cyan-500/40 rounded-2xl p-6 max-w-sm w-full space-y-4 shadow-2xl">
            <h3 className="text-base font-bold text-white flex items-center gap-2">
              <Coins className="w-5 h-5 text-amber-400" />
              <span>Configure Commercial Electricity Tariff</span>
            </h3>
            <p className="text-xs text-slate-300">
              Set the per-unit electricity cost (₹/kWh) provided by the utility provider to dynamically recalculate billing and potential savings.
            </p>

            <div>
              <label className="text-xs font-mono font-semibold text-slate-400">
                TARIFF RATE (₹ / kWh)
              </label>
              <div className="mt-1 relative">
                <span className="absolute left-3 top-2.5 text-slate-400 font-mono">₹</span>
                <input
                  type="number"
                  step="0.5"
                  value={tempTariff}
                  onChange={(e) => setTempTariff(Number(e.target.value))}
                  className="w-full bg-slate-950 border border-slate-700 rounded-xl pl-8 pr-3 py-2 text-white font-mono text-sm focus:outline-none focus:border-cyan-400"
                />
              </div>
            </div>

            <div className="flex items-center justify-end gap-2 pt-2">
              <button
                onClick={() => setShowTariffModal(false)}
                className="px-3 py-1.5 rounded-xl bg-slate-800 text-slate-300 text-xs font-medium cursor-pointer"
              >
                Cancel
              </button>
              <button
                onClick={() => {
                  setTariffINR(tempTariff);
                  setShowTariffModal(false);
                }}
                className="px-4 py-1.5 rounded-xl bg-cyan-500 hover:bg-cyan-400 text-black text-xs font-bold cursor-pointer"
              >
                Save Tariff
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
