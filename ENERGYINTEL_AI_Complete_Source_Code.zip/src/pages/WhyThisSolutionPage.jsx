import React from "react";
import {
  HelpCircle,
  Sparkles,
  ArrowRight,
  CheckCircle2,
  XCircle,
  Zap,
  Brain,
  Search,
  Lightbulb,
  Coins,
  ShieldCheck,
  TrendingDown,
  Layers,
  Clock,
  Play
} from "lucide-react";
import { useEnergy } from "../context/EnergyContext";

export function WhyThisSolutionPage({ setCurrentTab }) {
  const { startAiDemo } = useEnergy();

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 p-5 rounded-2xl bg-gradient-to-r from-cyan-950/50 via-slate-900 to-blue-950/40 border border-cyan-500/30">
        <div>
          <div className="flex items-center gap-2">
            <span className="px-2.5 py-0.5 rounded-full bg-cyan-950 border border-cyan-700 text-cyan-300 font-mono text-[10px] font-bold uppercase tracking-wider">
              EVALUATOR & JUDGE GUIDE
            </span>
            <span className="text-xs text-cyan-300 font-bold">
              Core Value Proposition
            </span>
          </div>
          <h1 className="text-2xl font-black text-white mt-1">
            Why EnergyIntel AI? Competitive Differentiation & Pitch
          </h1>
          <p className="text-xs text-slate-300 mt-0.5">
            How this platform goes beyond passive dashboards to deliver autonomous root-cause diagnosis and actionable savings.
          </p>
        </div>

        <button
          onClick={startAiDemo}
          className="px-4 py-2.5 rounded-xl bg-gradient-to-r from-cyan-500 to-blue-600 hover:from-cyan-400 hover:to-blue-500 text-black font-extrabold text-xs uppercase tracking-wider shadow-lg shadow-cyan-500/20 flex items-center gap-2 cursor-pointer transition transform hover:scale-105"
        >
          <Play className="w-4 h-4 fill-current" />
          <span>Launch 10-Step AI Demo</span>
        </button>
      </div>

      {/* 5 Core Pitch Questions (Requirement 59) */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        <div className="p-5 rounded-2xl bg-[#0b1329] border border-slate-800 space-y-2">
          <span className="text-xs font-mono font-bold text-rose-400 uppercase">1. WHY? (The Problem)</span>
          <h3 className="text-base font-bold text-white">Invisible Facility Waste</h3>
          <p className="text-xs text-slate-300 leading-relaxed">
            Large university campuses waste 18–35% of electricity because lights stay on in empty lecture halls, AC chillers run during low occupancy, and equipment hums after hours without unified visibility.
          </p>
        </div>

        <div className="p-5 rounded-2xl bg-[#0b1329] border border-slate-800 space-y-2">
          <span className="text-xs font-mono font-bold text-cyan-400 uppercase">2. WHAT? (The Product)</span>
          <h3 className="text-base font-bold text-white">AI Energy Intelligence</h3>
          <p className="text-xs text-slate-300 leading-relaxed">
            A real-time intelligence hub aggregating sub-metered power, ambient weather, and occupant density into predictive thermodynamic forecasting and automated prescriptive alerts.
          </p>
        </div>

        <div className="p-5 rounded-2xl bg-[#0b1329] border border-slate-800 space-y-2">
          <span className="text-xs font-mono font-bold text-purple-400 uppercase">3. HOW? (The Loop)</span>
          <h3 className="text-base font-bold text-white">Monitor → Predict → Action</h3>
          <p className="text-xs text-slate-300 leading-relaxed">
            Continuously ingesting telemetry → predicting tomorrow's load → isolating anomalies → diagnosing exact room root causes → prescribing 1-click facility actions.
          </p>
        </div>

        <div className="p-5 rounded-2xl bg-[#0b1329] border border-slate-800 space-y-2">
          <span className="text-xs font-mono font-bold text-emerald-400 uppercase">4. IMPACT? (The ROI)</span>
          <h3 className="text-base font-bold text-white">Quantifiable Capital Saved</h3>
          <p className="text-xs text-slate-300 leading-relaxed">
            186 kWh saved per day = ₹1,488 daily utility bill reduction (₹5.35 Lakhs annually) + 152.5 kg CO₂ Scope 2 emissions eliminated every single day.
          </p>
        </div>
      </div>

      {/* The 6-Stage Differentiation Loop (Requirement 60) */}
      <div className="p-6 rounded-2xl bg-[#0b1329] border border-cyan-500/40 shadow-xl space-y-5">
        <div>
          <span className="text-xs font-mono font-bold text-cyan-400 uppercase tracking-wider">
            COMPETITIVE DIFFERENTIATION: BEYOND PASSIVE METERS
          </span>
          <h2 className="text-lg font-bold text-white mt-1">
            Why EnergyIntel AI Outperforms Traditional Building Management Systems (BMS)
          </h2>
          <p className="text-xs text-slate-300 mt-0.5">
            Traditional meters tell you <em>"You consumed 82 kW"</em>. EnergyIntel AI tells you <em>"Why"</em>, <em>"What is abnormal"</em>, and <em>"What exact action to take right now"</em>.
          </p>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-6 gap-3 pt-2">
          <div className="p-3.5 rounded-xl bg-slate-950 border border-slate-800 space-y-1">
            <span className="text-[10px] font-mono text-cyan-400 font-bold uppercase">1. MONITORING</span>
            <div className="text-xs font-bold text-white">What is happening?</div>
            <p className="text-[11px] text-slate-400">82.4 kW campus draw</p>
          </div>

          <div className="p-3.5 rounded-xl bg-slate-950 border border-slate-800 space-y-1">
            <span className="text-[10px] font-mono text-purple-400 font-bold uppercase">2. PREDICTION</span>
            <div className="text-xs font-bold text-white">What will happen?</div>
            <p className="text-[11px] text-slate-400">1,420 kWh tomorrow</p>
          </div>

          <div className="p-3.5 rounded-xl bg-slate-950 border border-slate-800 space-y-1">
            <span className="text-[10px] font-mono text-rose-400 font-bold uppercase">3. DETECTION</span>
            <div className="text-xs font-bold text-white">What is abnormal?</div>
            <p className="text-[11px] text-slate-400">+56% Block B surge</p>
          </div>

          <div className="p-3.5 rounded-xl bg-slate-950 border border-slate-800 space-y-1">
            <span className="text-[10px] font-mono text-amber-400 font-bold uppercase">4. REASON</span>
            <div className="text-xs font-bold text-white">Why is it happening?</div>
            <p className="text-[11px] text-slate-400">AC at 18°C with 24% occ</p>
          </div>

          <div className="p-3.5 rounded-xl bg-slate-950 border border-slate-800 space-y-1">
            <span className="text-[10px] font-mono text-emerald-400 font-bold uppercase">5. RECOMMEND</span>
            <div className="text-xs font-bold text-white">What should we do?</div>
            <p className="text-[11px] text-slate-400">Float setpoint to 24°C</p>
          </div>

          <div className="p-3.5 rounded-xl bg-slate-950 border border-slate-800 space-y-1">
            <span className="text-[10px] font-mono text-teal-400 font-bold uppercase">6. IMPACT</span>
            <div className="text-xs font-bold text-white">How much saved?</div>
            <p className="text-[11px] text-emerald-400 font-bold font-mono">186 kWh / ₹1,488 / day</p>
          </div>
        </div>
      </div>

      {/* 5-Minute Judge Demo Workflow (Requirement 62) */}
      <div className="p-6 rounded-2xl bg-gradient-to-br from-slate-900 to-[#101b38] border border-slate-800 space-y-4">
        <div className="flex items-center justify-between">
          <div>
            <span className="text-xs font-mono font-bold text-cyan-400 uppercase">
              5-MINUTE HACKATHON PRESENTATION SCRIPT
            </span>
            <h2 className="text-base font-bold text-white mt-0.5">
              Recommended Presentation Steps for the Evaluation Panel
            </h2>
          </div>
          <span className="text-xs font-mono px-3 py-1 rounded-full bg-slate-800 text-slate-300">
            Estimated Demo Time: 4-5 Mins
          </span>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3 text-xs">
          {[
            { step: "01", action: "Login in 1-Click via Demo Mode", detail: "Bypasses credentials and loads Trident Campus dataset" },
            { step: "02", action: "Explain Campus Hierarchy", detail: "Show 4 Blocks (A, B, C, D) and 12 submetered zones" },
            { step: "03", action: "Review 8 Core KPI Cards", detail: "82.4 kW live draw, 1,284 kWh today, ₹10,272 estimated billing" },
            { step: "04", action: "Click 'RUN AI DEMO'", detail: "Demonstrates 10-step autonomous sequence with confetti finish" },
            { step: "05", action: "Show AI Predictions", detail: "Highlight multivariate thermodynamic curve & tomorrow forecast" },
            { step: "06", action: "Trigger 'Generate Anomaly'", detail: "Observe live surge to 128 kW and automatic alert generation" },
            { step: "07", action: "Review AI Wastage Cases", detail: "Show Case 2 AC overrun with 24% occupancy in Lab 204" },
            { step: "08", action: "Execute AI Recommendation", detail: "Apply action and watch potential wastage decrease" },
            { step: "09", action: "Drill into Building Intelligence", detail: "Inspect Block B Floor 2 micro-level room telemetry" },
            { step: "10", action: "Test What-If Simulator", detail: "Slide ambient temperature and preview immediate ROI" }
          ].map((s, idx) => (
            <div key={idx} className="p-3 rounded-xl bg-slate-950/80 border border-slate-800/80 space-y-1">
              <div className="flex items-center gap-2">
                <span className="font-mono font-bold text-cyan-400">{s.step}.</span>
                <span className="font-semibold text-white">{s.action}</span>
              </div>
              <p className="text-[11px] text-slate-400 pl-5">
                {s.detail}
              </p>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
