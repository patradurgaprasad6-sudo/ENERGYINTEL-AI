import React, { useState } from "react";
import {
  Sun,
  Fan,
  Zap,
  Building2,
  Layers,
  Sliders,
  RotateCcw,
  Sparkles,
  Coins,
  Leaf,
  CheckCircle2,
  Box,
  Download,
  Flame,
  ArrowRight
} from "lucide-react";
import { useEnergy } from "../context/EnergyContext";
import { ThreeDigitalTwinCanvas } from "../components/ThreeDigitalTwinCanvas";
import { calculateFloorConsumption, APPLIANCE_SPECS } from "../services/mockDataGenerator";

export function FloorSimulationStudioPage() {
  const {
    campusConfig,
    applianceSpecs,
    selectedBuilding,
    setSelectedBuilding,
    selectedFloor,
    setSelectedFloor,
    floorApplianceStates,
    updateFloorBulbsPct,
    updateFloorFansPct,
    updateFloorAcsPct,
    toggleSingleBulb,
    toggleSingleFan,
    toggleSingleAc,
    setAllFloorsPreset,
    campusTotals,
    tariffINR,
    todayEnergyKWh
  } = useEnergy();

  const [activeTabSubView, setActiveTabSubView] = useState("appliance-controls"); // "appliance-controls" | "matrix"

  // Current active building object
  const currentBuildingObj = campusConfig.buildings.find(b => b.id === selectedBuilding) || campusConfig.buildings[0];

  // Current active floor object
  const currentFloorObj = currentBuildingObj.floors.find(f => f.id === selectedFloor) || currentBuildingObj.floors[0];

  // Current active floor appliance state
  const currentFloorState = floorApplianceStates[currentFloorObj.id] || {
    bulbsPct: 60,
    fansPct: 60,
    acsPct: 60,
    activeBulbsCount: 12,
    activeFansCount: 6,
    activeAcsCount: 3,
    bulbs: Array(20).fill(true).map((_, i) => i < 12),
    fans: Array(10).fill(true).map((_, i) => i < 6),
    acs: Array(5).fill(true).map((_, i) => i < 3),
    floorNumber: currentFloorObj.number
  };

  // Floor consumption calculation
  const floorUsage = calculateFloorConsumption(currentFloorState);

  // Building consumption calculation
  const buildingUsage = campusTotals.buildingPowers[selectedBuilding] || { totalW: 0, totalKW: 0 };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 p-5 rounded-2xl bg-gradient-to-r from-blue-950/60 via-slate-900 to-cyan-950/50 border border-cyan-500/40 shadow-xl">
        <div>
          <div className="flex items-center gap-2">
            <span className="px-2.5 py-0.5 rounded-full bg-cyan-950 border border-cyan-700 text-cyan-300 font-mono text-[10px] font-bold uppercase tracking-wider flex items-center gap-1.5">
              <Box className="w-3.5 h-3.5 text-cyan-400" />
              FLOOR-WISE 3D DIGITAL TWIN & SIMULATION
            </span>
            <span className="text-[11px] font-mono text-emerald-400 font-semibold">
              4 BUILDINGS • 3 FLOORS EACH
            </span>
          </div>
          <h1 className="text-2xl font-black text-white mt-1">
            Floor-Wise Appliance Telemetry & Manual % Controls
          </h1>
          <p className="text-xs text-slate-300 mt-0.5">
            Per floor specifications: <strong>20 Bulbs (20W)</strong>, <strong>10 Fans (75W)</strong>, and <strong>5 ACs (2000W)</strong>. Adjust % sliders or click individual appliances to observe real-time consumption changes.
          </p>
        </div>

        {/* Live Power Sums Badge */}
        <div className="flex items-center gap-2">
          <div className="p-3 rounded-xl bg-slate-900 border border-cyan-500/40 text-right">
            <span className="text-[10px] text-slate-400 font-mono uppercase">Current Floor Power</span>
            <div className="text-2xl font-black text-cyan-300 font-mono">
              {floorUsage.totalW.toLocaleString()} W
            </div>
            <span className="text-[10px] text-cyan-400 font-mono">
              {floorUsage.totalKW} kW
            </span>
          </div>

          <div className="p-3 rounded-xl bg-slate-900 border border-slate-800 text-right">
            <span className="text-[10px] text-slate-400 font-mono uppercase">Campus Net Load</span>
            <div className="text-2xl font-black text-emerald-400 font-mono">
              {campusTotals.totalCampusKW} kW
            </div>
            <span className="text-[10px] text-slate-500 font-mono">
              All 12 Floors
            </span>
          </div>
        </div>
      </div>

      {/* Building & Floor Dropdown Selector Bar (Requested by user!) */}
      <div className="p-4 rounded-2xl bg-[#0b1329] border border-cyan-500/40 shadow-xl flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
        <div className="flex items-center gap-3 flex-wrap w-full md:w-auto">
          {/* 1. SELECT BUILDING DROPDOWN */}
          <div className="space-y-1">
            <label className="text-[10px] font-mono font-bold text-slate-400 uppercase flex items-center gap-1">
              <Building2 className="w-3.5 h-3.5 text-cyan-400" />
              1. SELECT BUILDING (4 BUILDINGS)
            </label>
            <select
              value={selectedBuilding}
              onChange={(e) => setSelectedBuilding(e.target.value)}
              className="bg-slate-950 text-white font-bold text-xs border border-cyan-500/60 rounded-xl px-3 py-2 focus:outline-none focus:border-cyan-400 shadow-md min-w-[240px]"
            >
              {campusConfig.buildings.map((b) => (
                <option key={b.id} value={b.id}>
                  🏢 {b.name}
                </option>
              ))}
            </select>
          </div>

          <div className="hidden md:block h-8 w-px bg-slate-800"></div>

          {/* 2. SELECT FLOOR DROPDOWN (Appears after building selection) */}
          <div className="space-y-1">
            <label className="text-[10px] font-mono font-bold text-slate-400 uppercase flex items-center gap-1">
              <Layers className="w-3.5 h-3.5 text-purple-400" />
              2. SELECT FLOOR (3 FLOORS)
            </label>
            <select
              value={selectedFloor}
              onChange={(e) => setSelectedFloor(e.target.value)}
              className="bg-slate-950 text-purple-300 font-bold text-xs border border-purple-500/60 rounded-xl px-3 py-2 focus:outline-none focus:border-purple-400 shadow-md min-w-[260px]"
            >
              {currentBuildingObj.floors.map((fl) => (
                <option key={fl.id} value={fl.id}>
                  📑 Floor {fl.number}: {fl.name.split(":")[1]?.trim() || fl.name}
                </option>
              ))}
            </select>
          </div>
        </div>

        {/* Quick Presets for Current Floor */}
        <div className="flex items-center gap-1.5 flex-wrap">
          <span className="text-[10px] font-mono text-slate-400">Presets:</span>
          <button
            onClick={() => {
              updateFloorBulbsPct(currentFloorObj.id, 0);
              updateFloorFansPct(currentFloorObj.id, 0);
              updateFloorAcsPct(currentFloorObj.id, 0);
            }}
            className="px-2.5 py-1 rounded-lg bg-slate-900 border border-slate-800 text-slate-400 hover:text-white text-xs font-mono cursor-pointer"
          >
            All OFF (0W)
          </button>
          <button
            onClick={() => {
              updateFloorBulbsPct(currentFloorObj.id, 50);
              updateFloorFansPct(currentFloorObj.id, 50);
              updateFloorAcsPct(currentFloorObj.id, 40);
            }}
            className="px-2.5 py-1 rounded-lg bg-slate-900 border border-slate-800 text-cyan-300 hover:text-white text-xs font-mono cursor-pointer"
          >
            Eco Mode
          </button>
          <button
            onClick={() => {
              updateFloorBulbsPct(currentFloorObj.id, 100);
              updateFloorFansPct(currentFloorObj.id, 100);
              updateFloorAcsPct(currentFloorObj.id, 100);
            }}
            className="px-2.5 py-1 rounded-lg bg-slate-900 border border-slate-800 text-amber-300 hover:text-white text-xs font-mono cursor-pointer"
          >
            Max (11.15 kW)
          </button>
        </div>
      </div>

      {/* Main 2-Column Section: 3D Three.js Digital Twin & Manual % Control Sliders */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Left Column: Real Three.js 3D Digital Twin Canvas (6 cols) */}
        <div className="lg:col-span-6 space-y-3">
          <div className="flex items-center justify-between">
            <h2 className="text-sm font-bold text-white uppercase font-mono flex items-center gap-2">
              <Box className="w-4 h-4 text-cyan-400" />
              <span>Three.js Real-Time 3D Digital Twin</span>
            </h2>
            <span className="text-[10px] font-mono text-cyan-400">WebGL Accelerated</span>
          </div>

          {/* Three.js Canvas */}
          <ThreeDigitalTwinCanvas
            selectedBuildingId={selectedBuilding}
            selectedFloorId={selectedFloor}
            floorApplianceState={currentFloorState}
          />
        </div>

        {/* Right Column: Manual % Sliders & Appliance Controls (6 cols) */}
        <div className="lg:col-span-6 bg-[#0b1329] border border-slate-800 rounded-2xl p-5 shadow-xl space-y-5">
          <div className="flex items-center justify-between border-b border-slate-800 pb-3">
            <div>
              <span className="text-[10px] font-mono font-bold text-cyan-400 uppercase">
                {currentBuildingObj.shortName} — FLOOR {currentFloorObj.number}
              </span>
              <h2 className="text-base font-bold text-white mt-0.5">
                Appliance On/Off % Sliders
              </h2>
            </div>
            <div className="text-right">
              <span className="text-xs text-slate-400 font-mono">Floor Power:</span>
              <div className="text-xl font-black text-cyan-300 font-mono">
                {floorUsage.totalW.toLocaleString()} W
              </div>
            </div>
          </div>

          {/* SLIDER 1: LIGHTS / BULBS (20 Bulbs × 20W each) */}
          <div className="p-4 rounded-xl bg-slate-950 border border-yellow-500/30 space-y-3">
            <div className="flex items-start justify-between">
              <div className="flex items-center gap-2.5">
                <div className="p-2 rounded-lg bg-yellow-500/20 text-yellow-400">
                  <Sun className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="text-sm font-bold text-white">Lights / LED Bulbs</h3>
                  <span className="text-xs text-slate-400 font-mono">
                    20 Bulbs • 20W Consumption each
                  </span>
                </div>
              </div>

              <div className="text-right font-mono">
                <span className="text-xs font-bold text-yellow-400">
                  {currentFloorState.activeBulbsCount} / 20 Active
                </span>
                <div className="text-base font-black text-white">
                  {floorUsage.bulbsW} W
                </div>
              </div>
            </div>

            {/* % Slider */}
            <div className="space-y-1.5">
              <div className="flex justify-between text-xs font-mono">
                <span className="text-slate-400">On / Off Rate:</span>
                <span className="text-yellow-400 font-bold">{currentFloorState.bulbsPct}%</span>
              </div>
              <input
                type="range"
                min="0"
                max="100"
                step="5"
                value={currentFloorState.bulbsPct}
                onChange={(e) => updateFloorBulbsPct(currentFloorObj.id, Number(e.target.value))}
                className="w-full h-2 bg-slate-800 rounded-lg appearance-none cursor-pointer accent-yellow-400"
              />
              <div className="flex justify-between text-[10px] text-slate-500 font-mono">
                <span>0% (0W)</span>
                <span>50% (10 Bulbs = 200W)</span>
                <span>100% (20 Bulbs = 400W)</span>
              </div>
            </div>
          </div>

          {/* SLIDER 2: FANS (10 Fans × 75W each) */}
          <div className="p-4 rounded-xl bg-slate-950 border border-cyan-500/30 space-y-3">
            <div className="flex items-start justify-between">
              <div className="flex items-center gap-2.5">
                <div className="p-2 rounded-lg bg-cyan-500/20 text-cyan-400">
                  <Fan className={`w-5 h-5 ${currentFloorState.activeFansCount > 0 ? 'animate-spin' : ''}`} />
                </div>
                <div>
                  <h3 className="text-sm font-bold text-white">Ceiling Fans</h3>
                  <span className="text-xs text-slate-400 font-mono">
                    10 Fans • 75W Consumption each
                  </span>
                </div>
              </div>

              <div className="text-right font-mono">
                <span className="text-xs font-bold text-cyan-400">
                  {currentFloorState.activeFansCount} / 10 Active
                </span>
                <div className="text-base font-black text-white">
                  {floorUsage.fansW} W
                </div>
              </div>
            </div>

            {/* % Slider */}
            <div className="space-y-1.5">
              <div className="flex justify-between text-xs font-mono">
                <span className="text-slate-400">On / Off Rate:</span>
                <span className="text-cyan-400 font-bold">{currentFloorState.fansPct}%</span>
              </div>
              <input
                type="range"
                min="0"
                max="100"
                step="10"
                value={currentFloorState.fansPct}
                onChange={(e) => updateFloorFansPct(currentFloorObj.id, Number(e.target.value))}
                className="w-full h-2 bg-slate-800 rounded-lg appearance-none cursor-pointer accent-cyan-400"
              />
              <div className="flex justify-between text-[10px] text-slate-500 font-mono">
                <span>0% (0W)</span>
                <span>50% (5 Fans = 375W)</span>
                <span>100% (10 Fans = 750W)</span>
              </div>
            </div>
          </div>

          {/* SLIDER 3: AC UNITS (5 ACs × 2000W each) */}
          <div className="p-4 rounded-xl bg-slate-950 border border-blue-500/30 space-y-3">
            <div className="flex items-start justify-between">
              <div className="flex items-center gap-2.5">
                <div className="p-2 rounded-lg bg-blue-500/20 text-blue-400">
                  <Zap className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="text-sm font-bold text-white">Air Conditioners (AC)</h3>
                  <span className="text-xs text-slate-400 font-mono">
                    5 Split ACs • 2000W (2kW) each
                  </span>
                </div>
              </div>

              <div className="text-right font-mono">
                <span className="text-xs font-bold text-blue-400">
                  {currentFloorState.activeAcsCount} / 5 Active
                </span>
                <div className="text-base font-black text-white">
                  {floorUsage.acsW.toLocaleString()} W
                </div>
              </div>
            </div>

            {/* % Slider */}
            <div className="space-y-1.5">
              <div className="flex justify-between text-xs font-mono">
                <span className="text-slate-400">On / Off Rate:</span>
                <span className="text-blue-400 font-bold">{currentFloorState.acsPct}%</span>
              </div>
              <input
                type="range"
                min="0"
                max="100"
                step="20"
                value={currentFloorState.acsPct}
                onChange={(e) => updateFloorAcsPct(currentFloorObj.id, Number(e.target.value))}
                className="w-full h-2 bg-slate-800 rounded-lg appearance-none cursor-pointer accent-blue-400"
              />
              <div className="flex justify-between text-[10px] text-slate-500 font-mono">
                <span>0% (0W)</span>
                <span>40% (2 ACs = 4000W)</span>
                <span>100% (5 ACs = 10,000W / 10kW)</span>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Individual Appliance Interactive Matrix (Click any bulb, fan, or AC!) */}
      <div className="bg-[#0b1329] border border-slate-800 rounded-2xl p-6 shadow-xl space-y-6">
        <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 border-b border-slate-800 pb-3">
          <div>
            <h2 className="text-base font-bold text-white flex items-center gap-2">
              <Sliders className="w-5 h-5 text-cyan-400" />
              <span>Interactive Individual Appliance Switches</span>
            </h2>
            <p className="text-xs text-slate-400">
              Click individual appliance icons below to toggle them ON/OFF. Watch the consumption and % sliders update dynamically!
            </p>
          </div>

          <div className="text-xs font-mono text-cyan-300">
            Total Floor Max Capacity: 11,150 W (11.15 kW)
          </div>
        </div>

        {/* 1. 20 Bulbs Grid */}
        <div className="space-y-2">
          <div className="flex justify-between text-xs font-mono">
            <span className="text-slate-300 font-bold flex items-center gap-1.5">
              <Sun className="w-4 h-4 text-yellow-400" />
              20 LED BULBS (20W each):
            </span>
            <span className="text-yellow-400 font-bold">
              {currentFloorState.activeBulbsCount} ON ({floorUsage.bulbsW} W)
            </span>
          </div>

          <div className="grid grid-cols-4 sm:grid-cols-5 md:grid-cols-10 gap-2">
            {currentFloorState.bulbs.map((isOn, idx) => (
              <button
                key={idx}
                onClick={() => toggleSingleBulb(currentFloorObj.id, idx)}
                className={`p-2.5 rounded-xl border flex flex-col items-center justify-center gap-1 transition cursor-pointer ${
                  isOn
                    ? "bg-yellow-500/20 border-yellow-500/70 text-yellow-300 shadow-sm shadow-yellow-500/20 scale-105"
                    : "bg-slate-950 border-slate-800 text-slate-600 hover:border-slate-700"
                }`}
              >
                <Sun className={`w-4 h-4 ${isOn ? 'text-yellow-400 fill-current' : 'text-slate-600'}`} />
                <span className="text-[10px] font-mono font-bold">B{idx + 1}</span>
                <span className="text-[9px] font-mono">{isOn ? "20W" : "0W"}</span>
              </button>
            ))}
          </div>
        </div>

        {/* 2. 10 Fans Grid */}
        <div className="space-y-2">
          <div className="flex justify-between text-xs font-mono">
            <span className="text-slate-300 font-bold flex items-center gap-1.5">
              <Fan className="w-4 h-4 text-cyan-400" />
              10 CEILING FANS (75W each):
            </span>
            <span className="text-cyan-400 font-bold">
              {currentFloorState.activeFansCount} ON ({floorUsage.fansW} W)
            </span>
          </div>

          <div className="grid grid-cols-2 sm:grid-cols-5 md:grid-cols-10 gap-2">
            {currentFloorState.fans.map((isOn, idx) => (
              <button
                key={idx}
                onClick={() => toggleSingleFan(currentFloorObj.id, idx)}
                className={`p-2.5 rounded-xl border flex flex-col items-center justify-center gap-1 transition cursor-pointer ${
                  isOn
                    ? "bg-cyan-500/20 border-cyan-500/70 text-cyan-300 shadow-sm shadow-cyan-500/20 scale-105"
                    : "bg-slate-950 border-slate-800 text-slate-600 hover:border-slate-700"
                }`}
              >
                <Fan className={`w-4 h-4 ${isOn ? 'text-cyan-400 animate-spin' : 'text-slate-600'}`} />
                <span className="text-[10px] font-mono font-bold">Fan {idx + 1}</span>
                <span className="text-[9px] font-mono">{isOn ? "75W" : "0W"}</span>
              </button>
            ))}
          </div>
        </div>

        {/* 3. 5 AC Units Grid */}
        <div className="space-y-2">
          <div className="flex justify-between text-xs font-mono">
            <span className="text-slate-300 font-bold flex items-center gap-1.5">
              <Zap className="w-4 h-4 text-blue-400" />
              5 SPLIT AC UNITS (2000W / 2kW each):
            </span>
            <span className="text-blue-400 font-bold">
              {currentFloorState.activeAcsCount} ON ({floorUsage.acsW.toLocaleString()} W)
            </span>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-5 gap-3">
            {currentFloorState.acs.map((isOn, idx) => (
              <button
                key={idx}
                onClick={() => toggleSingleAc(currentFloorObj.id, idx)}
                className={`p-3.5 rounded-xl border flex flex-col items-start justify-between gap-2 transition cursor-pointer ${
                  isOn
                    ? "bg-blue-950/40 border-blue-500/80 text-blue-200 shadow-md shadow-blue-500/20"
                    : "bg-slate-950 border-slate-800 text-slate-500 hover:border-slate-700"
                }`}
              >
                <div className="flex items-center justify-between w-full">
                  <span className="font-bold text-xs font-mono">AC Unit #{idx + 1}</span>
                  <span
                    className={`text-[9px] font-mono px-1.5 py-0.5 rounded font-bold ${
                      isOn ? "bg-blue-500 text-black" : "bg-slate-900 text-slate-500"
                    }`}
                  >
                    {isOn ? "ONLINE" : "STANDBY"}
                  </span>
                </div>
                <div className="text-base font-black font-mono">
                  {isOn ? "2,000 W (2 kW)" : "0 W"}
                </div>
                <span className="text-[10px] text-slate-400">
                  {isOn ? "Cooling at 24°C" : "Power Off"}
                </span>
              </button>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}
