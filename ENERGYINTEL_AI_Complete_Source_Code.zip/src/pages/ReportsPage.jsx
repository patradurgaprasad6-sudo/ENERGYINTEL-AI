import React, { useState } from "react";
import {
  FileText,
  Download,
  Printer,
  Sparkles,
  CheckCircle2,
  Calendar,
  Building2,
  Coins,
  Leaf,
  Zap,
  ShieldCheck
} from "lucide-react";
import { useEnergy } from "../context/EnergyContext";
import { exportSimulationDataset, export1HourSecondTelemetry } from "../services/exportUtils";

export function ReportsPage() {
  const {
    todayEnergyKWh,
    predictedTomorrowKWh,
    potentialWastageKWh,
    potentialSavingsINR,
    estimatedCostINR,
    energyEfficiencyPct,
    carbonEmissionKg,
    sustainabilityScore,
    recommendations,
    tariffINR
  } = useEnergy();

  const [activeReportType, setActiveReportType] = useState("energy"); // "energy" | "wastage" | "prediction" | "sustainability"
  const [reportDate, setReportDate] = useState("2026-10-08");

  const handlePrint = () => {
    window.print();
  };

  const reportsList = [
    { id: "energy", title: "Comprehensive Campus Energy Audit Report", sub: "Daily & hourly consumption profiles" },
    { id: "wastage", title: "AI Inefficiency & Wastage Assessment", sub: "5 core case isolation and root cause logs" },
    { id: "prediction", title: "Predictive Demand & Peak Shaving Forecast", sub: "Multivariate regression horizons" },
    { id: "sustainability", title: "ESG & Carbon Sustainability Scorecard", sub: "Scope 2 grid emissions & GRI alignment" }
  ];

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 p-5 rounded-2xl bg-gradient-to-r from-blue-950/50 via-slate-900 to-indigo-950/50 border border-blue-500/30 print:hidden">
        <div>
          <div className="flex items-center gap-2">
            <span className="px-2.5 py-0.5 rounded-full bg-blue-950 border border-blue-700 text-blue-300 font-mono text-[10px] font-bold uppercase tracking-wider">
              FACILITY DOCUMENTATION
            </span>
            <span className="text-xs text-blue-300">
              Executive Briefings & PDF Generation
            </span>
          </div>
          <h1 className="text-2xl font-black text-white mt-1">
            Campus Energy Reports & Executive Briefings
          </h1>
          <p className="text-xs text-slate-300 mt-0.5">
            Generate printable executive audits, tariff reconciliation summaries, and board-ready sustainability dossiers.
          </p>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={() => export1HourSecondTelemetry("excel")}
            className="px-3.5 py-2 rounded-xl bg-emerald-500/20 hover:bg-emerald-500/30 text-emerald-300 border border-emerald-500/50 text-xs font-bold font-mono flex items-center gap-1.5 cursor-pointer transition shadow-md shadow-emerald-500/20"
          >
            <Download className="w-4 h-4 text-emerald-400" />
            <span>Export 1-Hr Excel (.xls)</span>
          </button>
          <button
            onClick={handlePrint}
            className="px-4 py-2 rounded-xl bg-cyan-500 hover:bg-cyan-400 text-black font-bold text-xs uppercase tracking-wider flex items-center gap-1.5 cursor-pointer shadow-lg shadow-cyan-500/20"
          >
            <Printer className="w-4 h-4" />
            <span>Print / Save PDF</span>
          </button>
        </div>
      </div>

      {/* Report Selector Tabs (Print Hidden) */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3 print:hidden">
        {reportsList.map((rep) => (
          <button
            key={rep.id}
            onClick={() => setActiveReportType(rep.id)}
            className={`p-4 rounded-xl border text-left transition cursor-pointer ${
              activeReportType === rep.id
                ? "bg-slate-900 border-cyan-400 shadow-lg shadow-cyan-500/10"
                : "bg-[#0b1329] border-slate-800 text-slate-400 hover:text-white"
            }`}
          >
            <span className="text-xs font-bold text-white block">{rep.title}</span>
            <span className="text-[11px] text-slate-400 mt-1 block">{rep.sub}</span>
          </button>
        ))}
      </div>

      {/* Formatted Printable Report Paper Document */}
      <div className="p-8 rounded-2xl bg-[#090e1c] border border-slate-700/80 shadow-2xl space-y-6 text-slate-200 font-sans print:border-none print:p-0 print:bg-white print:text-black">
        {/* Document Header */}
        <div className="flex items-start justify-between border-b border-slate-700 pb-4">
          <div>
            <div className="text-xs font-mono font-bold text-cyan-400 uppercase tracking-wider print:text-blue-700">
              TRIDENT CAMPUS ENERGY OPERATIONS CENTER
            </div>
            <h2 className="text-xl font-black text-white mt-1 print:text-black">
              {reportsList.find(r => r.id === activeReportType)?.title}
            </h2>
            <div className="text-xs text-slate-400 mt-1 font-mono print:text-gray-600">
              Date: {reportDate} • Generated by: ENERGYINTEL AI v2.4 Enterprise
            </div>
          </div>

          <div className="text-right">
            <span className="text-xs font-mono px-2.5 py-1 rounded-full bg-cyan-950 border border-cyan-800 text-cyan-300 font-bold print:bg-gray-100 print:text-black">
              STATUS: AUDITED
            </span>
            <div className="text-[11px] text-slate-400 font-mono mt-1 print:text-gray-600">
              Tariff Benchmark: ₹{tariffINR}/kWh
            </div>
          </div>
        </div>

        {/* Executive Summary Metrics Grid */}
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
          <div className="p-3.5 rounded-xl bg-slate-950 border border-slate-800 print:border-gray-300 print:bg-gray-50">
            <span className="text-[10px] uppercase font-mono text-slate-400 print:text-gray-600">Daily Total Energy</span>
            <div className="text-xl font-black text-white font-mono mt-0.5 print:text-black">
              {todayEnergyKWh.toLocaleString()} kWh
            </div>
          </div>

          <div className="p-3.5 rounded-xl bg-slate-950 border border-slate-800 print:border-gray-300 print:bg-gray-50">
            <span className="text-[10px] uppercase font-mono text-slate-400 print:text-gray-600">Potential Wastage</span>
            <div className="text-xl font-black text-rose-400 font-mono mt-0.5 print:text-red-600">
              {potentialWastageKWh} kWh
            </div>
          </div>

          <div className="p-3.5 rounded-xl bg-slate-950 border border-slate-800 print:border-gray-300 print:bg-gray-50">
            <span className="text-[10px] uppercase font-mono text-slate-400 print:text-gray-600">Potential Savings</span>
            <div className="text-xl font-black text-emerald-400 font-mono mt-0.5 print:text-green-700">
              ₹{potentialSavingsINR.toLocaleString()} / day
            </div>
          </div>

          <div className="p-3.5 rounded-xl bg-slate-950 border border-slate-800 print:border-gray-300 print:bg-gray-50">
            <span className="text-[10px] uppercase font-mono text-slate-400 print:text-gray-600">Campus Eco Score</span>
            <div className="text-xl font-black text-cyan-400 font-mono mt-0.5 print:text-blue-700">
              {sustainabilityScore} / 100
            </div>
          </div>
        </div>

        {/* Executive Findings Section */}
        <div className="space-y-3">
          <h3 className="text-sm font-bold text-white uppercase font-mono print:text-black border-b border-slate-800 pb-1">
            Executive Summary & AI Diagnoses
          </h3>
          <p className="text-xs leading-relaxed text-slate-300 print:text-gray-800">
            Trident Campus electricity utilization during the audit period exhibited high overall efficiency in Block A (91%), but significant localized thermal overcooling in Block B Floor 2. HVAC equipment in empty engineering labs consumed 34.2 kWh in excess of normal baseline. Applying the prioritized automated setpoint adjustments will recover ₹1,488 per day while abating 152.5 kg of Scope 2 carbon dioxide daily.
          </p>
        </div>

        {/* Recommendations Action Table in Report */}
        <div className="space-y-3">
          <h3 className="text-sm font-bold text-white uppercase font-mono print:text-black border-b border-slate-800 pb-1">
            Action Items for Facility Management
          </h3>
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs font-mono">
              <thead>
                <tr className="border-b border-slate-800 text-slate-400 uppercase text-[10px] print:text-black print:border-gray-300">
                  <th className="py-2">Item</th>
                  <th className="py-2">Zone</th>
                  <th className="py-2">Prescribed Action</th>
                  <th className="py-2">Energy Saved</th>
                  <th className="py-2 text-right">Cost Savings</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-800/60 print:divide-gray-200">
                {recommendations.slice(0, 4).map((rec, idx) => (
                  <tr key={idx}>
                    <td className="py-2 font-semibold text-white print:text-black">{rec.title}</td>
                    <td className="py-2 text-slate-400 print:text-gray-600">{rec.building} — {rec.floor}</td>
                    <td className="py-2 text-slate-300 print:text-gray-800">{rec.action}</td>
                    <td className="py-2 text-emerald-400 print:text-green-700">+{rec.energySavingKWh} kWh/d</td>
                    <td className="py-2 text-right text-cyan-400 font-bold print:text-blue-700">₹{rec.costSavingINR}/d</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>

        {/* Verification Sign-Off */}
        <div className="pt-6 border-t border-slate-800 flex justify-between items-end text-xs text-slate-400 print:text-gray-600 font-mono">
          <div>
            <div>System Verification: ENERGYINTEL AI Engine (Verified Demonstration)</div>
            <div>Facility Director Sign-Off: ____________________</div>
          </div>
          <div className="text-right">
            Page 1 of 1 • Internal Facility Record
          </div>
        </div>
      </div>
    </div>
  );
}
