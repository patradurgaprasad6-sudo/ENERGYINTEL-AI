import React, { useState, useMemo } from "react";
import {
  Sliders,
  Sparkles,
  Zap,
  Coins,
  Leaf,
  RotateCcw,
  TrendingDown,
  CheckCircle2,
  Thermometer,
  Users,
  Lightbulb,
  Cpu,
  Fan
} from "lucide-react";
import { useEnergy } from "../context/EnergyContext";

export function WhatIfSimulatorPage() {
  const { tariffINR } = useEnergy();

  // Slider State (Requirement 32)
  const [occupancy, setOccupancy] = useState(75); // 0 - 100%
  const [temperature, setTemperature] = useState(32); // 15 - 45°C
  const [acUsage, setAcUsage] = useState(80); // 0 - 100%
  const [lighting, setLighting] = useState(70); // 0 - 100%
  const [equipment, setEquipment] = useState(65); // 0 - 100%

  // Reset to default
  const resetSliders = () => {
    setOccupancy(75);
    setTemperature(32);
    setAcUsage(80);
    setLighting(70);
    setEquipment(65);
  };

  // Calculations: Current Scenario based on raw user sliders
  const currentScenario = useMemo(() => {
    // Formula for current energy draw:
    // Baseload ~350 kWh + AC burden + lighting + equipment + occupancy scaling
    const tempBurden = Math.max(0, temperature - 22) * 22; // cooling burden above 22C
    const acEnergy = (acUsage / 100) * 580 * (1 + (tempBurden / 400));
    const lightingEnergy = (lighting / 100) * 260;
    const equipEnergy = (equipment / 100) * 320;
    const occFactor = (occupancy / 100) * 180;

    const totalKWh = Math.round(220 + acEnergy + lightingEnergy + equipEnergy + occFactor);
    const costINR = Math.round(totalKWh * tariffINR);
    const co2Kg = Number((totalKWh * 0.82).toFixed(1));

    return { totalKWh, costINR, co2Kg };
  }, [occupancy, temperature, acUsage, lighting, equipment, tariffINR]);

  // Calculations: Optimized Scenario (AI setpoints applied: 24°C eco-lock, PIR lighting cutoffs, smart plug shutdown)
  const optimizedScenario = useMemo(() => {
    // Optimized AC: setpoint capped at 24°C, dynamic throttling with occupancy
    const optAcUsage = (acUsage * (occupancy / 100) * 0.72);
    const tempBurden = Math.max(0, temperature - 24) * 16;
    const optAcEnergy = (optAcUsage / 100) * 440 * (1 + (tempBurden / 400));

    // Optimized Lighting: daylight harvesting & PIR saves 28%
    const optLightingEnergy = (lighting / 100) * 260 * 0.72;

    // Optimized Equipment: smart standby cutoffs save 20%
    const optEquipEnergy = (equipment / 100) * 320 * 0.80;
    const occFactor = (occupancy / 100) * 140;

    const totalKWh = Math.round(200 + optAcEnergy + optLightingEnergy + optEquipEnergy + occFactor);
    const costINR = Math.round(totalKWh * tariffINR);
    const co2Kg = Number((totalKWh * 0.82).toFixed(1));

    return { totalKWh, costINR, co2Kg };
  }, [occupancy, temperature, acUsage, lighting, equipment, tariffINR]);

  // Potential savings difference
  const savings = {
    kwh: Math.max(0, currentScenario.totalKWh - optimizedScenario.totalKWh),
    costINR: Math.max(0, currentScenario.costINR - optimizedScenario.costINR),
    co2Kg: Number(Math.max(0, currentScenario.co2Kg - optimizedScenario.co2Kg).toFixed(1)),
    pct: Math.round(((currentScenario.totalKWh - optimizedScenario.totalKWh) / currentScenario.totalKWh) * 100) || 16
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 p-5 rounded-2xl bg-gradient-to-r from-blue-950/50 via-slate-900 to-indigo-950/50 border border-blue-500/30">
        <div>
          <div className="flex items-center gap-2">
            <span className="px-2.5 py-0.5 rounded-full bg-blue-950 border border-blue-700 text-blue-300 font-mono text-[10px] font-bold uppercase tracking-wider">
              DYNAMIC ENERGY SIMULATION
            </span>
            <span className="text-xs text-blue-300">
              Interactive What-If Scenario Modeler
            </span>
          </div>
          <h1 className="text-2xl font-black text-white mt-1">
            What-If Campus Energy Simulator
          </h1>
          <p className="text-xs text-slate-300 mt-0.5">
            Test policy changes, heatwave scenarios, or occupancy fluctuations to preview exact savings before physical execution.
          </p>
        </div>

        <button
          onClick={resetSliders}
          className="px-3.5 py-2 rounded-xl bg-slate-800 text-slate-300 hover:text-white text-xs font-semibold flex items-center gap-1.5 cursor-pointer"
        >
          <RotateCcw className="w-3.5 h-3.5" />
          <span>Reset Sliders</span>
        </button>
      </div>

      {/* Main Grid: Controls vs Comparison Result */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Left Column: Interactive Sliders (5 cols) */}
        <div className="lg:col-span-5 bg-[#0b1329] border border-slate-800 rounded-2xl p-6 shadow-xl space-y-5">
          <div className="flex items-center justify-between border-b border-slate-800 pb-3">
            <h2 className="text-base font-bold text-white flex items-center gap-2">
              <Sliders className="w-4 h-4 text-cyan-400" />
              <span>Campus Parameter Sliders</span>
            </h2>
            <span className="text-[11px] font-mono text-cyan-300">Configurable</span>
          </div>

          {/* Slider 1: Occupancy (0 - 100%) */}
          <div className="space-y-2">
            <div className="flex justify-between text-xs">
              <span className="text-slate-300 font-semibold flex items-center gap-1.5">
                <Users className="w-3.5 h-3.5 text-cyan-400" /> Campus Occupancy
              </span>
              <span className="font-mono text-cyan-400 font-bold">{occupancy}%</span>
            </div>
            <input
              type="range"
              min="0"
              max="100"
              value={occupancy}
              onChange={(e) => setOccupancy(Number(e.target.value))}
              className="w-full h-1.5 bg-slate-800 rounded-lg appearance-none cursor-pointer accent-cyan-400"
            />
            <div className="flex justify-between text-[10px] text-slate-500 font-mono">
              <span>0% (Empty Campus)</span>
              <span>100% (Peak Capacity)</span>
            </div>
          </div>

          {/* Slider 2: Ambient Temperature (15 - 45°C) */}
          <div className="space-y-2">
            <div className="flex justify-between text-xs">
              <span className="text-slate-300 font-semibold flex items-center gap-1.5">
                <Thermometer className="w-3.5 h-3.5 text-orange-400" /> Ambient Temperature
              </span>
              <span className="font-mono text-orange-400 font-bold">{temperature}°C</span>
            </div>
            <input
              type="range"
              min="15"
              max="45"
              value={temperature}
              onChange={(e) => setTemperature(Number(e.target.value))}
              className="w-full h-1.5 bg-slate-800 rounded-lg appearance-none cursor-pointer accent-orange-400"
            />
            <div className="flex justify-between text-[10px] text-slate-500 font-mono">
              <span>15°C (Winter)</span>
              <span>45°C (Summer Heatwave)</span>
            </div>
          </div>

          {/* Slider 3: AC Usage (0 - 100%) */}
          <div className="space-y-2">
            <div className="flex justify-between text-xs">
              <span className="text-slate-300 font-semibold flex items-center gap-1.5">
                <Fan className="w-3.5 h-3.5 text-blue-400" /> AC / HVAC Duty Cycle
              </span>
              <span className="font-mono text-blue-400 font-bold">{acUsage}%</span>
            </div>
            <input
              type="range"
              min="0"
              max="100"
              value={acUsage}
              onChange={(e) => setAcUsage(Number(e.target.value))}
              className="w-full h-1.5 bg-slate-800 rounded-lg appearance-none cursor-pointer accent-blue-400"
            />
            <div className="flex justify-between text-[10px] text-slate-500 font-mono">
              <span>0% (All Off)</span>
              <span>100% (Continuous Chilling)</span>
            </div>
          </div>

          {/* Slider 4: Lighting (0 - 100%) */}
          <div className="space-y-2">
            <div className="flex justify-between text-xs">
              <span className="text-slate-300 font-semibold flex items-center gap-1.5">
                <Lightbulb className="w-3.5 h-3.5 text-yellow-400" /> Lighting Circuit Load
              </span>
              <span className="font-mono text-yellow-400 font-bold">{lighting}%</span>
            </div>
            <input
              type="range"
              min="0"
              max="100"
              value={lighting}
              onChange={(e) => setLighting(Number(e.target.value))}
              className="w-full h-1.5 bg-slate-800 rounded-lg appearance-none cursor-pointer accent-yellow-400"
            />
            <div className="flex justify-between text-[10px] text-slate-500 font-mono">
              <span>0% (Natural Daylight)</span>
              <span>100% (All Fixtures Active)</span>
            </div>
          </div>

          {/* Slider 5: Equipment Load (0 - 100%) */}
          <div className="space-y-2">
            <div className="flex justify-between text-xs">
              <span className="text-slate-300 font-semibold flex items-center gap-1.5">
                <Cpu className="w-3.5 h-3.5 text-purple-400" /> Lab & Office Equipment
              </span>
              <span className="font-mono text-purple-400 font-bold">{equipment}%</span>
            </div>
            <input
              type="range"
              min="0"
              max="100"
              value={equipment}
              onChange={(e) => setEquipment(Number(e.target.value))}
              className="w-full h-1.5 bg-slate-800 rounded-lg appearance-none cursor-pointer accent-purple-400"
            />
            <div className="flex justify-between text-[10px] text-slate-500 font-mono">
              <span>0% (Standby Off)</span>
              <span>100% (High Compute Draw)</span>
            </div>
          </div>
        </div>

        {/* Right Column: Comparative Side-by-Side (7 cols) (Requirement 32) */}
        <div className="lg:col-span-7 space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {/* CURRENT SCENARIO CARD */}
            <div className="p-6 rounded-2xl bg-gradient-to-br from-slate-900 to-[#10172a] border border-slate-700/80 shadow-xl space-y-4">
              <div className="flex items-center justify-between">
                <span className="text-xs font-mono font-bold text-slate-400 uppercase tracking-wider">
                  CURRENT SCENARIO
                </span>
                <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-slate-800 text-slate-300">
                  Unmanaged Baseline
                </span>
              </div>

              <div className="space-y-3">
                <div className="p-3 rounded-xl bg-slate-950/80 border border-slate-800">
                  <span className="text-xs text-slate-400">Projected Daily Energy</span>
                  <div className="text-2xl font-black text-white font-mono mt-0.5">
                    {currentScenario.totalKWh.toLocaleString()} kWh
                  </div>
                </div>

                <div className="p-3 rounded-xl bg-slate-950/80 border border-slate-800">
                  <span className="text-xs text-slate-400">Electricity Billing Cost</span>
                  <div className="text-2xl font-black text-rose-400 font-mono mt-0.5">
                    ₹{currentScenario.costINR.toLocaleString()}
                  </div>
                  <span className="text-[10px] text-slate-500">at ₹{tariffINR}/kWh</span>
                </div>

                <div className="p-3 rounded-xl bg-slate-950/80 border border-slate-800">
                  <span className="text-xs text-slate-400">Carbon Footprint</span>
                  <div className="text-lg font-bold text-slate-300 font-mono mt-0.5">
                    {currentScenario.co2Kg.toLocaleString()} kg CO₂
                  </div>
                </div>
              </div>
            </div>

            {/* OPTIMIZED SCENARIO CARD */}
            <div className="p-6 rounded-2xl bg-gradient-to-br from-emerald-950/40 via-slate-900 to-cyan-950/40 border-2 border-emerald-500/60 shadow-xl space-y-4">
              <div className="flex items-center justify-between">
                <span className="text-xs font-mono font-bold text-emerald-300 uppercase tracking-wider flex items-center gap-1.5">
                  <Sparkles className="w-3.5 h-3.5 text-emerald-400" />
                  OPTIMIZED SCENARIO
                </span>
                <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-emerald-900/60 text-emerald-200 border border-emerald-700">
                  AI Setpoints
                </span>
              </div>

              <div className="space-y-3">
                <div className="p-3 rounded-xl bg-slate-950/80 border border-emerald-900/60">
                  <span className="text-xs text-slate-400">Optimized Daily Energy</span>
                  <div className="text-2xl font-black text-emerald-400 font-mono mt-0.5">
                    {optimizedScenario.totalKWh.toLocaleString()} kWh
                  </div>
                </div>

                <div className="p-3 rounded-xl bg-slate-950/80 border border-emerald-900/60">
                  <span className="text-xs text-slate-400">Optimized Billing Cost</span>
                  <div className="text-2xl font-black text-cyan-400 font-mono mt-0.5">
                    ₹{optimizedScenario.costINR.toLocaleString()}
                  </div>
                  <span className="text-[10px] text-slate-500">at ₹{tariffINR}/kWh</span>
                </div>

                <div className="p-3 rounded-xl bg-slate-950/80 border border-emerald-900/60">
                  <span className="text-xs text-slate-400">Reduced Carbon</span>
                  <div className="text-lg font-bold text-teal-300 font-mono mt-0.5">
                    {optimizedScenario.co2Kg.toLocaleString()} kg CO₂
                  </div>
                </div>
              </div>
            </div>
          </div>

          {/* POTENTIAL SAVINGS SUMMARY BANNER (Requirement 32) */}
          <div className="p-5 rounded-2xl bg-gradient-to-r from-emerald-900/60 to-teal-900/40 border border-emerald-400/60 shadow-xl flex flex-col sm:flex-row items-center justify-between gap-4">
            <div className="space-y-1 text-center sm:text-left">
              <span className="text-xs font-mono font-bold text-emerald-300 uppercase tracking-wider">
                POTENTIAL OPTIMIZATION SAVING
              </span>
              <div className="text-2xl sm:text-3xl font-black text-white font-mono flex items-center justify-center sm:justify-start gap-2">
                <span>{savings.kwh} kWh</span>
                <span className="text-lg text-emerald-300 font-normal">/ day</span>
                <span className="text-xs font-bold px-2 py-0.5 rounded-full bg-emerald-500 text-black ml-1">
                  -{savings.pct}%
                </span>
              </div>
              <p className="text-xs text-emerald-200">
                Direct Cost Savings: <strong className="text-white font-mono">₹{savings.costINR.toLocaleString()} / day</strong> (₹{(savings.costINR * 30).toLocaleString()} monthly)
              </p>
            </div>

            <div className="flex flex-col items-center sm:items-end">
              <div className="text-sm font-bold text-teal-300 font-mono">
                -{savings.co2Kg} kg CO₂ / day
              </div>
              <span className="text-[10px] text-teal-200">
                GRI / ESG Scope 2 avoidance
              </span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
