import React from "react";
import {
  Network,
  Database,
  Cpu,
  Brain,
  Lightbulb,
  Bell,
  Coins,
  Leaf,
  Zap,
  ArrowDown,
  Layers,
  CheckCircle2,
  Sliders
} from "lucide-react";

export function SystemArchitecturePage() {
  const layers = [
    {
      number: 1,
      name: "DATA LAYER",
      color: "from-cyan-500 to-blue-600",
      border: "border-cyan-500/40",
      icon: Database,
      title: "Data Collection & Ingestion (Simulated & External Streams)",
      items: [
        "Simulated Sensor-Data Engine (Voltage, Current, Power Factor, Power)",
        "Environmental Context Telemetry (Indoor & Outdoor Temp, Heat Index)",
        "Occupancy Detection Streams (PIR motion & optical headcount)",
        "Equipment Status Telemetry (AC VRF duty cycle, Lighting circuits)",
        "Historical CSV / Excel Bulk Telemetry Ingestion"
      ]
    },
    {
      number: 2,
      name: "PROCESSING LAYER",
      color: "from-blue-600 to-indigo-600",
      border: "border-blue-500/40",
      icon: Cpu,
      title: "Cleaning, Normalization & Statistical Validation",
      items: [
        "Missing Data Imputation & Sensor Drift Filtering",
        "3-Phase Electrical Line Balancing & Power Factor Verification",
        "Outlier Boundary Tagging (IQR & 3-Sigma z-score thresholds)",
        "Degree-Day Thermodynamic Cooling Degree Baseline Normalization"
      ]
    },
    {
      number: 3,
      name: "AI LAYER",
      color: "from-purple-600 to-pink-600",
      border: "border-purple-500/40",
      icon: Brain,
      title: "Predictive Forecasting & Anomaly Detection",
      items: [
        "Multivariate Time-Series Autoregression (Hourly, 24h, 7d horizons)",
        "Thermodynamic Degree-Day Regression Model",
        "Dynamic Baseline Envelope Modeling & Statistical Threshold Tracking",
        "Peak Demand Coincident Window Predictor (13:00 - 15:00)"
      ]
    },
    {
      number: 4,
      name: "INTELLIGENCE LAYER",
      color: "from-amber-500 to-orange-600",
      border: "border-amber-500/40",
      icon: Lightbulb,
      title: "Wastage Isolation & Root Cause Synthesis",
      items: [
        "Case 1 Isolation: Lights ON + Zero Occupancy in vacant spaces",
        "Case 2 Isolation: AC Chilling at 18°C with < 30% Room Occupancy",
        "Case 3 Isolation: After-Hours Lab & Plug Load Draw (22:00+)",
        "Case 4 Isolation: Sudden +56% Compressor Spike / Locked Rotor",
        "Case 5 Isolation: Weekend Idle Inefficiency in auditoriums",
        "NLP Complaint Correlation & Spatial Hotspot Clustering"
      ]
    },
    {
      number: 5,
      name: "ACTION LAYER",
      color: "from-emerald-500 to-teal-600",
      border: "border-emerald-500/40",
      icon: Bell,
      title: "Prescriptive Recommendations & Incident Dispatch",
      items: [
        "Algorithmic Prioritization (Max kWh & INR saving / implementation ease)",
        "Prescriptive Action Plan: Problem → Reason → Execution Action",
        "Automated Real-Time Critical Alerts dispatched to Operations Center",
        "Pre-Cooling Load Shifting Schedule Generation"
      ]
    },
    {
      number: 6,
      name: "IMPACT LAYER",
      color: "from-teal-400 to-green-500",
      border: "border-teal-500/40",
      icon: Leaf,
      title: "Financial ROI & ESG Carbon Accounting",
      items: [
        "Direct Electricity Billing Reduction (186 kWh/day → ₹1,488/day)",
        "Scope 2 Grid Emission Abatement (0.82 kg CO₂/kWh factor)",
        "Campus Sustainability Score Gauge (0–100 composite index)",
        "Executive PDF Briefings & Verifiable Audit Trail"
      ]
    }
  ];

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 p-5 rounded-2xl bg-gradient-to-r from-blue-950/50 via-slate-900 to-cyan-950/50 border border-blue-500/30">
        <div>
          <div className="flex items-center gap-2">
            <span className="px-2.5 py-0.5 rounded-full bg-blue-950 border border-blue-700 text-blue-300 font-mono text-[10px] font-bold uppercase tracking-wider">
              FULL-STACK TECHNICAL BLUEPRINT
            </span>
            <span className="text-xs text-blue-300">
              Enterprise 6-Layer Modular Architecture
            </span>
          </div>
          <h1 className="text-2xl font-black text-white mt-1">
            System Architecture: Data → AI → Insight → Action → Savings
          </h1>
          <p className="text-xs text-slate-300 mt-0.5">
            Transparent breakdown of data flow from physical/simulated sensors to prescriptive facility management actions.
          </p>
        </div>
      </div>

      {/* 6-Layer Architecture Pipeline (Requirement 45) */}
      <div className="space-y-4 max-w-4xl mx-auto">
        {layers.map((layer, idx) => {
          const Icon = layer.icon;
          return (
            <React.Fragment key={layer.number}>
              <div
                className={`p-6 rounded-2xl bg-[#0b1329] border ${layer.border} shadow-xl relative overflow-hidden`}
              >
                <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 border-b border-slate-800 pb-3">
                  <div className="flex items-center gap-3">
                    <div className={`p-2.5 rounded-xl bg-gradient-to-br ${layer.color} text-black font-bold`}>
                      <Icon className="w-5 h-5 text-white" />
                    </div>
                    <div>
                      <span className="text-[10px] font-mono font-bold text-slate-400 uppercase">
                        LAYER {layer.number}
                      </span>
                      <h2 className="text-base font-bold text-white">
                        {layer.name} — {layer.title}
                      </h2>
                    </div>
                  </div>
                </div>

                <div className="pt-3">
                  <ul className="grid grid-cols-1 md:grid-cols-2 gap-2 text-xs text-slate-300">
                    {layer.items.map((item, itemIdx) => (
                      <li key={itemIdx} className="flex items-start gap-2">
                        <CheckCircle2 className="w-3.5 h-3.5 text-cyan-400 flex-shrink-0 mt-0.5" />
                        <span>{item}</span>
                      </li>
                    ))}
                  </ul>
                </div>
              </div>

              {idx < layers.length - 1 && (
                <div className="flex justify-center py-1">
                  <div className="p-1 rounded-full bg-slate-900 border border-slate-800 text-slate-400">
                    <ArrowDown className="w-4 h-4 animate-bounce" />
                  </div>
                </div>
              )}
            </React.Fragment>
          );
        })}
      </div>
    </div>
  );
}
