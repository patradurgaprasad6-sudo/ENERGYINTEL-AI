import React, { useState } from "react";
import {
  Coins,
  Leaf,
  Zap,
  TrendingDown,
  ArrowRight,
  ShieldCheck,
  CheckCircle2,
  TreePine,
  Car,
  Home,
  SlidersHorizontal
} from "lucide-react";
import { useEnergy } from "../context/EnergyContext";

export function CostCarbonPage() {
  const {
    tariffINR,
    setTariffINR,
    todayEnergyKWh,
    potentialWastageKWh,
    potentialSavingsINR,
    estimatedCostINR,
    carbonEmissionKg,
    carbonSavingsKg,
    campusConfig
  } = useEnergy();

  const [inputTariff, setInputTariff] = useState(tariffINR);
  const [carbonFactor, setCarbonFactor] = useState(0.82); // CEA Grid Emission Factor in India

  // Periodic metrics
  const dailyCost = Math.round(todayEnergyKWh * tariffINR);
  const weeklyCost = Math.round(todayEnergyKWh * 7 * tariffINR);
  const monthlyCost = Math.round(todayEnergyKWh * 30 * tariffINR);

  const wastedDailyCost = Math.round(potentialWastageKWh * tariffINR);
  const wastedWeeklyCost = Math.round(potentialWastageKWh * 7 * tariffINR);
  const wastedMonthlyCost = Math.round(potentialWastageKWh * 30 * tariffINR);

  // Carbon metrics
  const dailyCO2 = Number((todayEnergyKWh * carbonFactor).toFixed(1));
  const monthlyCO2Tonnes = Number(((todayEnergyKWh * 30 * carbonFactor) / 1000).toFixed(2));
  const monthlyCO2SavedTonnes = Number(((potentialWastageKWh * 30 * carbonFactor) / 1000).toFixed(2));

  // Equivalencies
  const treesEquivalent = Math.round((potentialWastageKWh * 365 * carbonFactor) / 22); // ~22kg CO2 per tree per year
  const carKmEquivalent = Math.round((potentialWastageKWh * 30 * carbonFactor) / 0.12); // ~120g CO2 per km

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 p-5 rounded-2xl bg-gradient-to-r from-emerald-950/50 via-slate-900 to-cyan-950/50 border border-emerald-500/30">
        <div>
          <div className="flex items-center gap-2">
            <span className="px-2.5 py-0.5 rounded-full bg-emerald-950 border border-emerald-700 text-emerald-300 font-mono text-[10px] font-bold uppercase tracking-wider">
              FINANCIAL & ESG ACCOUNTING
            </span>
            <span className="text-xs text-emerald-300">
              India Grid CEA 0.82 Factor
            </span>
          </div>
          <h1 className="text-2xl font-black text-white mt-1">
            Cost & Carbon Emission Intelligence
          </h1>
          <p className="text-xs text-slate-300 mt-0.5">
            Transparently translating every saved kilowatt-hour into verifiable financial capital and Scope 2 carbon abatement.
          </p>
        </div>

        {/* Highlight ROI Pill */}
        <div className="p-4 rounded-xl bg-slate-900/90 border border-emerald-500/40 text-right min-w-[210px]">
          <span className="text-[10px] text-slate-400 font-mono uppercase">Annual Potential Savings</span>
          <div className="text-2xl font-black text-emerald-400 font-mono mt-0.5">
            ₹{(wastedDailyCost * 365).toLocaleString()}
          </div>
          <span className="text-xs text-teal-300 font-mono">
            {Number(((potentialWastageKWh * 365 * carbonFactor) / 1000).toFixed(1))} Tonnes CO₂ / year
          </span>
        </div>
      </div>

      {/* The Core Methodology Pipeline Card (Requirement 30: ENERGY SAVED → COST SAVED → CO₂ REDUCED) */}
      <div className="p-6 rounded-2xl bg-[#0b1329] border border-cyan-500/40 shadow-xl space-y-4">
        <span className="text-xs font-mono font-bold text-cyan-400 uppercase tracking-wider">
          THE THREE-TIER IMPACT PIPELINE
        </span>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 items-center">
          {/* Box 1: Energy Saved */}
          <div className="p-4 rounded-xl bg-slate-950 border border-cyan-800/80 text-center space-y-1">
            <div className="w-10 h-10 rounded-full bg-cyan-500/20 text-cyan-400 flex items-center justify-center mx-auto mb-2">
              <Zap className="w-5 h-5" />
            </div>
            <div className="text-xs text-slate-400 uppercase font-mono">ENERGY SAVED</div>
            <div className="text-2xl font-black text-white font-mono">{potentialWastageKWh} kWh</div>
            <div className="text-[11px] text-slate-400">Avoidable daily waste</div>
          </div>

          {/* Box 2: Cost Saved */}
          <div className="p-4 rounded-xl bg-slate-950 border border-emerald-800/80 text-center space-y-1">
            <div className="w-10 h-10 rounded-full bg-emerald-500/20 text-emerald-400 flex items-center justify-center mx-auto mb-2">
              <Coins className="w-5 h-5" />
            </div>
            <div className="text-xs text-slate-400 uppercase font-mono">COST SAVED</div>
            <div className="text-2xl font-black text-emerald-400 font-mono">₹{potentialSavingsINR}</div>
            <div className="text-[11px] text-slate-400">@ ₹{tariffINR}/kWh daily bill reduction</div>
          </div>

          {/* Box 3: CO2 Reduced */}
          <div className="p-4 rounded-xl bg-slate-950 border border-teal-800/80 text-center space-y-1">
            <div className="w-10 h-10 rounded-full bg-teal-500/20 text-teal-400 flex items-center justify-center mx-auto mb-2">
              <Leaf className="w-5 h-5" />
            </div>
            <div className="text-xs text-slate-400 uppercase font-mono">CO₂ REDUCED</div>
            <div className="text-2xl font-black text-teal-400 font-mono">{carbonSavingsKg} kg</div>
            <div className="text-[11px] text-slate-400">Scope 2 emissions avoided daily</div>
          </div>
        </div>
      </div>

      {/* Financial Cost Breakdown & Editable Tariff Tool (Requirement 29) */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Left: Interactive Tariff Configurator (4 cols) */}
        <div className="lg:col-span-4 bg-[#0b1329] border border-slate-800 rounded-2xl p-5 shadow-xl space-y-4">
          <div className="flex items-center justify-between border-b border-slate-800 pb-2">
            <h2 className="text-sm font-bold text-white flex items-center gap-2">
              <Coins className="w-4 h-4 text-amber-400" />
              <span>Electricity Tariff Engine</span>
            </h2>
            <span className="text-[10px] font-mono text-cyan-400">Editable</span>
          </div>

          <p className="text-xs text-slate-400">
            Customize local utility tariff rate to immediately adjust all campus cost and savings calculations.
          </p>

          <div className="space-y-2">
            <label className="text-xs font-mono font-bold text-slate-300">
              COMMERCIAL RATE (₹ / kWh)
            </label>
            <div className="relative">
              <span className="absolute left-3 top-2 text-slate-400 font-mono">₹</span>
              <input
                type="number"
                step="0.5"
                value={inputTariff}
                onChange={(e) => {
                  const val = Number(e.target.value);
                  setInputTariff(val);
                  setTariffINR(val);
                }}
                className="w-full bg-slate-950 border border-slate-700 rounded-xl pl-8 pr-3 py-2 text-white font-mono font-bold text-sm focus:outline-none focus:border-cyan-400"
              />
            </div>
            <span className="text-[10px] text-slate-500 font-mono">
              Trident Campus Default: ₹8.00 / kWh
            </span>
          </div>

          <div className="space-y-2 pt-2 border-t border-slate-800">
            <label className="text-xs font-mono font-bold text-slate-300">
              GRID EMISSION FACTOR (kg CO₂ / kWh)
            </label>
            <input
              type="number"
              step="0.01"
              value={carbonFactor}
              onChange={(e) => setCarbonFactor(Number(e.target.value))}
              className="w-full bg-slate-950 border border-slate-700 rounded-xl px-3 py-2 text-white font-mono font-bold text-sm focus:outline-none focus:border-cyan-400"
            />
            <span className="text-[10px] text-slate-500 font-mono">
              CEA (Central Electricity Authority India): 0.82
            </span>
          </div>
        </div>

        {/* Right: Detailed Horizon Table & ROI (8 cols) */}
        <div className="lg:col-span-8 bg-[#0b1329] border border-slate-800 rounded-2xl p-5 shadow-xl space-y-4">
          <h2 className="text-sm font-bold text-white flex items-center gap-2 border-b border-slate-800 pb-2">
            <TrendingDown className="w-4 h-4 text-emerald-400" />
            <span>Electricity Bill & Wasted Energy Cost Projections</span>
          </h2>

          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs">
              <thead>
                <tr className="border-b border-slate-800 font-mono text-slate-400 uppercase text-[11px]">
                  <th className="py-2.5">Time Period</th>
                  <th className="py-2.5">Expected Consumption</th>
                  <th className="py-2.5">Campus Electricity Bill</th>
                  <th className="py-2.5">Wasted Energy Cost</th>
                  <th className="py-2.5 text-right">Potential Savings</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-800/60 font-mono">
                <tr>
                  <td className="py-3 font-semibold text-white">Daily (24h)</td>
                  <td className="py-3 text-slate-300">{todayEnergyKWh.toLocaleString()} kWh</td>
                  <td className="py-3 text-slate-200">₹{dailyCost.toLocaleString()}</td>
                  <td className="py-3 text-rose-400">₹{wastedDailyCost.toLocaleString()}</td>
                  <td className="py-3 text-right text-emerald-400 font-bold">₹{wastedDailyCost.toLocaleString()}</td>
                </tr>
                <tr>
                  <td className="py-3 font-semibold text-white">Weekly (7d)</td>
                  <td className="py-3 text-slate-300">{(todayEnergyKWh * 7).toLocaleString()} kWh</td>
                  <td className="py-3 text-slate-200">₹{weeklyCost.toLocaleString()}</td>
                  <td className="py-3 text-rose-400">₹{wastedWeeklyCost.toLocaleString()}</td>
                  <td className="py-3 text-right text-emerald-400 font-bold">₹{wastedWeeklyCost.toLocaleString()}</td>
                </tr>
                <tr>
                  <td className="py-3 font-semibold text-white">Monthly (30d)</td>
                  <td className="py-3 text-slate-300">{(todayEnergyKWh * 30).toLocaleString()} kWh</td>
                  <td className="py-3 text-slate-200">₹{monthlyCost.toLocaleString()}</td>
                  <td className="py-3 text-rose-400">₹{wastedMonthlyCost.toLocaleString()}</td>
                  <td className="py-3 text-right text-emerald-400 font-bold">₹{wastedMonthlyCost.toLocaleString()}</td>
                </tr>
              </tbody>
            </table>
          </div>
        </div>
      </div>

      {/* Sustainability Equivalencies (Trees, Cars, Homes) */}
      <div className="space-y-3">
        <h2 className="text-sm font-bold text-white flex items-center gap-2">
          <Leaf className="w-4 h-4 text-emerald-400" />
          <span>Real-World Environmental Equivalency Equivalents</span>
        </h2>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          <div className="p-4 rounded-xl bg-slate-900 border border-slate-800 flex items-center gap-3">
            <div className="p-3 rounded-xl bg-emerald-500/20 text-emerald-400">
              <TreePine className="w-6 h-6" />
            </div>
            <div>
              <span className="text-xs text-slate-400">Tree Carbon Sequestration</span>
              <div className="text-xl font-black text-white font-mono mt-0.5">
                {treesEquivalent.toLocaleString()} Trees
              </div>
              <span className="text-[10px] text-slate-500">Annual mature tree offset</span>
            </div>
          </div>

          <div className="p-4 rounded-xl bg-slate-900 border border-slate-800 flex items-center gap-3">
            <div className="p-3 rounded-xl bg-cyan-500/20 text-cyan-400">
              <Car className="w-6 h-6" />
            </div>
            <div>
              <span className="text-xs text-slate-400">Passenger Car Travel Avoided</span>
              <div className="text-xl font-black text-white font-mono mt-0.5">
                {carKmEquivalent.toLocaleString()} km
              </div>
              <span className="text-[10px] text-slate-500">Gasoline vehicle travel equivalent</span>
            </div>
          </div>

          <div className="p-4 rounded-xl bg-slate-900 border border-slate-800 flex items-center gap-3">
            <div className="p-3 rounded-xl bg-purple-500/20 text-purple-400">
              <Home className="w-6 h-6" />
            </div>
            <div>
              <span className="text-xs text-slate-400">Urban Households Powered</span>
              <div className="text-xl font-black text-white font-mono mt-0.5">
                18 Homes
              </div>
              <span className="text-[10px] text-slate-500">Powered solely by eliminated waste</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
