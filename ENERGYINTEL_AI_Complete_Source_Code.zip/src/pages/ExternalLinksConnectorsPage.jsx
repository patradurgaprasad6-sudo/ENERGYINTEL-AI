import React from "react";
import {
  ExternalLink,
  Radio,
  CloudSun,
  Cpu,
  BarChart4,
  Leaf,
  Network,
  Share2,
  Box,
  Database,
  Sliders,
  CheckCircle2,
  Sparkles
} from "lucide-react";

export function ExternalLinksConnectorsPage({ isStandalone = false }) {
  const externalConnectors = [
    {
      id: "posoco",
      title: "National Grid Real-Time Frequency (POSOCO / NLDC)",
      category: "Utility Grid Telemetry",
      url: "https://posoco.in",
      desc: "Live 50.00 Hz Indian National Power Grid frequency and regional inter-state transmission flow balancing.",
      status: "Active (50.02 Hz Synced)",
      badge: "GRID TELEMETRY"
    },
    {
      id: "weather",
      title: "Campus Microclimate Weather Radar (Open-Meteo API)",
      category: "Atmospheric Telemetry",
      url: "https://open-meteo.com",
      desc: "Hyperlocal ambient temperature, wet-bulb heat index, and Global Horizontal Irradiance (GHI) solar feed.",
      status: "Active (32.4°C Ambient)",
      badge: "WEATHER API"
    },
    {
      id: "bms",
      title: "BACnet / Modbus OpenBMS Gateway Protocol",
      category: "Industrial Facility Control",
      url: "https://bacnet.org",
      desc: "Standardized industrial fieldbus connector linking VRF chillers, AHUs, and variable frequency drives (VFD).",
      status: "Ready (Port 47808 BACnet/IP)",
      badge: "BMS PROTOCOL"
    },
    {
      id: "mqtt",
      title: "MQTT IoT Broker WebSockets Explorer (Eclipse Mosquitto)",
      category: "IoT Edge Telemetry",
      url: "https://test.mosquitto.org",
      desc: "Pub/Sub message broker streaming sub-second JSON telemetry packets from ESP32 energy meters.",
      status: "Connected (Topic: trident/telemetry/#)",
      badge: "MQTT STREAM"
    },
    {
      id: "grafana",
      title: "Grafana Enterprise Time-Series Visualizer",
      category: "Observability Metrics",
      url: "https://play.grafana.org",
      desc: "Deep metric dashboards and alert rules running on top of PromQL / TimescaleDB databases.",
      status: "Available (Dashboard 1024)",
      badge: "OBSERVABILITY"
    },
    {
      id: "ghg",
      title: "GHG Protocol Scope 2 Emissions Registry",
      category: "ESG & Carbon Accounting",
      url: "https://ghgprotocol.org",
      desc: "International Greenhouse Gas Protocol accounting standard for campus purchased electricity emissions.",
      status: "Compliant (CEA 0.82 Factor)",
      badge: "ESG REGISTRY"
    }
  ];

  const popoutTabs = [
    {
      name: "Campus Digital Twin 3D Studio",
      path: "/?view=digitaltwin",
      icon: Box,
      desc: "Isometric 2.5D visual campus wireframe and live node inspector in a dedicated browser window.",
      color: "from-cyan-500 to-blue-600"
    },
    {
      name: "Big Data Telemetry Lake & SQL Console",
      path: "/?view=bigdata",
      icon: Database,
      desc: "Timescale time-series data stream with SQL query execution in a separate window.",
      color: "from-blue-600 to-indigo-600"
    },
    {
      name: "Stress Testing & Scenario Simulator",
      path: "/?view=simulations",
      icon: Sliders,
      desc: "Fault injection and macro stress-test laboratory in an independent browser tab.",
      color: "from-purple-600 to-pink-600"
    },
    {
      name: "Printable Executive Energy Audits",
      path: "/?view=reports",
      icon: BarChart4,
      desc: "Boardroom-ready documentation and printable PDF export workspace.",
      color: "from-emerald-500 to-teal-600"
    }
  ];

  const handlePopout = (path) => {
    window.open(`${window.location.origin}${path}`, "_blank");
  };

  return (
    <div className={`space-y-6 ${isStandalone ? 'p-6 max-w-7xl mx-auto' : ''}`}>
      {/* Header */}
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 p-5 rounded-2xl bg-gradient-to-r from-cyan-950/60 via-slate-900 to-blue-950/50 border border-cyan-500/40 shadow-xl">
        <div>
          <div className="flex items-center gap-2">
            <span className="px-2.5 py-0.5 rounded-full bg-cyan-950 border border-cyan-700 text-cyan-300 font-mono text-[10px] font-bold uppercase tracking-wider flex items-center gap-1.5">
              <Share2 className="w-3.5 h-3.5 text-cyan-400" />
              ECOSYSTEM INTEGRATIONS
            </span>
            <span className="text-[11px] font-mono text-emerald-400 font-semibold">
              SEPARATE TAB WORKSPACE MANAGER
            </span>
          </div>
          <h1 className="text-2xl font-black text-white mt-1">
            External Links, Connectors & Multi-Tab Workspaces
          </h1>
          <p className="text-xs text-slate-300 mt-0.5">
            Open dedicated standalone tabs for Big Data, 3D Digital Twin, Simulation Laboratory, and external grid telemetry APIs.
          </p>
        </div>
      </div>

      {/* Pop-Out Dedicated Browser Tabs Section */}
      <div className="p-6 rounded-2xl bg-[#0b1329] border border-cyan-500/40 shadow-xl space-y-4">
        <div className="flex items-center justify-between">
          <div>
            <span className="text-xs font-mono font-bold text-cyan-400 uppercase tracking-wider">
              MULTI-WINDOW TAB MANAGER
            </span>
            <h2 className="text-base font-bold text-white mt-0.5">
              Launch Dedicated Standalone Workspace Tabs
            </h2>
          </div>
          <span className="text-xs text-slate-400 font-mono">
            Opens in new browser tab
          </span>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 pt-1">
          {popoutTabs.map((tab, idx) => {
            const Icon = tab.icon;
            return (
              <div
                key={idx}
                className="p-4 rounded-xl bg-slate-950 border border-slate-800 hover:border-cyan-500/50 transition flex items-start justify-between gap-4 group"
              >
                <div className="flex items-start gap-3">
                  <div className={`p-2.5 rounded-xl bg-gradient-to-br ${tab.color} text-white`}>
                    <Icon className="w-5 h-5" />
                  </div>
                  <div>
                    <h3 className="text-sm font-bold text-white group-hover:text-cyan-300 transition">
                      {tab.name}
                    </h3>
                    <p className="text-xs text-slate-400 mt-1 leading-relaxed">
                      {tab.desc}
                    </p>
                  </div>
                </div>

                <button
                  onClick={() => handlePopout(tab.path)}
                  className="px-3 py-1.5 rounded-lg bg-slate-900 hover:bg-cyan-500 hover:text-black text-cyan-300 border border-cyan-500/30 text-xs font-bold whitespace-nowrap flex items-center gap-1 cursor-pointer transition shadow-sm"
                >
                  <span>Launch ↗</span>
                </button>
              </div>
            );
          })}
        </div>
      </div>

      {/* External Industry APIs & Web Services List */}
      <div className="space-y-3">
        <div className="flex items-center justify-between">
          <h2 className="text-sm font-bold text-white uppercase font-mono flex items-center gap-2">
            <Network className="w-4 h-4 text-cyan-400" />
            <span>External Infrastructure Connectors & Live API Links (Opens in New Tab)</span>
          </h2>
          <span className="text-xs text-slate-400 font-mono">Industry Standards</span>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {externalConnectors.map((c) => (
            <div
              key={c.id}
              className="p-5 rounded-2xl bg-[#0b1329] border border-slate-800 hover:border-slate-700 transition flex flex-col justify-between space-y-3 shadow-lg"
            >
              <div className="space-y-2">
                <div className="flex justify-between items-start">
                  <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-slate-900 border border-slate-700 text-cyan-300 font-bold uppercase">
                    {c.badge}
                  </span>
                  <span className="text-[10px] text-emerald-400 font-mono font-semibold">
                    {c.status}
                  </span>
                </div>

                <h3 className="text-base font-bold text-white">{c.title}</h3>
                <p className="text-xs text-slate-400 leading-relaxed">
                  {c.desc}
                </p>
              </div>

              <div className="pt-2 border-t border-slate-800/80 flex items-center justify-between">
                <span className="text-[11px] text-slate-500 font-mono truncate max-w-[170px]">
                  {c.url}
                </span>
                <a
                  href={c.url}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="px-3 py-1.5 rounded-lg bg-cyan-500/20 hover:bg-cyan-500/30 text-cyan-300 border border-cyan-500/40 text-xs font-bold flex items-center gap-1 cursor-pointer transition"
                >
                  <span>Open API ↗</span>
                </a>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
