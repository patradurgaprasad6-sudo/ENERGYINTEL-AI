import React, { useState } from "react";
import {
  Building2,
  Layers,
  Thermometer,
  Users,
  Zap,
  ShieldCheck,
  AlertTriangle,
  Lightbulb,
  ArrowRight,
  Sliders,
  CheckCircle2,
  ChevronRight,
  Fan,
  SunMedium
} from "lucide-react";
import { useEnergy } from "../context/EnergyContext";

export function BuildingIntelligencePage({ setCurrentTab }) {
  const {
    campusConfig,
    selectedBuilding,
    setSelectedBuilding,
    selectedFloor,
    setSelectedFloor,
    applyRecommendation,
    appliedRecommendations,
    occupancyMultiplier,
    tempOffset
  } = useEnergy();

  const currentBuildingId = selectedBuilding === "all" ? "block-b" : selectedBuilding;
  const currentBuilding = campusConfig.buildings.find(b => b.id === currentBuildingId) || campusConfig.buildings[1];

  const currentFloorId = selectedFloor === "all" ? currentBuilding.floors[1]?.id : selectedFloor;
  const activeFloor = currentBuilding.floors.find(f => f.id === currentFloorId) || currentBuilding.floors[0];

  return (
    <div className="space-y-6">
      {/* Page Header */}
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 p-5 rounded-2xl bg-gradient-to-r from-cyan-950/50 via-slate-900 to-blue-950/40 border border-cyan-500/30">
        <div>
          <div className="flex items-center gap-2">
            <span className="px-2.5 py-0.5 rounded-full bg-cyan-950 border border-cyan-700 text-cyan-300 font-mono text-[10px] font-bold uppercase tracking-wider">
              FACILITY HIERARCHY DRILL-DOWN
            </span>
            <span className="text-xs text-slate-300">
              Trident Campus → 4 Blocks → 12 Sub-Metered Floors
            </span>
          </div>
          <h1 className="text-2xl font-black text-white mt-1">
            Building & Floor Level Intelligence
          </h1>
          <p className="text-xs text-slate-300 mt-0.5">
            Micro-level sub-metering telemetry isolating energy density, cooling loads, and real-time room occupancy across all 4 Blocks and 12 Floors.
          </p>
        </div>
      </div>

      {/* Building Switcher Header Cards (Requirement 25) */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        {campusConfig.buildings.map((b) => {
          const isSelected = currentBuildingId === b.id;
          return (
            <div
              key={b.id}
              onClick={() => {
                setSelectedBuilding(b.id);
                setSelectedFloor("all");
              }}
              className={`p-5 rounded-2xl border transition-all cursor-pointer ${
                isSelected
                  ? "bg-gradient-to-br from-slate-900 to-[#101b38] border-cyan-400 shadow-xl shadow-cyan-500/20 scale-[1.01]"
                  : "bg-[#0b1329] border-slate-800 hover:border-slate-700 hover:bg-slate-900/60"
              }`}
            >
              <div className="flex items-start justify-between">
                <div>
                  <span className="text-xs font-mono font-bold text-cyan-400">BLOCK {b.code}</span>
                  <h3 className="text-lg font-bold text-white mt-0.5">{b.name.split("—")[0]}</h3>
                  <p className="text-xs text-slate-400">{b.type}</p>
                </div>
                <div className={`p-2.5 rounded-xl ${isSelected ? 'bg-cyan-500 text-black' : 'bg-slate-800 text-slate-400'}`}>
                  <Building2 className="w-5 h-5" />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-2 mt-4 pt-3 border-t border-slate-800">
                <div className="p-2.5 rounded-xl bg-slate-950/80">
                  <span className="text-[10px] text-slate-400 font-mono uppercase">Energy Load</span>
                  <div className="text-lg font-black text-cyan-300 font-mono mt-0.5">
                    {b.nominalPowerKW} kW
                  </div>
                </div>
                <div className="p-2.5 rounded-xl bg-slate-950/80">
                  <span className="text-[10px] text-slate-400 font-mono uppercase">Efficiency</span>
                  <div className="text-lg font-black text-emerald-400 font-mono mt-0.5">
                    {b.nominalEfficiency}%
                  </div>
                </div>
              </div>
            </div>
          );
        })}
      </div>

      {/* Floor Selection Strip */}
      <div className="flex items-center gap-2 overflow-x-auto pb-1">
        {currentBuilding.floors.map((fl) => {
          const isFloorActive = activeFloor.id === fl.id;
          return (
            <button
              key={fl.id}
              onClick={() => setSelectedFloor(fl.id)}
              className={`flex items-center gap-2.5 px-4 py-2.5 rounded-xl border text-xs font-semibold transition cursor-pointer whitespace-nowrap ${
                isFloorActive
                  ? "bg-cyan-500/20 text-cyan-300 border-cyan-500 shadow-md shadow-cyan-500/20"
                  : "bg-[#0b1329] text-slate-400 border-slate-800 hover:text-white hover:border-slate-700"
              }`}
            >
              <Layers className="w-4 h-4" />
              <span>Floor {fl.number}: {fl.name.split(":")[1]?.trim() || fl.name}</span>
            </button>
          );
        })}
      </div>

      {/* Active Floor Deep Dive Telemetry (Requirement 26) */}
      <div className="bg-[#0b1329] border border-slate-800 rounded-2xl p-6 shadow-xl space-y-6">
        <div className="flex flex-col md:flex-row items-start md:items-center justify-between gap-4 border-b border-slate-800 pb-4">
          <div>
            <div className="flex items-center gap-2">
              <span className="text-xs font-mono font-bold px-2.5 py-0.5 rounded bg-cyan-950 text-cyan-300 border border-cyan-800 uppercase">
                {currentBuilding.name.split("—")[0].trim()} — FLOOR {activeFloor.number}
              </span>
              {activeFloor.id === "b-2" && (
                <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-rose-950 text-rose-300 border border-rose-800 font-bold uppercase animate-pulse">
                  WASTAGE: HIGH
                </span>
              )}
            </div>
            <h2 className="text-xl font-bold text-white mt-1">
              {activeFloor.name}
            </h2>
            <p className="text-xs text-slate-400 mt-0.5">
              Area: {activeFloor.areaSqFt.toLocaleString()} sq.ft • {activeFloor.rooms} Rooms & Laboratories • Capacity: {activeFloor.occupancyCapacity} occupants
            </p>
          </div>

          <div className="flex items-center gap-2">
            <span className="text-xs text-slate-400 font-mono">Floor Power:</span>
            <span className="text-2xl font-black text-cyan-300 font-mono">
              {activeFloor.id === "b-2" ? "14.8 kW" : `${activeFloor.baseLoadKW} kW`}
            </span>
          </div>
        </div>

        {/* 6 Metric Badges for Floor */}
        <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-3">
          <div className="p-3.5 rounded-xl bg-slate-950 border border-slate-800/80">
            <span className="text-[10px] text-slate-400 uppercase font-mono">Energy Draw</span>
            <div className="text-lg font-black text-cyan-400 font-mono mt-1">
              {activeFloor.id === "b-2" ? "14.8 kW" : `${activeFloor.baseLoadKW} kW`}
            </div>
            <span className="text-[10px] text-slate-500">Live submeter</span>
          </div>

          <div className="p-3.5 rounded-xl bg-slate-950 border border-slate-800/80">
            <span className="text-[10px] text-slate-400 uppercase font-mono">Occupancy</span>
            <div className="text-lg font-black text-purple-400 font-mono mt-1">
              {activeFloor.id === "b-2" ? `${Math.round(32 * occupancyMultiplier)}%` : "68%"}
            </div>
            <span className="text-[10px] text-slate-500">PIR + Optical</span>
          </div>

          <div className="p-3.5 rounded-xl bg-slate-950 border border-slate-800/80">
            <span className="text-[10px] text-slate-400 uppercase font-mono">Temperature</span>
            <div className="text-lg font-black text-amber-400 font-mono mt-1">
              {24.2 + tempOffset}°C
            </div>
            <span className="text-[10px] text-slate-500">Ambient indoor</span>
          </div>

          <div className="p-3.5 rounded-xl bg-slate-950 border border-slate-800/80">
            <span className="text-[10px] text-slate-400 uppercase font-mono">AC Duty Cycle</span>
            <div className="text-lg font-black text-blue-400 font-mono mt-1">
              {activeFloor.id === "b-2" ? "78%" : "54%"}
            </div>
            <span className="text-[10px] text-slate-500">VRF chilled flow</span>
          </div>

          <div className="p-3.5 rounded-xl bg-slate-950 border border-slate-800/80">
            <span className="text-[10px] text-slate-400 uppercase font-mono">Lighting Load</span>
            <div className="text-lg font-black text-yellow-400 font-mono mt-1">
              {activeFloor.id === "a-3" ? "92%" : "64%"}
            </div>
            <span className="text-[10px] text-slate-500">Luminaires</span>
          </div>

          <div className="p-3.5 rounded-xl bg-slate-950 border border-slate-800/80">
            <span className="text-[10px] text-slate-400 uppercase font-mono">Wastage Status</span>
            <div className={`text-lg font-black font-mono mt-1 ${activeFloor.id === "b-2" ? 'text-rose-400' : 'text-emerald-400'}`}>
              {activeFloor.id === "b-2" ? "HIGH" : "LOW"}
            </div>
            <span className="text-[10px] text-slate-500">AI evaluated</span>
          </div>
        </div>

        {/* Floor Specific AI Recommendation Card */}
        <div className="p-4 rounded-xl bg-gradient-to-r from-blue-950/40 to-cyan-950/40 border border-cyan-800/60 flex flex-col md:flex-row items-start md:items-center justify-between gap-4">
          <div className="space-y-1">
            <span className="text-xs font-mono font-bold text-cyan-300 uppercase flex items-center gap-1.5">
              <Lightbulb className="w-4 h-4 text-cyan-400" />
              Floor AI Optimization Recommendation
            </span>
            <p className="text-xs text-slate-200">
              {activeFloor.id === "b-2"
                ? "Reduce AC operation during low-occupancy periods. Increase setpoint from 18°C to 24°C in vacant Lab 204."
                : "Operational schedule optimal. Maintain baseline ventilation flow."}
            </p>
          </div>

          <div className="flex items-center gap-3">
            <div className="text-right">
              <div className="text-xs font-mono font-bold text-emerald-400">
                {activeFloor.id === "b-2" ? "+34.2 kWh/day" : "Nominal"}
              </div>
              <div className="text-[10px] font-mono text-cyan-400">
                {activeFloor.id === "b-2" ? "Save ₹273/day" : "Zero Waste"}
              </div>
            </div>

            <button
              onClick={() => setCurrentTab("recommendations")}
              className="px-3.5 py-1.5 rounded-xl bg-cyan-500 hover:bg-cyan-400 text-black font-bold text-xs cursor-pointer whitespace-nowrap"
            >
              Action Plan
            </button>
          </div>
        </div>

        {/* Room / Zone Visual Layout Grid */}
        <div className="space-y-3">
          <h3 className="text-xs font-bold uppercase font-mono text-slate-400">
            Room-by-Room Zone Sub-Metering & PIR Occupancy Status
          </h3>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3">
            {[
              { room: "Zone 101: West Wing Lab", load: "3.8 kW", occ: 35, ac: "Active", status: "Nominal" },
              { room: "Zone 102: Central Studio", load: "4.6 kW", occ: 18, ac: "Overcooling", status: "Wastage Alert" },
              { room: "Zone 103: Research Bay", load: "2.9 kW", occ: 42, ac: "Eco Mode", status: "Nominal" },
              { room: "Zone 104: Seminar Suite", load: "3.5 kW", occ: 0, ac: "Idle", status: "Lights ON (Warning)" }
            ].map((z, idx) => (
              <div
                key={idx}
                className={`p-3.5 rounded-xl border text-xs space-y-2 ${
                  z.status.includes("Wastage") || z.status.includes("Warning")
                    ? "bg-rose-950/20 border-rose-800/60"
                    : "bg-slate-950 border-slate-800/80"
                }`}
              >
                <div className="flex justify-between items-start">
                  <span className="font-semibold text-slate-200">{z.room}</span>
                  <span
                    className={`text-[9px] font-mono px-1.5 py-0.5 rounded font-bold ${
                      z.status.includes("Wastage")
                        ? "bg-rose-500/20 text-rose-300 border border-rose-500/50"
                        : z.status.includes("Warning")
                        ? "bg-amber-500/20 text-amber-300 border border-amber-500/50"
                        : "bg-emerald-500/20 text-emerald-300 border border-emerald-500/50"
                    }`}
                  >
                    {z.status}
                  </span>
                </div>
                <div className="grid grid-cols-2 gap-1 text-[11px] text-slate-400 font-mono">
                  <div>Power: <strong className="text-slate-200">{z.load}</strong></div>
                  <div>Occ: <strong className="text-slate-200">{z.occ}%</strong></div>
                  <div>HVAC: <strong className="text-slate-200">{z.ac}</strong></div>
                  <div>PF: <strong className="text-emerald-400">0.96</strong></div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}
