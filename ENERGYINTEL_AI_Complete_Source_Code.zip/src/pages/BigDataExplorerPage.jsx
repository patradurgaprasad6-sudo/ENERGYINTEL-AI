import React, { useState, useEffect, useMemo } from "react";
import {
  Database,
  ExternalLink,
  Search,
  Filter,
  Download,
  Play,
  Pause,
  Terminal,
  Activity,
  ArrowUpDown,
  RefreshCw,
  Clock,
  Sparkles,
  Layers,
  Table,
  Cpu
} from "lucide-react";
import {
  ResponsiveContainer,
  ScatterChart,
  Scatter,
  XAxis,
  YAxis,
  ZAxis,
  Tooltip,
  CartesianGrid
} from "recharts";
import { useEnergy } from "../context/EnergyContext";
import { exportToCSV } from "../services/exportUtils";

export function BigDataExplorerPage({ isStandalone = false }) {
  const { currentPowerKW, electricalParams, activeAnomaly } = useEnergy();

  const [isStreaming, setIsStreaming] = useState(true);
  const [streamSpeedMs, setStreamSpeedMs] = useState(1500);
  const [sqlQuery, setSqlQuery] = useState("SELECT timestamp, building, floor, power_kw, temp_c, occ_pct, pf FROM campus_telemetry WHERE power_kw > 15.0 ORDER BY timestamp DESC LIMIT 50");
  const [activeFilterBuilding, setActiveFilterBuilding] = useState("all");
  const [streamBuffer, setStreamBuffer] = useState([]);
  const [queryExecutionStats, setQueryExecutionStats] = useState({ rows: 50, timeMs: 4.8, memoryKB: 142 });

  // Generate initial simulated big data lake records
  useEffect(() => {
    const buildings = ["Block A", "Block B", "Block C", "Block D"];
    const floors = ["Floor 1", "Floor 2", "Floor 3"];
    const initialRecords = [];
    const now = Date.now();

    for (let i = 0; i < 40; i++) {
      const b = buildings[i % 3];
      const f = floors[(i + 1) % 3];
      const t = new Date(now - i * 3000).toISOString().replace("T", " ").substring(11, 19);
      const isAnomalyRow = activeAnomaly && b === "Block B" && f === "Floor 2";
      const power = isAnomalyRow ? 24.8 : Number((8.5 + (Math.sin(i) * 3) + (b === "Block A" ? 3.5 : 2.0)).toFixed(2));
      const temp = Number((24.0 + (Math.cos(i) * 3.5)).toFixed(1));
      const occ = Math.round(Math.max(5, 45 + Math.sin(i * 0.8) * 35));

      initialRecords.push({
        id: `rec-${now - i * 1000}`,
        timestamp: t,
        building: b,
        floor: f,
        power_kw: power,
        voltage_v: Number((230.5 + Math.sin(i) * 1.5).toFixed(1)),
        current_a: Number(((power * 1000) / (230 * 0.96)).toFixed(1)),
        temp_c: temp,
        occ_pct: occ,
        pf: Number((0.95 + Math.cos(i) * 0.02).toFixed(2)),
        frequency_hz: 50.02,
        anomaly_flag: isAnomalyRow ? 1 : 0
      });
    }

    setStreamBuffer(initialRecords);
  }, [activeAnomaly]);

  // Streaming real-time ingestion ticker
  useEffect(() => {
    if (!isStreaming) return;

    const interval = setInterval(() => {
      const buildings = ["Block A", "Block B", "Block C", "Block D"];
      const floors = ["Floor 1", "Floor 2", "Floor 3"];
      const b = buildings[Math.floor(Math.random() * buildings.length)];
      const f = floors[Math.floor(Math.random() * floors.length)];
      const now = new Date();
      const t = now.toISOString().replace("T", " ").substring(11, 19);
      const isAnomalyRow = activeAnomaly && b === "Block B" && f === "Floor 2";
      const power = isAnomalyRow ? 24.8 : Number((8.0 + Math.random() * 6).toFixed(2));

      const newRec = {
        id: `rec-${Date.now()}`,
        timestamp: t,
        building: b,
        floor: f,
        power_kw: power,
        voltage_v: Number((230 + Math.random() * 3).toFixed(1)),
        current_a: Number(((power * 1000) / (230 * 0.95)).toFixed(1)),
        temp_c: Number((25 + Math.random() * 6).toFixed(1)),
        occ_pct: Math.round(10 + Math.random() * 80),
        pf: Number((0.94 + Math.random() * 0.04).toFixed(2)),
        frequency_hz: 50.01,
        anomaly_flag: isAnomalyRow ? 1 : 0
      };

      setStreamBuffer(prev => [newRec, ...prev.slice(0, 59)]);
    }, streamSpeedMs);

    return () => clearInterval(interval);
  }, [isStreaming, streamSpeedMs, activeAnomaly]);

  const openInNewTab = () => {
    window.open(`${window.location.origin}/?view=bigdata`, "_blank");
  };

  const handleRunQuery = (customSql) => {
    const query = customSql || sqlQuery;
    const start = performance.now();
    // Simulate query execution filtering
    setQueryExecutionStats({
      rows: streamBuffer.length,
      timeMs: Number((performance.now() - start + 2.4).toFixed(2)),
      memoryKB: 248
    });
  };

  const filteredRecords = useMemo(() => {
    if (activeFilterBuilding === "all") return streamBuffer;
    return streamBuffer.filter(r => r.building === activeFilterBuilding);
  }, [streamBuffer, activeFilterBuilding]);

  return (
    <div className={`space-y-6 ${isStandalone ? 'p-6 max-w-7xl mx-auto' : ''}`}>
      {/* Header */}
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 p-5 rounded-2xl bg-gradient-to-r from-blue-950/60 via-slate-900 to-indigo-950/50 border border-blue-500/40 shadow-xl">
        <div>
          <div className="flex items-center gap-2">
            <span className="px-2.5 py-0.5 rounded-full bg-blue-950 border border-blue-700 text-blue-300 font-mono text-[10px] font-bold uppercase tracking-wider flex items-center gap-1.5">
              <Database className="w-3.5 h-3.5 text-blue-400" />
              TIMESERIES BIG DATA LAKE
            </span>
            <span className="text-[11px] font-mono text-cyan-400 font-semibold">
              INFLUXDB / TIMESCALEDB ARCHITECTURE
            </span>
          </div>
          <h1 className="text-2xl font-black text-white mt-1">
            Big Data Telemetry Stream & Query Console
          </h1>
          <p className="text-xs text-slate-300 mt-0.5">
            Real-time ingestion of high-frequency electrical telemetry with sub-second timestamps and multi-variate indexing.
          </p>
        </div>

        <div className="flex items-center gap-2">
          {!isStandalone && (
            <button
              onClick={openInNewTab}
              className="px-3.5 py-2 rounded-xl bg-blue-500/20 hover:bg-blue-500/30 text-blue-300 border border-blue-500/50 text-xs font-bold flex items-center gap-1.5 cursor-pointer transition shadow-md shadow-blue-500/20"
              title="Open Big Data Lake in a dedicated separate browser tab"
            >
              <ExternalLink className="w-3.5 h-3.5" />
              <span>Open in New Browser Tab ↗</span>
            </button>
          )}

          <button
            onClick={() => exportToCSV("telemetry_stream_dump.csv", filteredRecords)}
            className="px-3.5 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-semibold flex items-center gap-1.5 cursor-pointer"
          >
            <Download className="w-3.5 h-3.5 text-cyan-400" />
            <span>Export CSV</span>
          </button>
        </div>
      </div>

      {/* Big Data System Telemetry Vitals */}
      <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
        <div className="p-4 rounded-xl bg-[#0b1329] border border-slate-800">
          <span className="text-[10px] text-slate-400 font-mono uppercase">Ingestion Velocity</span>
          <div className="text-2xl font-black text-cyan-400 font-mono mt-0.5">
            1,240 msg/sec
          </div>
          <span className="text-[10px] text-slate-500">Sub-second MQTT stream</span>
        </div>

        <div className="p-4 rounded-xl bg-[#0b1329] border border-slate-800">
          <span className="text-[10px] text-slate-400 font-mono uppercase">Query Latency</span>
          <div className="text-2xl font-black text-emerald-400 font-mono mt-0.5">
            {queryExecutionStats.timeMs} ms
          </div>
          <span className="text-[10px] text-slate-500">In-memory column cache</span>
        </div>

        <div className="p-4 rounded-xl bg-[#0b1329] border border-slate-800">
          <span className="text-[10px] text-slate-400 font-mono uppercase">Cumulative Records</span>
          <div className="text-2xl font-black text-purple-400 font-mono mt-0.5">
            2,841,920
          </div>
          <span className="text-[10px] text-slate-500">Bucket: campus_raw_telemetry</span>
        </div>

        <div className="p-4 rounded-xl bg-[#0b1329] border border-slate-800">
          <span className="text-[10px] text-slate-400 font-mono uppercase">Active Stream Status</span>
          <div className="text-2xl font-black text-amber-400 font-mono mt-0.5 flex items-center gap-2">
            <span className="w-2.5 h-2.5 rounded-full bg-emerald-400 animate-ping"></span>
            <span>STREAMING</span>
          </div>
          <span className="text-[10px] text-slate-500">Buffer: 60 Rolling Slices</span>
        </div>
      </div>

      {/* SQL Query Console Card */}
      <div className="p-5 rounded-2xl bg-[#080d1a] border border-slate-800 space-y-3 font-mono">
        <div className="flex items-center justify-between text-xs text-slate-400">
          <span className="flex items-center gap-1.5 text-cyan-300 font-bold">
            <Terminal className="w-4 h-4 text-cyan-400" />
            TIMESCALE / INFLUX QUERY CONSOLE
          </span>
          <div className="flex items-center gap-2">
            <button
              onClick={() => handleRunQuery()}
              className="px-3 py-1 rounded-lg bg-cyan-500 hover:bg-cyan-400 text-black text-xs font-bold cursor-pointer transition flex items-center gap-1"
            >
              <Play className="w-3 h-3 fill-current" />
              <span>Execute SQL Query</span>
            </button>
          </div>
        </div>

        <div className="relative">
          <textarea
            rows="2"
            value={sqlQuery}
            onChange={(e) => setSqlQuery(e.target.value)}
            className="w-full bg-slate-950 border border-slate-800 rounded-xl p-3 text-xs text-cyan-300 font-mono focus:outline-none focus:border-cyan-400"
          ></textarea>
        </div>

        {/* Quick Sample Query Buttons */}
        <div className="flex items-center gap-2 flex-wrap text-[11px]">
          <span className="text-slate-500">Quick Queries:</span>
          {[
            { label: "Surge kW > 20", q: "SELECT * FROM campus_telemetry WHERE power_kw > 20 ORDER BY power_kw DESC" },
            { label: "Low PF < 0.94", q: "SELECT timestamp, building, pf FROM campus_telemetry WHERE pf < 0.94" },
            { label: "High Heat > 28°C", q: "SELECT timestamp, floor, temp_c, occ_pct FROM campus_telemetry WHERE temp_c > 28" }
          ].map((sample, idx) => (
            <button
              key={idx}
              onClick={() => {
                setSqlQuery(sample.q);
                handleRunQuery(sample.q);
              }}
              className="px-2.5 py-0.5 rounded bg-slate-900 border border-slate-700 text-slate-300 hover:text-cyan-300 cursor-pointer"
            >
              {sample.label}
            </button>
          ))}
        </div>
      </div>

      {/* Stream Controls & Building Filter */}
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 p-3 rounded-xl bg-[#0b1329] border border-slate-800 text-xs">
        <div className="flex items-center gap-2">
          <button
            onClick={() => setIsStreaming(prev => !prev)}
            className={`px-3 py-1.5 rounded-lg font-semibold flex items-center gap-1.5 cursor-pointer ${
              isStreaming ? "bg-amber-500/20 text-amber-300 border border-amber-500/40" : "bg-emerald-500/20 text-emerald-300 border border-emerald-500/40"
            }`}
          >
            {isStreaming ? <Pause className="w-3.5 h-3.5" /> : <Play className="w-3.5 h-3.5" />}
            <span>{isStreaming ? "Pause Live Ingestion" : "Resume Stream"}</span>
          </button>

          <select
            value={streamSpeedMs}
            onChange={(e) => setStreamSpeedMs(Number(e.target.value))}
            className="bg-slate-950 text-slate-300 border border-slate-800 rounded-lg px-2.5 py-1.5 text-xs font-mono"
          >
            <option value="800">High Frequency (800ms)</option>
            <option value="1500">Normal Frequency (1.5s)</option>
            <option value="3000">Slow Frequency (3s)</option>
          </select>
        </div>

        <div className="flex items-center gap-2">
          <span className="text-slate-400 font-mono text-[11px] flex items-center gap-1">
            <Filter className="w-3.5 h-3.5" /> Building Filter:
          </span>
          {["all", "Block A", "Block B", "Block C", "Block D"].map(b => (
            <button
              key={b}
              onClick={() => setActiveFilterBuilding(b)}
              className={`px-2.5 py-1 rounded text-[11px] font-mono transition cursor-pointer ${
                activeFilterBuilding === b
                  ? "bg-slate-800 text-cyan-300 font-bold border border-slate-700"
                  : "text-slate-400 hover:text-white"
              }`}
            >
              {b}
            </button>
          ))}
        </div>
      </div>

      {/* Streaming High-Density Data Table */}
      <div className="bg-[#0b1329] border border-slate-800 rounded-2xl p-5 shadow-xl space-y-3 font-mono">
        <div className="flex items-center justify-between text-xs text-slate-400 border-b border-slate-800 pb-2">
          <div className="flex items-center gap-2">
            <Table className="w-4 h-4 text-cyan-400" />
            <span className="font-bold text-white">Live Ingested Telemetry Buffer</span>
            <span className="text-[10px] px-2 py-0.5 rounded bg-slate-900 border border-slate-800 text-cyan-300">
              {filteredRecords.length} Rows Cached
            </span>
          </div>
          <span className="text-[10px] text-slate-500">Rolling FIFO Queue</span>
        </div>

        <div className="overflow-x-auto max-h-96 overflow-y-auto">
          <table className="w-full text-left text-xs">
            <thead className="sticky top-0 bg-[#0b1329] text-slate-400 uppercase text-[10px] border-b border-slate-800">
              <tr>
                <th className="py-2 px-2">Timestamp</th>
                <th className="py-2 px-2">Location</th>
                <th className="py-2 px-2">Power (kW)</th>
                <th className="py-2 px-2">Voltage (V)</th>
                <th className="py-2 px-2">Current (A)</th>
                <th className="py-2 px-2">PF</th>
                <th className="py-2 px-2">Temp (°C)</th>
                <th className="py-2 px-2">Occ (%)</th>
                <th className="py-2 px-2 text-right">Flag</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/60 text-[11px]">
              {filteredRecords.map((row) => (
                <tr
                  key={row.id}
                  className={`hover:bg-slate-900/50 transition-colors ${
                    row.anomaly_flag === 1 ? "bg-rose-950/30 text-rose-300 font-bold" : "text-slate-200"
                  }`}
                >
                  <td className="py-2 px-2 text-cyan-300">{row.timestamp}</td>
                  <td className="py-2 px-2">{row.building} — {row.floor}</td>
                  <td className="py-2 px-2 font-bold">{row.power_kw} kW</td>
                  <td className="py-2 px-2">{row.voltage_v} V</td>
                  <td className="py-2 px-2">{row.current_a} A</td>
                  <td className="py-2 px-2 text-emerald-400">{row.pf}</td>
                  <td className="py-2 px-2 text-amber-300">{row.temp_c}°C</td>
                  <td className="py-2 px-2 text-purple-300">{row.occ_pct}%</td>
                  <td className="py-2 px-2 text-right">
                    {row.anomaly_flag === 1 ? (
                      <span className="px-1.5 py-0.5 rounded bg-rose-500 text-black font-bold text-[9px]">
                        ANOMALY
                      </span>
                    ) : (
                      <span className="text-slate-600 text-[10px]">OK</span>
                    )}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
