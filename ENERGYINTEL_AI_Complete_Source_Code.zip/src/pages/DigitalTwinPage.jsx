import React, { useState, useEffect } from "react";
import {
  Layers,
  Zap,
  Thermometer,
  Users,
  AlertTriangle,
  Building2,
  Cpu,
  Fan,
  Activity,
  ExternalLink,
  Maximize2,
  RefreshCw,
  Sliders,
  CheckCircle2,
  Radio,
  Eye,
  Box
} from "lucide-react";
import { useEnergy } from "../context/EnergyContext";

export function DigitalTwinPage({ isStandalone = false }) {
  const {
    campusConfig,
    currentPowerKW,
    activeAnomaly,
    activeWastageScenario,
    electricalParams,
    environmentalParams,
    triggerAnomaly,
    selectedBuilding,
    setSelectedBuilding,
    selectedFloor,
    setSelectedFloor
  } = useEnergy();

  // Active overlay layer: "power" | "thermal" | "occupancy" | "wastage"
  const [activeLayer, setActiveLayer] = useState("power");
  // Selected inspection node
  const [selectedNode, setSelectedNode] = useState({
    id: "block-b-f2",
    name: "Block B — Floor 2 (Microelectronics & Design Studio)",
    building: "Block B",
    floor: 2,
    type: "High-Density Lab & Studio",
    powerKW: 14.8,
    tempC: 22.4,
    targetTempC: 24.0,
    occupancyPct: 24,
    headcount: 72,
    hvacDutyPct: 78,
    hvacSetpointC: 18.0,
    lightingPct: 85,
    status: "Wastage Alert: AC Overrun at Low Occupancy",
    chillerLoop: "Loop B2 (VRF Chilled Water)",
    compressorAmps: 34.2,
    damperAngle: "65° Open",
    co2Ppm: 520,
    harmonicsTHD: "2.4%"
  });

  const [isRotating, setIsRotating] = useState(false);
  const [pulseTick, setPulseTick] = useState(0);

  useEffect(() => {
    const timer = setInterval(() => {
      setPulseTick(prev => (prev + 1) % 100);
    }, 1200);
    return () => clearInterval(timer);
  }, []);

  const openInNewTab = () => {
    window.open(`${window.location.origin}/?view=digitaltwin`, "_blank");
  };

  // Node details generator
  const selectDigitalTwinNode = (nodeId, name, building, floor, power, temp, occ, hvacDuty, status) => {
    setSelectedNode({
      id: nodeId,
      name,
      building,
      floor,
      type: floor === 0 ? "Central Substation & Chiller Yard" : "Campus Facility Zone",
      powerKW: power,
      tempC: temp,
      targetTempC: 24.0,
      occupancyPct: occ,
      headcount: Math.round(occ * 3.2),
      hvacDutyPct: hvacDuty,
      hvacSetpointC: status.includes("Alert") || status.includes("Spike") ? 18.0 : 24.0,
      lightingPct: Math.round(occ * 0.9) + 20,
      status,
      chillerLoop: `Loop ${building.replace("Block ", "")}-${floor}`,
      compressorAmps: Number((power * 2.3).toFixed(1)),
      damperAngle: `${Math.min(100, Math.round(hvacDuty * 0.9))}% Open`,
      co2Ppm: 450 + Math.round(occ * 4),
      harmonicsTHD: activeAnomaly && building === "Block B" ? "6.8% (Elevated)" : "2.1% (Optimal)"
    });
  };

  return (
    <div className={`space-y-6 ${isStandalone ? 'p-6 max-w-7xl mx-auto' : ''}`}>
      {/* Header */}
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 p-5 rounded-2xl bg-gradient-to-r from-blue-950/60 via-slate-900 to-cyan-950/50 border border-cyan-500/40 shadow-xl">
        <div>
          <div className="flex items-center gap-2">
            <span className="px-2.5 py-0.5 rounded-full bg-cyan-950 border border-cyan-700 text-cyan-300 font-mono text-[10px] font-bold uppercase tracking-wider flex items-center gap-1.5">
              <Box className="w-3.5 h-3.5 text-cyan-400" />
              SPATIAL 3D DIGITAL TWIN
            </span>
            <span className="text-[11px] font-mono text-emerald-400 font-semibold flex items-center gap-1">
              <span className="w-2 h-2 rounded-full bg-emerald-400 animate-ping"></span>
              LIVE SYNCHRONIZED
            </span>
          </div>
          <h1 className="text-2xl font-black text-white mt-1">
            Trident Campus Real-Time Digital Twin Studio
          </h1>
          <p className="text-xs text-slate-300 mt-0.5">
            Synchronized 2.5D spatial telemetry model tracking all 4 Blocks (A, B, C, D) and 12 sub-metered floors with thermal envelopes, circuit wireframes, and occupancy loads.
          </p>
        </div>

        <div className="flex items-center gap-2">
          {!isStandalone && (
            <button
              onClick={openInNewTab}
              className="px-3.5 py-2 rounded-xl bg-cyan-500/20 hover:bg-cyan-500/30 text-cyan-300 border border-cyan-500/50 text-xs font-bold flex items-center gap-1.5 cursor-pointer transition shadow-md shadow-cyan-500/20"
              title="Open Campus Digital Twin in a dedicated separate browser tab"
            >
              <ExternalLink className="w-3.5 h-3.5" />
              <span>Open in New Browser Tab ↗</span>
            </button>
          )}

          <button
            onClick={() => setIsRotating(prev => !prev)}
            className={`px-3 py-2 rounded-xl border text-xs font-semibold flex items-center gap-1.5 cursor-pointer ${
              isRotating ? "bg-cyan-500 text-black border-cyan-400" : "bg-slate-900 text-slate-300 border-slate-800"
            }`}
          >
            <RefreshCw className={`w-3.5 h-3.5 ${isRotating ? 'animate-spin' : ''}`} />
            <span>{isRotating ? "Live Scan ON" : "Scan Idle"}</span>
          </button>
        </div>
      </div>

      {/* Layer Toggle Strip & Controls */}
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 p-3.5 rounded-xl bg-[#0b1329] border border-slate-800 text-xs">
        <div className="flex items-center gap-2 flex-wrap">
          <span className="text-slate-400 font-mono text-[11px] font-bold flex items-center gap-1">
            <Layers className="w-3.5 h-3.5 text-cyan-400" /> SPATIAL OVERLAYS:
          </span>

          {[
            { id: "power", label: "Electrical Power Flow (kW)", icon: Zap, color: "text-cyan-400" },
            { id: "thermal", label: "Thermal Heatmap (°C)", icon: Thermometer, color: "text-orange-400" },
            { id: "occupancy", label: "Occupancy Density", icon: Users, color: "text-purple-400" },
            { id: "wastage", label: "Wastage & Anomalies", icon: AlertTriangle, color: "text-rose-400" }
          ].map(l => {
            const Icon = l.icon;
            const isActive = activeLayer === l.id;
            return (
              <button
                key={l.id}
                onClick={() => setActiveLayer(l.id)}
                className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg font-medium transition cursor-pointer ${
                  isActive
                    ? "bg-slate-800 text-white font-bold border border-cyan-500/60 shadow-sm"
                    : "bg-slate-950 text-slate-400 hover:text-white"
                }`}
              >
                <Icon className={`w-3.5 h-3.5 ${l.color}`} />
                <span>{l.label}</span>
              </button>
            );
          })}
        </div>

        <div className="text-[11px] font-mono text-slate-400">
          Showing: <strong className="text-cyan-300 font-semibold">{selectedNode.name}</strong>
        </div>
      </div>

      {/* Main Digital Twin Interactive Canvas & Inspector Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        {/* Spatial 2.5D Campus SVG Canvas (8 cols) */}
        <div className="lg:col-span-8 bg-[#080d1c] border border-slate-800 rounded-2xl p-5 shadow-2xl relative overflow-hidden flex flex-col justify-between min-h-[520px]">
          {/* Top Canvas Bar */}
          <div className="flex items-center justify-between text-xs text-slate-400 z-10">
            <div className="flex items-center gap-2 font-mono text-[11px]">
              <span className="w-2 h-2 rounded-full bg-cyan-400"></span>
              <span>CAMPUS WIREFRAME: ISOMETRIC PROJECTION</span>
            </div>
            <div className="flex items-center gap-3 font-mono text-[10px]">
              <span>Grid: 33kV/415V Substation</span>
              <span>Bus: 3-Phase 50Hz</span>
              <span className="text-cyan-400 font-bold">{currentPowerKW} kW Net</span>
            </div>
          </div>

          {/* Isometric SVG Interactive Campus Map */}
          <div className="relative my-4 flex items-center justify-center">
            <svg
              viewBox="0 0 960 480"
              className="w-full h-auto max-h-[460px] filter drop-shadow-[0_10px_25px_rgba(0,0,0,0.8)]"
            >
              <defs>
                <linearGradient id="groundGrad" x1="0%" y1="0%" x2="100%" y2="100%">
                  <stop offset="0%" stopColor="#0b1329" stopOpacity="0.8" />
                  <stop offset="100%" stopColor="#070b14" stopOpacity="0.9" />
                </linearGradient>

                <linearGradient id="blockAGrad" x1="0%" y1="0%" x2="100%" y2="100%">
                  <stop offset="0%" stopColor="#0284c7" stopOpacity="0.85" />
                  <stop offset="100%" stopColor="#0369a1" stopOpacity="0.6" />
                </linearGradient>

                <linearGradient id="blockBGrad" x1="0%" y1="0%" x2="100%" y2="100%">
                  <stop offset="0%" stopColor={activeAnomaly ? "#e11d48" : "#7c3aed"} stopOpacity="0.85" />
                  <stop offset="100%" stopColor={activeAnomaly ? "#9f1239" : "#6d28d9"} stopOpacity="0.6" />
                </linearGradient>

                <linearGradient id="blockCGrad" x1="0%" y1="0%" x2="100%" y2="100%">
                  <stop offset="0%" stopColor="#059669" stopOpacity="0.85" />
                  <stop offset="100%" stopColor="#047857" stopOpacity="0.6" />
                </linearGradient>

                <linearGradient id="blockDGrad" x1="0%" y1="0%" x2="100%" y2="100%">
                  <stop offset="0%" stopColor="#d97706" stopOpacity="0.85" />
                  <stop offset="100%" stopColor="#b45309" stopOpacity="0.6" />
                </linearGradient>

                <linearGradient id="substationGrad" x1="0%" y1="0%" x2="100%" y2="100%">
                  <stop offset="0%" stopColor="#d97706" stopOpacity="0.9" />
                  <stop offset="100%" stopColor="#b45309" stopOpacity="0.7" />
                </linearGradient>
              </defs>

              {/* Campus Ground Plane Grid */}
              <polygon
                points="480,30 930,230 480,455 30,250"
                fill="url(#groundGrad)"
                stroke="#1e2e5c"
                strokeWidth="1.5"
                strokeDasharray="4 4"
              />

              {/* Electrical Power Bus Lines running from Substation to all 4 Blocks */}
              <path
                d="M 480,380 L 200,270"
                stroke={activeLayer === "power" ? "#00f0ff" : "#334155"}
                strokeWidth="2.5"
                strokeDasharray={activeLayer === "power" ? "6 6" : "none"}
                className={activeLayer === "power" ? "animate-pulse" : ""}
              />
              <path
                d="M 480,380 L 380,185"
                stroke={activeLayer === "power" ? "#a855f7" : "#334155"}
                strokeWidth="2.5"
                strokeDasharray={activeLayer === "power" ? "6 6" : "none"}
                className={activeLayer === "power" ? "animate-pulse" : ""}
              />
              <path
                d="M 480,380 L 580,185"
                stroke={activeLayer === "power" ? "#10b981" : "#334155"}
                strokeWidth="2.5"
                strokeDasharray={activeLayer === "power" ? "6 6" : "none"}
                className={activeLayer === "power" ? "animate-pulse" : ""}
              />
              <path
                d="M 480,380 L 760,270"
                stroke={activeLayer === "power" ? "#f59e0b" : "#334155"}
                strokeWidth="2.5"
                strokeDasharray={activeLayer === "power" ? "6 6" : "none"}
                className={activeLayer === "power" ? "animate-pulse" : ""}
              />

              {/* Central Transformer Substation Node */}
              <g
                className="cursor-pointer group"
                onClick={() =>
                  selectDigitalTwinNode(
                    "substation-main",
                    "Campus 11kV Substation & Central Chillers",
                    "Central Yard",
                    0,
                    currentPowerKW,
                    36.5,
                    0,
                    90,
                    "Nominal Grid Input: 50.02 Hz"
                  )
                }
              >
                {/* Substation Base */}
                <polygon
                  points="480,350 520,368 480,390 440,368"
                  fill="url(#substationGrad)"
                  stroke="#f59e0b"
                  strokeWidth="2"
                />
                <polygon
                  points="480,320 520,338 520,368 480,350"
                  fill="#b45309"
                  opacity="0.9"
                />
                <polygon
                  points="440,338 480,320 480,350 440,368"
                  fill="#92400e"
                  opacity="0.9"
                />
                <polygon
                  points="480,290 520,308 480,330 440,308"
                  fill="#f59e0b"
                  stroke="#fbbf24"
                  strokeWidth="1.5"
                />
                <circle cx="480" cy="308" r="4" fill="#fff" className="animate-ping" />
                <text x="480" y="415" fill="#f59e0b" fontSize="11" fontWeight="bold" textAnchor="middle" fontFamily="monospace">
                  SUBSTATION & CHILLER PLANT
                </text>
              </g>

              {/* BLOCK A — Left Wing (Academic & Lecture Halls) */}
              <g
                className="cursor-pointer group"
                onClick={() =>
                  selectDigitalTwinNode(
                    "block-a-f1",
                    "Block A — Academic Lecture Halls & Dean Offices",
                    "Block A",
                    1,
                    33.5,
                    25.1,
                    88,
                    65,
                    "Optimal Efficiency: 91%"
                  )
                }
              >
                {/* Floor 1 */}
                <polygon
                  points="200,250 265,282 200,314 135,282"
                  fill="url(#blockAGrad)"
                  stroke="#38bdf8"
                  strokeWidth="1.5"
                />
                <polygon points="135,282 200,314 200,334 135,302" fill="#0369a1" />
                <polygon points="265,282 200,314 200,334 265,302" fill="#0284c7" />

                {/* Floor 2 */}
                <polygon
                  points="200,190 265,222 200,254 135,222"
                  fill="url(#blockAGrad)"
                  stroke="#38bdf8"
                  strokeWidth="1.5"
                />
                <polygon points="135,222 200,254 200,269 135,237" fill="#0369a1" />
                <polygon points="265,222 200,254 200,269 265,237" fill="#0284c7" />

                {/* Floor 3 (Top) */}
                <polygon
                  points="200,130 265,162 200,194 135,162"
                  fill="url(#blockAGrad)"
                  stroke="#7dd3fc"
                  strokeWidth="2"
                />
                <polygon points="135,162 200,194 200,209 135,177" fill="#0369a1" />
                <polygon points="265,162 200,194 200,209 265,177" fill="#0284c7" />

                <circle cx="200" cy="140" r="5" fill="#38bdf8" />
                <text x="200" y="115" fill="#38bdf8" fontSize="12" fontWeight="bold" textAnchor="middle" fontFamily="sans-serif">
                  BLOCK A (33.5 kW)
                </text>
                <text x="200" y="355" fill="#94a3b8" fontSize="10" textAnchor="middle" fontFamily="monospace">
                  Eff: 91% • Classrooms
                </text>
              </g>

              {/* BLOCK B — Center High Tower (Engineering & Compute Labs) */}
              <g
                className="cursor-pointer group"
                onClick={() =>
                  selectDigitalTwinNode(
                    "block-b-f2",
                    "Block B — Floor 2 (Microelectronics & Design Studio)",
                    "Block B",
                    2,
                    activeAnomaly ? 24.8 : 14.8,
                    22.4,
                    24,
                    78,
                    activeAnomaly ? "CRITICAL: Compressor Surge Spike" : "Wastage Alert: AC Overrun at Low Occupancy"
                  )
                }
              >
                {/* Floor 1 */}
                <polygon
                  points="380,190 445,222 380,254 315,222"
                  fill="url(#blockBGrad)"
                  stroke={activeAnomaly ? "#f43f5e" : "#c084fc"}
                  strokeWidth="1.5"
                />
                <polygon points="315,222 380,254 380,274 315,242" fill={activeAnomaly ? "#9f1239" : "#6d28d9"} />
                <polygon points="445,222 380,254 380,274 445,242" fill={activeAnomaly ? "#e11d48" : "#7c3aed"} />

                {/* Floor 2 (Anomaly Hotspot) */}
                <polygon
                  points="380,120 445,152 380,184 315,152"
                  fill="url(#blockBGrad)"
                  stroke={activeAnomaly || activeWastageScenario ? "#f43f5e" : "#e9d5ff"}
                  strokeWidth={activeAnomaly ? "3" : "2"}
                />
                <polygon points="315,152 380,184 380,199 315,167" fill={activeAnomaly ? "#9f1239" : "#6d28d9"} />
                <polygon points="445,152 380,184 380,199 445,167" fill={activeAnomaly ? "#e11d48" : "#7c3aed"} />

                {/* Floor 3 */}
                <polygon
                  points="380,50 445,82 380,114 315,82"
                  fill="url(#blockBGrad)"
                  stroke={activeAnomaly ? "#f43f5e" : "#c084fc"}
                  strokeWidth="1.5"
                />
                <polygon points="315,82 380,114 380,129 315,97" fill={activeAnomaly ? "#9f1239" : "#6d28d9"} />
                <polygon points="445,82 380,114 380,129 445,97" fill={activeAnomaly ? "#e11d48" : "#7c3aed"} />

                <circle
                  cx="380"
                  cy="152"
                  r={activeAnomaly ? "8" : "5"}
                  fill={activeAnomaly ? "#f43f5e" : "#f59e0b"}
                  className="animate-ping"
                />
                <text x="380" y="35" fill={activeAnomaly ? "#fb7185" : "#c084fc"} fontSize="12" fontWeight="black" textAnchor="middle" fontFamily="sans-serif">
                  BLOCK B {activeAnomaly ? "(128 kW SPIKE)" : "(33.5 kW)"}
                </text>
                <text x="380" y="295" fill={activeAnomaly ? "#f43f5e" : "#f59e0b"} fontSize="10" fontWeight="bold" textAnchor="middle" fontFamily="monospace">
                  {activeAnomaly ? "🔴 COMPRESSOR SURGE" : "⚠️ F2: AC Overrun"}
                </text>
              </g>

              {/* BLOCK C — Central Right (Library, Auditorium & Lounge) */}
              <g
                className="cursor-pointer group"
                onClick={() =>
                  selectDigitalTwinNode(
                    "block-c-f2",
                    "Block C — Central Auditorium & Event Facilities",
                    "Block C",
                    2,
                    33.5,
                    26.0,
                    15,
                    52,
                    "Efficiency: 86% • Scheduled Auditorium"
                  )
                }
              >
                {/* Floor 1 */}
                <polygon
                  points="580,190 645,222 580,254 515,222"
                  fill="url(#blockCGrad)"
                  stroke="#34d399"
                  strokeWidth="1.5"
                />
                <polygon points="515,222 580,254 580,274 515,242" fill="#047857" />
                <polygon points="645,222 580,254 580,274 645,242" fill="#059669" />

                {/* Floor 2 */}
                <polygon
                  points="580,120 645,152 580,184 515,152"
                  fill="url(#blockCGrad)"
                  stroke="#34d399"
                  strokeWidth="1.5"
                />
                <polygon points="515,152 580,184 580,199 515,167" fill="#047857" />
                <polygon points="645,152 580,184 580,199 645,167" fill="#059669" />

                {/* Floor 3 */}
                <polygon
                  points="580,50 645,82 580,114 515,82"
                  fill="url(#blockCGrad)"
                  stroke="#6ee7b7"
                  strokeWidth="2"
                />
                <polygon points="515,82 580,114 580,129 515,97" fill="#047857" />
                <polygon points="645,82 580,114 580,129 645,97" fill="#059669" />

                <circle cx="580" cy="60" r="5" fill="#34d399" />
                <text x="580" y="35" fill="#34d399" fontSize="12" fontWeight="bold" textAnchor="middle" fontFamily="sans-serif">
                  BLOCK C (33.5 kW)
                </text>
                <text x="580" y="295" fill="#94a3b8" fontSize="10" textAnchor="middle" fontFamily="monospace">
                  Eff: 86% • Library & Audit
                </text>
              </g>

              {/* BLOCK D — Right Wing (Research & Innovation Hub) */}
              <g
                className="cursor-pointer group"
                onClick={() =>
                  selectDigitalTwinNode(
                    "block-d-f2",
                    "Block D — Floor 2 (Nanotech Cleanrooms & Photonics)",
                    "Block D",
                    2,
                    33.5,
                    23.8,
                    35,
                    60,
                    "Nominal Operation • High Efficiency: 89%"
                  )
                }
              >
                {/* Floor 1 */}
                <polygon
                  points="760,250 825,282 760,314 695,282"
                  fill="url(#blockDGrad)"
                  stroke="#fbbf24"
                  strokeWidth="1.5"
                />
                <polygon points="695,282 760,314 760,334 695,302" fill="#b45309" />
                <polygon points="825,282 760,314 760,334 825,302" fill="#d97706" />

                {/* Floor 2 */}
                <polygon
                  points="760,190 825,222 760,254 695,222"
                  fill="url(#blockDGrad)"
                  stroke="#fbbf24"
                  strokeWidth="1.5"
                />
                <polygon points="695,222 760,254 760,269 695,237" fill="#b45309" />
                <polygon points="825,222 760,254 760,269 825,237" fill="#d97706" />

                {/* Floor 3 */}
                <polygon
                  points="760,130 825,162 760,194 695,162"
                  fill="url(#blockDGrad)"
                  stroke="#fcd34d"
                  strokeWidth="2"
                />
                <polygon points="695,162 760,194 760,209 695,177" fill="#b45309" />
                <polygon points="825,162 760,194 760,209 825,177" fill="#d97706" />

                <circle cx="760" cy="140" r="5" fill="#f59e0b" />
                <text x="760" y="115" fill="#f59e0b" fontSize="12" fontWeight="bold" textAnchor="middle" fontFamily="sans-serif">
                  BLOCK D (33.5 kW)
                </text>
                <text x="760" y="355" fill="#94a3b8" fontSize="10" textAnchor="middle" fontFamily="monospace">
                  Eff: 89% • Innovation Hub
                </text>
              </g>
            </svg>
          </div>

          {/* Canvas Bottom Legend & Quick Hotspot Toggles */}
          <div className="flex flex-wrap items-center justify-between gap-3 pt-3 border-t border-slate-800 text-xs text-slate-400">
            <div className="flex items-center gap-4 flex-wrap">
              <span className="flex items-center gap-1.5 font-mono text-[11px]">
                <span className="w-2.5 h-2.5 rounded-full bg-cyan-400"></span> Block A (Academic)
              </span>
              <span className="flex items-center gap-1.5 font-mono text-[11px]">
                <span className="w-2.5 h-2.5 rounded-full bg-purple-400"></span> Block B (Labs/Compute)
              </span>
              <span className="flex items-center gap-1.5 font-mono text-[11px]">
                <span className="w-2.5 h-2.5 rounded-full bg-emerald-400"></span> Block C (Library)
              </span>
              <span className="flex items-center gap-1.5 font-mono text-[11px]">
                <span className="w-2.5 h-2.5 rounded-full bg-amber-400"></span> Block D (Innovation Hub)
              </span>
            </div>

            <div className="flex items-center gap-2">
              <button
                onClick={triggerAnomaly}
                className={`px-2.5 py-1 rounded text-[11px] font-mono font-bold transition cursor-pointer ${
                  activeAnomaly
                    ? "bg-rose-500 text-black shadow-md shadow-rose-500/30"
                    : "bg-slate-900 border border-slate-800 text-rose-300 hover:border-rose-700"
                }`}
              >
                {activeAnomaly ? "⚡ Anomaly Active (128 kW)" : "Inject Block B Spike"}
              </button>
            </div>
          </div>
        </div>

        {/* Right Deep Inspection Node Panel (4 cols) */}
        <div className="lg:col-span-4 bg-[#0b1329] border border-slate-800 rounded-2xl p-5 shadow-xl space-y-4 flex flex-col justify-between">
          <div className="space-y-4">
            <div className="flex items-start justify-between border-b border-slate-800 pb-3">
              <div>
                <span className="text-[10px] font-mono font-bold text-cyan-400 uppercase tracking-wider">
                  TELEMETRY INSPECTION NODE
                </span>
                <h3 className="text-base font-bold text-white mt-0.5">
                  {selectedNode.name}
                </h3>
                <span className="text-xs text-slate-400 font-mono">
                  Circuit: {selectedNode.chillerLoop}
                </span>
              </div>
              <div className="p-2 rounded-xl bg-slate-900 border border-slate-800 text-cyan-400">
                <Radio className="w-4 h-4 animate-pulse" />
              </div>
            </div>

            {/* Status Banner */}
            <div
              className={`p-3 rounded-xl border text-xs font-semibold ${
                selectedNode.status.includes("Alert") || selectedNode.status.includes("CRITICAL")
                  ? "bg-rose-950/40 border-rose-800 text-rose-200"
                  : "bg-emerald-950/40 border-emerald-800 text-emerald-200"
              }`}
            >
              {selectedNode.status}
            </div>

            {/* Electrical Telemetry 4-Pack */}
            <div className="grid grid-cols-2 gap-2.5">
              <div className="p-3 rounded-xl bg-slate-950 border border-slate-800/80">
                <span className="text-[10px] text-slate-400 font-mono uppercase">Instant Power</span>
                <div className="text-xl font-black text-cyan-300 font-mono mt-0.5">
                  {selectedNode.powerKW} kW
                </div>
                <span className="text-[10px] text-slate-500 font-mono">
                  {selectedNode.compressorAmps} Amps RMS
                </span>
              </div>

              <div className="p-3 rounded-xl bg-slate-950 border border-slate-800/80">
                <span className="text-[10px] text-slate-400 font-mono uppercase">Temperature</span>
                <div className="text-xl font-black text-amber-300 font-mono mt-0.5">
                  {selectedNode.tempC}°C
                </div>
                <span className="text-[10px] text-slate-500 font-mono">
                  Setpoint: {selectedNode.hvacSetpointC}°C
                </span>
              </div>

              <div className="p-3 rounded-xl bg-slate-950 border border-slate-800/80">
                <span className="text-[10px] text-slate-400 font-mono uppercase">Occupancy</span>
                <div className="text-xl font-black text-purple-300 font-mono mt-0.5">
                  {selectedNode.occupancyPct}%
                </div>
                <span className="text-[10px] text-slate-500 font-mono">
                  ~{selectedNode.headcount} Persons
                </span>
              </div>

              <div className="p-3 rounded-xl bg-slate-950 border border-slate-800/80">
                <span className="text-[10px] text-slate-400 font-mono uppercase">HVAC Duty</span>
                <div className="text-xl font-black text-blue-300 font-mono mt-0.5">
                  {selectedNode.hvacDutyPct}%
                </div>
                <span className="text-[10px] text-slate-500 font-mono">
                  Damper: {selectedNode.damperAngle}
                </span>
              </div>
            </div>

            {/* Micro-Parameters List */}
            <div className="p-3.5 rounded-xl bg-slate-950/80 border border-slate-800 text-xs space-y-2 font-mono">
              <div className="flex justify-between text-slate-400">
                <span>Phase Voltage:</span>
                <span className="text-slate-200">{electricalParams.voltage} V (Balanced)</span>
              </div>
              <div className="flex justify-between text-slate-400">
                <span>Power Factor (cos φ):</span>
                <span className="text-emerald-400">{electricalParams.powerFactor}</span>
              </div>
              <div className="flex justify-between text-slate-400">
                <span>Total Harmonic Distortion:</span>
                <span className="text-slate-200">{selectedNode.harmonicsTHD}</span>
              </div>
              <div className="flex justify-between text-slate-400">
                <span>Indoor CO₂ Level:</span>
                <span className="text-slate-200">{selectedNode.co2Ppm} ppm (Good)</span>
              </div>
            </div>
          </div>

          <div className="pt-2">
            <button
              onClick={() => {
                setSelectedBuilding(selectedNode.building === "Block A" ? "block-a" : selectedNode.building === "Block B" ? "block-b" : "block-c");
              }}
              className="w-full py-2.5 rounded-xl bg-gradient-to-r from-cyan-500 to-blue-600 hover:from-cyan-400 hover:to-blue-500 text-black font-extrabold text-xs uppercase tracking-wider shadow-lg shadow-cyan-500/20 cursor-pointer transition text-center"
            >
              Drill Into Building Sub-Panels
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
