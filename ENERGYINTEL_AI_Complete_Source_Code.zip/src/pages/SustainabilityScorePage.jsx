import React from "react";
import {
  Award,
  ShieldCheck,
  TrendingUp,
  CheckCircle2,
  AlertCircle,
  HelpCircle,
  ArrowRight,
  Sparkles,
  Zap
} from "lucide-react";
import { useEnergy } from "../context/EnergyContext";

export function SustainabilityScorePage() {
  const {
    sustainabilityScore,
    energyEfficiencyPct,
    potentialWastageKWh,
    todayEnergyKWh,
    appliedRecommendations
  } = useEnergy();

  const factors = [
    {
      name: "Energy Efficiency Benchmark",
      weight: "30%",
      score: Math.min(100, Math.round((energyEfficiencyPct / 100) * 100)),
      desc: "Measures actual useful electrical work delivered vs avoidable thermodynamic loss across lighting and chiller circuits."
    },
    {
      name: "Wastage Control Ratio",
      weight: "20%",
      score: Math.max(0, Math.round((1 - (potentialWastageKWh / todayEnergyKWh)) * 100)),
      desc: "Proportion of campus daily energy not wasted in zero-occupancy or after-hours overrun incidents."
    },
    {
      name: "Peak Demand Management",
      weight: "15%",
      score: 84,
      desc: "Effectiveness of pre-cooling schedules and load shedding in keeping maximum demand below the 100 kW ceiling."
    },
    {
      name: "Occupancy-Coupled Dispatch",
      weight: "15%",
      score: 88,
      desc: "Correlation between live headcount sensors and dynamic HVAC zone dampers and lighting lux levels."
    },
    {
      name: "Power Quality & Power Factor",
      weight: "10%",
      score: 95,
      desc: "Maintenance of 3-phase line power factor at 0.95+ to minimize reactive inductive losses."
    },
    {
      name: "AI Remediation Response",
      weight: "10%",
      score: Math.min(100, 70 + (appliedRecommendations.size * 10)),
      desc: "Speed and adoption rate of facility management in acknowledging and executing AI recommendations."
    }
  ];

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 p-5 rounded-2xl bg-gradient-to-r from-teal-950/50 via-slate-900 to-emerald-950/50 border border-teal-500/30">
        <div>
          <div className="flex items-center gap-2">
            <span className="px-2.5 py-0.5 rounded-full bg-teal-950 border border-teal-700 text-teal-300 font-mono text-[10px] font-bold uppercase tracking-wider">
              ESG & SUSTAINABILITY INDEX
            </span>
            <span className="text-xs text-teal-300">
              Trident Campus Composite Score
            </span>
          </div>
          <h1 className="text-2xl font-black text-white mt-1">
            Campus Energy Sustainability Score
          </h1>
          <p className="text-xs text-slate-300 mt-0.5">
            A comprehensive 0–100 algorithmic benchmark evaluating overall campus efficiency, peak resilience, and automated conservation.
          </p>
        </div>

        {/* Master Score Dial Box */}
        <div className="p-4 rounded-xl bg-slate-900/90 border border-teal-500/40 text-center min-w-[190px]">
          <span className="text-[10px] text-slate-400 font-mono uppercase">COMPOSITE SCORE</span>
          <div className="text-4xl font-black text-emerald-400 font-mono mt-0.5 flex items-baseline justify-center gap-1">
            <span>{sustainabilityScore}</span>
            <span className="text-lg text-slate-400 font-normal">/ 100</span>
          </div>
          <span className="text-[11px] font-mono text-teal-300 font-bold uppercase">
            GRADE: {sustainabilityScore >= 85 ? "EXCELLENT (A)" : "GOOD (B+)"}
          </span>
        </div>
      </div>

      {/* 6 Score Factor Breakdown Cards (Requirement 31) */}
      <div className="space-y-3">
        <div className="flex items-center justify-between">
          <h2 className="text-base font-bold text-white flex items-center gap-2">
            <Award className="w-5 h-5 text-emerald-400" />
            <span>Underlying Component Factors (Weighted Model)</span>
          </h2>
          <span className="text-xs text-slate-400 font-mono">
            6 Normalized Dimensions
          </span>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {factors.map((f, idx) => (
            <div
              key={idx}
              className="p-5 rounded-2xl bg-[#0b1329] border border-slate-800 space-y-3"
            >
              <div className="flex items-start justify-between">
                <div>
                  <span className="text-[10px] font-mono font-bold text-cyan-400 uppercase">
                    WEIGHT: {f.weight}
                  </span>
                  <h3 className="text-sm font-bold text-white mt-0.5">{f.name}</h3>
                </div>
                <div className="text-xl font-black font-mono text-emerald-400">
                  {f.score}%
                </div>
              </div>

              {/* Progress Bar */}
              <div className="w-full h-1.5 bg-slate-900 rounded-full overflow-hidden">
                <div
                  className="h-full bg-gradient-to-r from-cyan-400 to-emerald-400 rounded-full"
                  style={{ width: `${f.score}%` }}
                ></div>
              </div>

              <p className="text-xs text-slate-400 leading-relaxed">
                {f.desc}
              </p>
            </div>
          ))}
        </div>
      </div>

      {/* Transparent Formula Explanation (Requirement 31) */}
      <div className="p-6 rounded-2xl bg-gradient-to-br from-slate-900 to-[#0b1329] border border-slate-800 space-y-3">
        <h2 className="text-sm font-bold text-white flex items-center gap-2">
          <HelpCircle className="w-4 h-4 text-cyan-400" />
          <span>How the Campus Sustainability Score is Mathematically Formulated</span>
        </h2>
        <p className="text-xs text-slate-300 leading-relaxed">
          The Composite Score is evaluated continuously using a linear weighted combination of normalized metrics:
        </p>

        <div className="p-3.5 rounded-xl bg-slate-950 font-mono text-xs text-cyan-300 border border-slate-800 overflow-x-auto">
          Score = (0.30 × Efficiency) + (0.20 × WastageRatio) + (0.15 × PeakShaving) + (0.15 × OccupancyCoupling) + (0.10 × PowerFactor) + (0.10 × AI_Remediation)
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 pt-2 text-xs text-slate-400">
          <div className="flex items-center gap-2">
            <CheckCircle2 className="w-4 h-4 text-emerald-400" />
            <span>Score &gt; 85: Optimal Autonomous Operation</span>
          </div>
          <div className="flex items-center gap-2">
            <AlertCircle className="w-4 h-4 text-amber-400" />
            <span>Score 70–84: Moderate After-Hours Wastage</span>
          </div>
          <div className="flex items-center gap-2">
            <AlertCircle className="w-4 h-4 text-rose-400" />
            <span>Score &lt; 70: Urgent Human Intervention Required</span>
          </div>
        </div>
      </div>
    </div>
  );
}
