import React, { useState, useEffect } from "react";
import {
  FileSpreadsheet,
  Download,
  CheckCircle2,
  Clock,
  Zap,
  Activity,
  Layers,
  Sparkles,
  RotateCcw,
  ShieldCheck,
  Building2,
  Table,
  Radio
} from "lucide-react";
import { useEnergy } from "../context/EnergyContext";
import { export1HourSecondTelemetry } from "../services/exportUtils";

export function CsvImportPage() {
  const {
    campusConfig,
    applianceSpecs,
    currentPowerKW,
    todayEnergyKWh,
    electricalParams,
    environmentalParams,
    elapsedSimulationSeconds,
    hasAutoDownloaded1Hr,
    triggerFastForward1Hour,
    download1HourDataset,
    resetOneHourTimer
  } = useEnergy();

  const [liveStreamRows, setLiveStreamRows] = useState([]);
  const [downloadFormat, setDownloadFormat] = useState("excel"); // "excel" | "csv"

  // Live second-by-second rolling buffer of recent telemetry frames (last 10 seconds)
  useEffect(() => {
    const timestamp = new Date().toTimeString().split(" ")[0];
    const bldgs = campusConfig.buildings || [];
    const randomBldg = bldgs[elapsedSimulationSeconds % bldgs.length] || { name: "Building 1 — Block A", floors: [] };
    const floorIndex = (Math.floor(elapsedSimulationSeconds / 4)) % 3;
    const floorName = `Floor ${floorIndex + 1}`;

    const newRow = {
      second: elapsedSimulationSeconds + 1,
      time: timestamp,
      building: randomBldg.name.split("—")[0].trim(),
      floor: floorName,
      bulbs: 14 + (elapsedSimulationSeconds % 5),
      fans: 6 + (elapsedSimulationSeconds % 4),
      acs: 2 + (elapsedSimulationSeconds % 3),
      powerKW: Number(((14 * 20 + 6 * 75 + 2 * 2000) / 1000).toFixed(2)),
      campusKW: currentPowerKW,
      voltage: electricalParams.voltage,
      current: electricalParams.current,
      pf: electricalParams.powerFactor,
      co2Kg: Number(((currentPowerKW / 3600) * 0.82).toFixed(4))
    };

    setLiveStreamRows(prev => [newRow, ...prev.slice(0, 9)]);
  }, [elapsedSimulationSeconds, currentPowerKW, electricalParams, campusConfig]);

  const minutesElapsed = Math.floor(elapsedSimulationSeconds / 60);
  const secondsRemainder = elapsedSimulationSeconds % 60;
  const timeFormatted = `${String(minutesElapsed).padStart(2, "0")}:${String(secondsRemainder).padStart(2, "0")}`;
  const pct1Hr = Math.min(100, Math.round((elapsedSimulationSeconds / 3600) * 100));

  const handleManualDownload = (fmt) => {
    download1HourDataset(fmt);
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 p-5 rounded-2xl bg-gradient-to-r from-cyan-950/60 via-slate-900 to-blue-950/50 border border-cyan-500/40 shadow-xl">
        <div>
          <div className="flex items-center gap-2">
            <span className="px-2.5 py-0.5 rounded-full bg-cyan-950 border border-cyan-700 text-cyan-300 font-mono text-[10px] font-bold uppercase tracking-wider flex items-center gap-1.5">
              <Activity className="w-3.5 h-3.5 text-cyan-400" />
              1-SECOND TELEMETRY ENGINE (1 Hz)
            </span>
            <span className="text-[11px] font-mono text-emerald-400 font-semibold flex items-center gap-1">
              <span className="w-2 h-2 rounded-full bg-emerald-400 animate-ping"></span>
              ACTIVE STREAM
            </span>
          </div>
          <h1 className="text-2xl font-black text-white mt-1">
            1-Hour Simulation Telemetry & Real-Time Data Export Center
          </h1>
          <p className="text-xs text-slate-300 mt-0.5">
            Real-time second-by-second physical energy telemetry across all 4 Buildings (Block A, B, C, D) and 12 floors.
            Auto-downloads full 1-hour dataset (3,600 records) upon reaching 60:00 runtime.
          </p>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={() => handleManualDownload("excel")}
            className="px-3.5 py-2 rounded-xl bg-emerald-500/20 hover:bg-emerald-500/30 text-emerald-300 border border-emerald-500/50 text-xs font-bold font-mono flex items-center gap-1.5 cursor-pointer transition shadow-md shadow-emerald-500/20"
          >
            <FileSpreadsheet className="w-4 h-4 text-emerald-400" />
            <span>Download 1-Hr Excel (.xls)</span>
          </button>
          <button
            onClick={() => handleManualDownload("csv")}
            className="px-3.5 py-2 rounded-xl bg-cyan-500/20 hover:bg-cyan-500/30 text-cyan-300 border border-cyan-500/50 text-xs font-bold font-mono flex items-center gap-1.5 cursor-pointer transition shadow-md shadow-cyan-500/20"
          >
            <Download className="w-4 h-4 text-cyan-400" />
            <span>Download 1-Hr CSV (.csv)</span>
          </button>
        </div>
      </div>

      {/* 1-Hour Simulation Progress Card */}
      <div className="bg-[#0b1329] border border-cyan-500/30 rounded-2xl p-6 shadow-xl relative overflow-hidden">
        <div className="absolute top-0 right-0 w-80 h-80 bg-cyan-500/5 rounded-full blur-3xl pointer-events-none"></div>

        <div className="flex flex-col lg:flex-row items-start lg:items-center justify-between gap-6">
          <div className="space-y-3 flex-1">
            <div className="flex items-center gap-2">
              <span className="text-xs font-mono font-bold text-cyan-400 uppercase tracking-wider">
                1-HOUR CONTINUOUS SIMULATION PROGRESS
              </span>
              <span className="px-2 py-0.5 rounded-full bg-slate-800 text-slate-300 font-mono text-[10px]">
                {elapsedSimulationSeconds} / 3600 SECONDS
              </span>
            </div>

            <div className="flex items-baseline gap-3">
              <span className="text-4xl sm:text-5xl font-black text-white font-mono tracking-tight">
                {timeFormatted}
              </span>
              <span className="text-slate-400 font-mono text-lg">/ 60:00 (1 Hour)</span>
              <span className="text-emerald-400 font-bold font-mono text-xl ml-2">
                {pct1Hr}% Completed
              </span>
            </div>

            {/* Progress Bar */}
            <div className="w-full bg-slate-950 rounded-full h-3.5 p-0.5 border border-slate-800 overflow-hidden">
              <div
                className="h-full bg-gradient-to-r from-cyan-500 via-blue-500 to-emerald-400 rounded-full transition-all duration-500 shadow-md shadow-cyan-500/40"
                style={{ width: `${pct1Hr}%` }}
              ></div>
            </div>

            <div className="flex flex-wrap items-center justify-between text-xs text-slate-400 gap-2">
              <span className="flex items-center gap-1.5">
                <ShieldCheck className="w-4 h-4 text-emerald-400" />
                <span>Zero File Upload Required — Live Simulation Data Streaming</span>
              </span>
              <span className="font-mono text-cyan-300">
                Auto-download triggers at 60:00 (3,600s)
              </span>
            </div>
          </div>

          {/* Quick Action Test Panel for Evaluators / Judges */}
          <div className="bg-slate-950/80 border border-slate-800 rounded-xl p-4 flex flex-col gap-2.5 w-full lg:w-80">
            <span className="text-[10px] font-mono font-bold text-slate-400 uppercase tracking-wider">
              EVALUATOR QUICK-TEST CONTROLS
            </span>
            <p className="text-[11px] text-slate-400">
              Skip waiting 60 real minutes by fast-forwarding the 1-hour simulation buffer and exporting the dataset immediately:
            </p>

            <button
              onClick={() => triggerFastForward1Hour("excel")}
              className="w-full py-2.5 px-3 rounded-xl bg-gradient-to-r from-emerald-600 to-teal-600 hover:from-emerald-500 hover:to-teal-500 text-white font-bold text-xs flex items-center justify-center gap-2 cursor-pointer transition shadow-lg shadow-emerald-600/30 font-mono"
            >
              <Zap className="w-4 h-4 text-amber-300 fill-amber-300" />
              <span>Fast-Forward & Export 1-Hr Excel</span>
            </button>

            <button
              onClick={() => triggerFastForward1Hour("csv")}
              className="w-full py-2 px-3 rounded-xl bg-slate-900 hover:bg-slate-800 text-cyan-300 border border-slate-700 font-bold text-xs flex items-center justify-center gap-2 cursor-pointer transition font-mono"
            >
              <Download className="w-4 h-4 text-cyan-400" />
              <span>Fast-Forward & Export 1-Hr CSV</span>
            </button>

            <button
              onClick={resetOneHourTimer}
              className="w-full py-1.5 px-3 rounded-lg bg-slate-950 hover:bg-slate-900 text-slate-400 hover:text-slate-200 border border-slate-800 text-[11px] flex items-center justify-center gap-1.5 cursor-pointer transition font-mono"
            >
              <RotateCcw className="w-3.5 h-3.5" />
              <span>Reset 1-Hour Timer</span>
            </button>
          </div>
        </div>

        {hasAutoDownloaded1Hr && (
          <div className="mt-4 p-3 rounded-xl bg-emerald-950/60 border border-emerald-600 text-emerald-200 text-xs flex items-center gap-2 font-medium">
            <CheckCircle2 className="w-4 h-4 text-emerald-400 flex-shrink-0" />
            <span>
              1-Hour Simulation Completed! The high-resolution 3,600-second dataset has been exported automatically. You may also download it manually anytime using the buttons above.
            </span>
          </div>
        )}
      </div>

      {/* Campus Configuration Specifications Card (4 Buildings, 12 Floors) */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <div className="p-4 rounded-xl bg-[#0b1329] border border-slate-800 space-y-1">
          <span className="text-[10px] font-mono text-cyan-400 uppercase font-bold">CAMPUS EXTENT</span>
          <h4 className="text-xl font-bold text-white">4 Buildings / Blocks</h4>
          <p className="text-xs text-slate-400">Block A, Block B, Block C, Block D</p>
        </div>

        <div className="p-4 rounded-xl bg-[#0b1329] border border-slate-800 space-y-1">
          <span className="text-[10px] font-mono text-purple-400 uppercase font-bold">SUB-METERED ZONES</span>
          <h4 className="text-xl font-bold text-white">12 Floors Total</h4>
          <p className="text-xs text-slate-400">3 Floors each with dedicated IoT telemetry</p>
        </div>

        <div className="p-4 rounded-xl bg-[#0b1329] border border-slate-800 space-y-1">
          <span className="text-[10px] font-mono text-amber-400 uppercase font-bold">PER-FLOOR APPLIANCES</span>
          <h4 className="text-xl font-bold text-white">20 Bulbs • 10 Fans • 5 ACs</h4>
          <p className="text-xs text-slate-400">20W Bulbs, 75W Fans, 2000W Split ACs</p>
        </div>

        <div className="p-4 rounded-xl bg-[#0b1329] border border-slate-800 space-y-1">
          <span className="text-[10px] font-mono text-emerald-400 uppercase font-bold">SAMPLING INTERVAL</span>
          <h4 className="text-xl font-bold text-white">1.0s (1 Hz) Telemetry</h4>
          <p className="text-xs text-slate-400">3,600 Second Records per Simulation Hour</p>
        </div>
      </div>

      {/* Live Second-by-Second Telemetry Table (Refreshes Every Second) */}
      <div className="bg-[#0b1329] border border-slate-800 rounded-2xl p-5 shadow-xl space-y-4">
        <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 border-b border-slate-800 pb-3">
          <div>
            <h2 className="text-base font-bold text-white flex items-center gap-2">
              <Radio className="w-4 h-4 text-cyan-400 animate-pulse" />
              <span>Live Telemetry Frame Stream (Refreshing Every 1 Second)</span>
            </h2>
            <p className="text-xs text-slate-400">
              Showing the latest second-by-second telemetry records buffered from the active simulation model.
            </p>
          </div>

          <div className="flex items-center gap-2 text-xs font-mono">
            <span className="px-2.5 py-1 rounded-lg bg-slate-900 border border-slate-800 text-slate-300">
              Refresh: <span className="text-cyan-400 font-bold">1,000 ms</span>
            </span>
            <span className="px-2.5 py-1 rounded-lg bg-slate-900 border border-slate-800 text-slate-300">
              Buffer Depth: <span className="text-emerald-400 font-bold">3,600s</span>
            </span>
          </div>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs font-mono">
            <thead className="bg-slate-950/80 text-slate-400 uppercase text-[10px] border-b border-slate-800">
              <tr>
                <th className="py-2.5 px-3">Sec</th>
                <th className="py-2.5 px-3">Time</th>
                <th className="py-2.5 px-3">Building Sample</th>
                <th className="py-2.5 px-3">Floor</th>
                <th className="py-2.5 px-3">Bulbs (20W)</th>
                <th className="py-2.5 px-3">Fans (75W)</th>
                <th className="py-2.5 px-3">ACs (2kW)</th>
                <th className="py-2.5 px-3">Floor (kW)</th>
                <th className="py-2.5 px-3">Campus Net (kW)</th>
                <th className="py-2.5 px-3">Volts (V)</th>
                <th className="py-2.5 px-3">Current (A)</th>
                <th className="py-2.5 px-3">PF</th>
                <th className="py-2.5 px-3">CO2 Rate (kg)</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/60 text-slate-300">
              {liveStreamRows.map((row, idx) => (
                <tr
                  key={idx}
                  className={idx === 0 ? "bg-cyan-500/10 text-cyan-200 font-semibold" : "hover:bg-slate-900/40"}
                >
                  <td className="py-2 px-3 text-cyan-400 font-bold">#{row.second}</td>
                  <td className="py-2 px-3 text-slate-400">{row.time}</td>
                  <td className="py-2 px-3 text-white font-medium">{row.building}</td>
                  <td className="py-2 px-3 text-slate-300">{row.floor}</td>
                  <td className="py-2 px-3 text-amber-300">{row.bulbs} / 20</td>
                  <td className="py-2 px-3 text-blue-300">{row.fans} / 10</td>
                  <td className="py-2 px-3 text-cyan-300 font-bold">{row.acs} / 5</td>
                  <td className="py-2 px-3 text-purple-300 font-bold">{row.powerKW} kW</td>
                  <td className="py-2 px-3 text-emerald-400 font-bold">{row.campusKW} kW</td>
                  <td className="py-2 px-3 text-slate-300">{row.voltage} V</td>
                  <td className="py-2 px-3 text-slate-300">{row.current} A</td>
                  <td className="py-2 px-3 text-emerald-400">{row.pf}</td>
                  <td className="py-2 px-3 text-slate-400">{row.co2Kg}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
export default CsvImportPage;
