import React, { useState } from "react";
import {
  MessageSquareWarning,
  Sparkles,
  Search,
  Filter,
  CheckCircle2,
  Clock,
  Plus,
  Tag,
  Building,
  Brain,
  Layers,
  Flame,
  AlertTriangle,
  RotateCcw
} from "lucide-react";
import { useEnergy } from "../context/EnergyContext";

export function ComplaintAnalyticsPage() {
  const {
    complaints,
    addComplaint,
    toggleComplaintStatus,
    complaintAnalytics
  } = useEnergy();

  const [searchTerm, setSearchTerm] = useState("");
  const [selectedCategory, setSelectedCategory] = useState("all");
  const [selectedStatus, setSelectedStatus] = useState("all");

  // New complaint form modal
  const [showAddModal, setShowAddModal] = useState(false);
  const [newCmp, setNewCmp] = useState({
    building: "Block B",
    floor: "Floor 2",
    room: "Lab 205",
    category: "AC",
    text: "AC running excessively cold while room is empty during afternoon.",
    urgency: "Medium"
  });

  const categories = ["all", "AC", "Lighting", "Electrical", "Equipment", "Infrastructure"];

  const filteredComplaints = complaints.filter(c => {
    const matchesSearch = c.text.toLowerCase().includes(searchTerm.toLowerCase()) ||
                          c.building.toLowerCase().includes(searchTerm.toLowerCase()) ||
                          c.room.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesCat = selectedCategory === "all" || c.category === selectedCategory;
    const matchesStat = selectedStatus === "all" ||
                        (selectedStatus === "resolved" && c.status === "Resolved") ||
                        (selectedStatus === "open" && c.status !== "Resolved");
    return matchesSearch && matchesCat && matchesStat;
  });

  const handleCreateComplaint = (e) => {
    e.preventDefault();
    addComplaint(newCmp);
    setShowAddModal(false);
    setNewCmp({
      building: "Block B",
      floor: "Floor 2",
      room: "",
      category: "AC",
      text: "",
      urgency: "Medium"
    });
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 p-5 rounded-2xl bg-gradient-to-r from-purple-950/50 via-slate-900 to-indigo-950/50 border border-purple-500/30">
        <div>
          <div className="flex items-center gap-2">
            <span className="px-2.5 py-0.5 rounded-full bg-purple-950 border border-purple-700 text-purple-300 font-mono text-[10px] font-bold uppercase tracking-wider">
              FACILITY INCIDENT NLP
            </span>
            <span className="text-xs text-purple-300">
              Unstructured Feedback Intelligence
            </span>
          </div>
          <h1 className="text-2xl font-black text-white mt-1">
            Facility Complaint Analytics & NLP Intelligence
          </h1>
          <p className="text-xs text-slate-300 mt-0.5">
            Extracting recurring thermal comfort and electrical wastage patterns directly from occupant tickets.
          </p>
        </div>

        <button
          onClick={() => setShowAddModal(true)}
          className="px-4 py-2.5 rounded-xl bg-cyan-500 hover:bg-cyan-400 text-black font-bold text-xs uppercase tracking-wider flex items-center gap-2 cursor-pointer shadow-lg shadow-cyan-500/20"
        >
          <Plus className="w-4 h-4" />
          <span>Add Facility Ticket</span>
        </button>
      </div>

      {/* NLP Intelligence Summary Cards (Requirement 35) */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        {/* Card 1: Top Hotspot */}
        <div className="p-5 rounded-2xl bg-[#0b1329] border border-rose-500/40 space-y-2">
          <span className="text-xs font-mono font-bold text-slate-400 uppercase">
            PRIMARY COMPLAINT HOTSPOT
          </span>
          <div className="text-xl font-bold text-rose-300">
            {complaintAnalytics.topHotspot.location}
          </div>
          <p className="text-xs text-slate-400">
            {complaintAnalytics.topHotspot.count} complaints logged. Correlates directly with AI Case 2 AC Wastage.
          </p>
        </div>

        {/* Card 2: Recurring Problem Extractor */}
        <div className="p-5 rounded-2xl bg-[#0b1329] border border-amber-500/40 space-y-2">
          <span className="text-xs font-mono font-bold text-slate-400 uppercase">
            RECURRING PATTERN IDENTIFIED
          </span>
          <div className="text-lg font-bold text-amber-300">
            Thermal Overcooling & "AC Not Cooling"
          </div>
          <p className="text-xs text-slate-400">
            Occupants reporting extreme temperature swings due to manual thermostat overrides.
          </p>
        </div>

        {/* Card 3: NLP Keywords Cloud */}
        <div className="p-5 rounded-2xl bg-[#0b1329] border border-slate-800 space-y-2">
          <span className="text-xs font-mono font-bold text-slate-400 uppercase">
            TOP EXTRACTED NLP KEYWORDS
          </span>
          <div className="flex flex-wrap gap-1.5 pt-1">
            {complaintAnalytics.topKeywords.slice(0, 8).map((k, idx) => (
              <span
                key={idx}
                className="text-[11px] font-mono px-2 py-0.5 rounded-full bg-slate-900 border border-slate-700 text-cyan-300"
              >
                #{k.word} ({k.count})
              </span>
            ))}
          </div>
        </div>
      </div>

      {/* Search & Filter Toolbar (Requirement 34) */}
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 p-3.5 rounded-xl bg-[#0b1329] border border-slate-800 text-xs">
        <div className="relative w-full sm:w-72">
          <Search className="w-4 h-4 text-slate-500 absolute left-3 top-2.5" />
          <input
            type="text"
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            placeholder="Search tickets, rooms, buildings..."
            className="w-full bg-slate-950 border border-slate-800 rounded-xl pl-9 pr-3 py-2 text-white placeholder-slate-600 focus:outline-none focus:border-cyan-400"
          />
        </div>

        <div className="flex items-center gap-2 flex-wrap">
          <select
            value={selectedCategory}
            onChange={(e) => setSelectedCategory(e.target.value)}
            className="bg-slate-950 text-slate-200 border border-slate-800 rounded-lg px-2.5 py-1.5 text-xs font-medium focus:outline-none focus:border-cyan-400"
          >
            {categories.map((c) => (
              <option key={c} value={c}>
                {c === "all" ? "All Categories" : c}
              </option>
            ))}
          </select>

          <select
            value={selectedStatus}
            onChange={(e) => setSelectedStatus(e.target.value)}
            className="bg-slate-950 text-slate-200 border border-slate-800 rounded-lg px-2.5 py-1.5 text-xs font-medium focus:outline-none focus:border-cyan-400"
          >
            <option value="all">All Statuses</option>
            <option value="open">Open / Pending</option>
            <option value="resolved">Resolved</option>
          </select>
        </div>
      </div>

      {/* Complaints List (Requirement 34) */}
      <div className="space-y-3">
        {filteredComplaints.length === 0 ? (
          <div className="p-8 text-center text-slate-500 rounded-xl border border-slate-800">
            No complaints match the filter criteria.
          </div>
        ) : (
          filteredComplaints.map((c) => {
            const isResolved = c.status === "Resolved";
            return (
              <div
                key={c.id}
                className={`p-4 rounded-xl border transition-all flex flex-col md:flex-row items-start md:items-center justify-between gap-4 ${
                  isResolved
                    ? "bg-slate-950/60 border-slate-800/60 opacity-60"
                    : "bg-[#0b1329] border-slate-800 hover:border-slate-700"
                }`}
              >
                <div className="space-y-1.5">
                  <div className="flex items-center gap-2 flex-wrap">
                    <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-slate-900 text-cyan-300 border border-slate-800">
                      {c.category}
                    </span>
                    <span className="text-xs font-semibold text-white">
                      📍 {c.building} ({c.floor}, {c.room})
                    </span>
                    <span className="text-xs text-slate-500">•</span>
                    <span className="text-[11px] text-slate-400 font-mono">{c.date}</span>
                    <span
                      className={`text-[10px] font-mono px-2 py-0.5 rounded font-bold ${
                        c.urgency === "Critical"
                          ? "bg-rose-950 text-rose-300 border border-rose-800"
                          : "bg-amber-950 text-amber-300 border border-amber-800"
                      }`}
                    >
                      {c.urgency} Urgency
                    </span>
                  </div>

                  <p className="text-xs text-slate-300 leading-relaxed max-w-3xl">
                    "{c.text}"
                  </p>
                </div>

                <div className="flex items-center gap-2 whitespace-nowrap">
                  <button
                    onClick={() => toggleComplaintStatus(c.id)}
                    className={`px-3 py-1.5 rounded-xl text-xs font-semibold cursor-pointer transition ${
                      isResolved
                        ? "bg-slate-800 text-slate-400 hover:text-white"
                        : "bg-emerald-500/20 text-emerald-300 border border-emerald-500/50 hover:bg-emerald-500/30"
                    }`}
                  >
                    {isResolved ? "Reopen Ticket" : "Mark Resolved"}
                  </button>
                </div>
              </div>
            );
          })
        )}
      </div>

      {/* Add Complaint Modal */}
      {showAddModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 backdrop-blur-sm p-4">
          <div className="bg-[#0b1329] border border-cyan-500/40 rounded-2xl p-6 max-w-md w-full space-y-4 shadow-2xl">
            <h3 className="text-base font-bold text-white flex items-center gap-2">
              <MessageSquareWarning className="w-5 h-5 text-cyan-400" />
              <span>Log Facility Complaint</span>
            </h3>

            <form onSubmit={handleCreateComplaint} className="space-y-3 text-xs">
              <div>
                <label className="block text-slate-400 mb-1 font-mono">BUILDING & FLOOR</label>
                <div className="grid grid-cols-2 gap-2">
                  <select
                    value={newCmp.building}
                    onChange={(e) => setNewCmp({ ...newCmp, building: e.target.value })}
                    className="bg-slate-950 border border-slate-700 rounded-lg p-2 text-white"
                  >
                    <option value="Block A">Block A</option>
                    <option value="Block B">Block B</option>
                    <option value="Block C">Block C</option>
                    <option value="Block D">Block D</option>
                  </select>
                  <select
                    value={newCmp.floor}
                    onChange={(e) => setNewCmp({ ...newCmp, floor: e.target.value })}
                    className="bg-slate-950 border border-slate-700 rounded-lg p-2 text-white"
                  >
                    <option value="Floor 1">Floor 1</option>
                    <option value="Floor 2">Floor 2</option>
                    <option value="Floor 3">Floor 3</option>
                  </select>
                </div>
              </div>

              <div>
                <label className="block text-slate-400 mb-1 font-mono">ROOM / ZONE</label>
                <input
                  type="text"
                  required
                  placeholder="e.g. Lab 204 or Lecture Hall 101"
                  value={newCmp.room}
                  onChange={(e) => setNewCmp({ ...newCmp, room: e.target.value })}
                  className="w-full bg-slate-950 border border-slate-700 rounded-lg p-2 text-white"
                />
              </div>

              <div>
                <label className="block text-slate-400 mb-1 font-mono">CATEGORY</label>
                <select
                  value={newCmp.category}
                  onChange={(e) => setNewCmp({ ...newCmp, category: e.target.value })}
                  className="w-full bg-slate-950 border border-slate-700 rounded-lg p-2 text-white"
                >
                  <option value="AC">AC / HVAC</option>
                  <option value="Lighting">Lighting</option>
                  <option value="Electrical">Electrical Circuit</option>
                  <option value="Equipment">Lab Equipment</option>
                  <option value="Infrastructure">Infrastructure</option>
                </select>
              </div>

              <div>
                <label className="block text-slate-400 mb-1 font-mono">COMPLAINT DESCRIPTION</label>
                <textarea
                  rows="3"
                  required
                  placeholder="Describe thermal discomfort or lights left on..."
                  value={newCmp.text}
                  onChange={(e) => setNewCmp({ ...newCmp, text: e.target.value })}
                  className="w-full bg-slate-950 border border-slate-700 rounded-lg p-2 text-white"
                ></textarea>
              </div>

              <div className="flex justify-end gap-2 pt-2">
                <button
                  type="button"
                  onClick={() => setShowAddModal(false)}
                  className="px-3 py-1.5 rounded-lg bg-slate-800 text-slate-300"
                >
                  Cancel
                </button>
                <button
                  type="submit"
                  className="px-4 py-1.5 rounded-lg bg-cyan-500 text-black font-bold"
                >
                  Submit Ticket
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}
