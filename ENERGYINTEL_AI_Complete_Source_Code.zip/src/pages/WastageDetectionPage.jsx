import React, { useState } from "react";
import {
  AlertTriangle,
  AlertOctagon,
  Trash2,
  Moon,
  Sun,
  Flame,
  ArrowRight,
  ShieldAlert,
  Sliders,
  CheckCircle2,
  Building,
  Zap,
  Activity,
  Layers,
  Sparkles,
  Clock,
  Coffee,
  Lightbulb
} from "lucide-react";
import {
  ResponsiveContainer,
  ComposedChart,
  Area,
  Line,
  Bar,
  XAxis,
  YAxis,
  Tooltip,
  Legend,
  CartesianGrid,
  ReferenceArea
} from "recharts";
import { useEnergy } from "../context/EnergyContext";
import { ANOMALY_CASES } from "../services/aiAnomalyService";

function CustomWastageTooltip({ active, payload, label }) {
  if (active && payload && payload.length) {
    const data = payload[0].payload;
    return (
      <div className="p-3.5 rounded-xl bg-[#070b14] border border-slate-700 shadow-2xl text-xs space-y-2 font-mono max-w-sm">
        <div className="flex items-center justify-between border-b border-slate-800 pb-1.5">
          <span className="font-black text-cyan-300 text-sm">{label}</span>
          <span className={`px-2 py-0.5 rounded text-[10px] font-bold ${
            data.isLunchBreak 
              ? "bg-purple-950 text-purple-300 border border-purple-800" 
              : data.isOfficialWorking 
              ? "bg-emerald-950 text-emerald-300 border border-emerald-800" 
              : "bg-rose-950 text-rose-300 border border-rose-800"
          }`}>
            {data.status}
          </span>
        </div>

        <div className="grid grid-cols-2 gap-1.5 text-[11px]">
          <span className="text-slate-400">Actual Campus Draw:</span>
          <span className="text-white font-bold text-right">{data.actual} kW</span>

          <span className="text-slate-400">Baseline Expected:</span>
          <span className="text-emerald-400 text-right">{data.baseline} kW</span>

          <span className="text-slate-400">Campus Occupancy:</span>
          <span className="text-cyan-300 text-right">{data.occupancyPct}%</span>

          <span className="text-slate-400">Ambient Temp:</span>
          <span className="text-amber-300 text-right">{data.temperature}°C</span>
        </div>

        {data.wastageKW > 0 && (
          <div className="pt-2 border-t border-slate-800 space-y-1 text-[11px]">
            <div className="text-rose-400 font-bold flex justify-between">
              <span>Total Wastage:</span>
              <span>{data.wastageKW} kW (₹{Math.round(data.wastageKW * 8)}/hr loss)</span>
            </div>
            {data.corridorWasteKW > 0 && (
              <div className="text-amber-400 text-[10px] flex justify-between pl-1">
                <span>↳ Stair/Corridor Lights (Off-Hours):</span>
                <span className="font-bold">+{data.corridorWasteKW} kW</span>
              </div>
            )}
            {data.lunchWasteKW > 0 && (
              <div className="text-purple-400 text-[10px] flex justify-between pl-1">
                <span>↳ Lunch Break Vacant AC/Lights:</span>
                <span className="font-bold">+{data.lunchWasteKW} kW</span>
              </div>
            )}
            {data.equipmentIdleWasteKW > 0 && (
              <div className="text-slate-400 text-[10px] flex justify-between pl-1">
                <span>↳ Standby Equipment/Overrun:</span>
                <span className="font-bold">+{data.equipmentIdleWasteKW} kW</span>
              </div>
            )}
          </div>
        )}
      </div>
    );
  }
  return null;
}

export function WastageDetectionPage({ setCurrentTab }) {
  const {
    wastageEvaluation,
    hourlyData,
    activeAnomaly,
    triggerAnomaly,
    activeWastageScenario,
    triggerWastageScenario,
    tariffINR,
    potentialWastageKWh,
    potentialSavingsINR,
    applyRecommendation,
    appliedRecommendations
  } = useEnergy();

  const [filterSeverity, setFilterSeverity] = useState("all");

  const severityBadges = {
    LOW: "bg-blue-950/80 text-blue-300 border-blue-800",
    MEDIUM: "bg-amber-950/80 text-amber-300 border-amber-800",
    HIGH: "bg-orange-950/80 text-orange-300 border-orange-800",
    CRITICAL: "bg-rose-950/80 text-rose-300 border-rose-800 animate-pulse"
  };

  const allDetectedCases = [
    ...wastageEvaluation.anomalies,
    ...wastageEvaluation.wastageCases
  ];

  const filteredCases = filterSeverity === "all"
    ? allDetectedCases
    : allDetectedCases.filter(c => c.severity === filterSeverity);

  return (
    <div className="space-y-6">
      {/* Page Header */}
      <div className="flex flex-col lg:flex-row items-start lg:items-center justify-between gap-4 p-5 rounded-2xl bg-gradient-to-r from-rose-950/60 via-slate-900 to-amber-950/40 border border-rose-500/30">
        <div>
          <div className="flex items-center gap-2">
            <span className="px-2.5 py-0.5 rounded-full bg-rose-950 border border-rose-700 text-rose-300 font-mono text-[10px] font-bold uppercase tracking-wider">
              AI INEFFICIENCY DETECTOR
            </span>
            <span className="text-xs text-rose-300 font-semibold">
              {allDetectedCases.length} Active Incidents Identified
            </span>
          </div>
          <h1 className="text-2xl font-black text-white mt-1">
            Wastage & Anomaly Detection Center
          </h1>
          <p className="text-xs text-slate-300 mt-0.5">
            Continuous cross-correlation of real-time electricity draw against occupant density, HVAC setpoints, and baseline operating hours.
          </p>
        </div>

        {/* Wastage Summary Stat Box */}
        <div className="flex items-center gap-3">
          <div className="p-3.5 rounded-xl bg-slate-900/90 border border-rose-500/40 text-right">
            <span className="text-[10px] text-slate-400 font-mono uppercase">Total Daily Wastage</span>
            <div className="text-2xl font-black text-rose-400 font-mono">
              {potentialWastageKWh} kWh
            </div>
            <span className="text-[10px] text-amber-300 font-mono">
              Cost Loss: ₹{potentialSavingsINR}/day
            </span>
          </div>
        </div>
      </div>

      {/* Interactive Trigger Bench for Demonstrators (Requirement 22) */}
      <div className="p-4 rounded-xl bg-[#0b1329] border border-slate-800 space-y-3">
        <div className="flex items-center justify-between">
          <span className="text-xs font-bold text-slate-300 uppercase tracking-wider font-mono flex items-center gap-1.5">
            <Sparkles className="w-4 h-4 text-cyan-400" />
            Interactive Inefficiency Simulators (Click to trigger AI detection)
          </span>
          <span className="text-[11px] text-slate-500">Live evaluation triggers</span>
        </div>

        <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-5 gap-2">
          {/* Case 1 Trigger: Corridor / Staircase */}
          <button
            onClick={() => triggerWastageScenario(ANOMALY_CASES.STAIRCASE_CORRIDOR_OFFHOURS)}
            className={`p-2.5 rounded-xl border text-left text-xs transition cursor-pointer ${
              activeWastageScenario === ANOMALY_CASES.STAIRCASE_CORRIDOR_OFFHOURS
                ? "bg-amber-500/20 border-amber-500/80 text-amber-200 shadow-md shadow-amber-500/20"
                : "bg-slate-900/80 border-slate-800 text-slate-400 hover:text-slate-200 hover:border-slate-700"
            }`}
          >
            <div className="font-bold text-amber-400 flex items-center gap-1">
              <Lightbulb className="w-3.5 h-3.5" />
              <span>Case 1: Stair / Corridor</span>
            </div>
            <div className="text-[10px] text-slate-400 mt-0.5">Off-Hours (Pre-9AM & Post-6PM)</div>
          </button>

          {/* Case 2 Trigger: Lunch Break */}
          <button
            onClick={() => triggerWastageScenario(ANOMALY_CASES.LUNCH_BREAK_CLASSROOM_AC)}
            className={`p-2.5 rounded-xl border text-left text-xs transition cursor-pointer ${
              activeWastageScenario === ANOMALY_CASES.LUNCH_BREAK_CLASSROOM_AC || activeWastageScenario === ANOMALY_CASES.AC_LOW_OCCUPANCY
                ? "bg-purple-500/20 border-purple-500/80 text-purple-200 shadow-md shadow-purple-500/20"
                : "bg-slate-900/80 border-slate-800 text-slate-400 hover:text-slate-200 hover:border-slate-700"
            }`}
          >
            <div className="font-bold text-purple-400 flex items-center gap-1">
              <Coffee className="w-3.5 h-3.5" />
              <span>Case 2: Lunch Break AC</span>
            </div>
            <div className="text-[10px] text-slate-400 mt-0.5">1-2 PM Vacant Overrun (22% Occ)</div>
          </button>

          {/* Case 3 Trigger: After-Hours */}
          <button
            onClick={() => triggerWastageScenario(ANOMALY_CASES.AFTER_HOURS_CONSUMPTION)}
            className={`p-2.5 rounded-xl border text-left text-xs transition cursor-pointer ${
              activeWastageScenario === ANOMALY_CASES.AFTER_HOURS_CONSUMPTION
                ? "bg-blue-500/20 border-blue-500/80 text-blue-200 shadow-md shadow-blue-500/20"
                : "bg-slate-900/80 border-slate-800 text-slate-400 hover:text-slate-200 hover:border-slate-700"
            }`}
          >
            <div className="font-bold text-blue-400 flex items-center gap-1">
              <Moon className="w-3.5 h-3.5" />
              <span>Case 3: After-Hours Lab</span>
            </div>
            <div className="text-[10px] text-slate-400 mt-0.5">Post-6 PM Workshop Load</div>
          </button>

          {/* Case 4 Trigger: Spike */}
          <button
            onClick={triggerAnomaly}
            className={`p-2.5 rounded-xl border text-left text-xs transition cursor-pointer ${
              activeAnomaly
                ? "bg-rose-500/20 border-rose-500/80 text-rose-200 shadow-md shadow-rose-500/20"
                : "bg-slate-900/80 border-slate-800 text-slate-400 hover:text-slate-200 hover:border-slate-700"
            }`}
          >
            <div className="font-bold text-rose-400 flex items-center gap-1">
              <Flame className="w-3.5 h-3.5" />
              <span>Case 4: +56% Surge</span>
            </div>
            <div className="text-[10px] text-slate-400 mt-0.5">128 kW Chiller Surge Spike</div>
          </button>

          {/* Case 5 Trigger: Weekend */}
          <button
            onClick={() => triggerWastageScenario(ANOMALY_CASES.WEEKEND_ANOMALY)}
            className={`p-2.5 rounded-xl border text-left text-xs transition cursor-pointer ${
              activeWastageScenario === ANOMALY_CASES.WEEKEND_ANOMALY
                ? "bg-teal-500/20 border-teal-500/80 text-teal-200 shadow-md shadow-teal-500/20"
                : "bg-slate-900/80 border-slate-800 text-slate-400 hover:text-slate-200 hover:border-slate-700"
            }`}
          >
            <div className="font-bold text-teal-400 flex items-center gap-1">
              <Activity className="w-3.5 h-3.5" />
              <span>Case 5: Weekend Idle</span>
            </div>
            <div className="text-[10px] text-slate-400 mt-0.5">Auditorium Sunday Draw</div>
          </button>
        </div>
      </div>

      {/* Redesigned Diurnal Curve: College Working Hours (9am-6pm), Lunch Break (1-2pm), and Staircase/Corridor Lights */}
      <div className="bg-[#0b1329] border border-slate-800 rounded-2xl p-5 shadow-xl space-y-4">
        <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-2 border-b border-slate-800 pb-3">
          <div>
            <h2 className="text-base font-bold text-white flex items-center gap-2">
              <Zap className="w-4 h-4 text-rose-400" />
              <span>24-Hour Power Usage & Wastage Pattern (College Schedule Calibrated)</span>
            </h2>
            <p className="text-xs text-slate-400">
              Correlated against college working hours (9 AM – 6 PM), lunch intermission (1 PM – 2 PM), and continuous staircase/corridor light waste.
            </p>
          </div>

          <div className="flex items-center gap-2">
            <span className="text-[11px] font-mono px-2 py-0.5 rounded bg-emerald-950 text-emerald-300 border border-emerald-800">
              Normal: 82.4 kW
            </span>
            <span className="text-slate-500">→</span>
            <span className={`text-[11px] font-mono px-2 py-0.5 rounded font-bold ${
              activeAnomaly ? "bg-rose-950 text-rose-300 border border-rose-800 animate-pulse" : "bg-slate-900 text-slate-400"
            }`}>
              Peak Spike: {activeAnomaly ? "128.4 kW (+56%)" : "Nominal"}
            </span>
          </div>
        </div>

        {/* Visual Schedule Context Ribbon */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-2.5 p-3 rounded-xl bg-slate-950/80 border border-slate-800 text-xs font-mono">
          <div className="flex items-center gap-2.5 p-2 rounded-lg bg-emerald-950/30 border border-emerald-800/50">
            <Clock className="w-4 h-4 text-emerald-400 flex-shrink-0" />
            <div>
              <span className="font-bold text-emerald-300 block">09:00 — 18:00 (Official Hours)</span>
              <span className="text-[10px] text-slate-400">Classrooms & labs in session. High occupancy (88-96%).</span>
            </div>
          </div>
          <div className="flex items-center gap-2.5 p-2 rounded-lg bg-purple-950/30 border border-purple-800/50">
            <Coffee className="w-4 h-4 text-purple-400 flex-shrink-0" />
            <div>
              <span className="font-bold text-purple-300 block">13:00 — 14:00 (Lunch Break)</span>
              <span className="text-[10px] text-slate-400">Occ plunges to 22%, but 34.5 kW AC/lights left running!</span>
            </div>
          </div>
          <div className="flex items-center gap-2.5 p-2 rounded-lg bg-amber-950/30 border border-amber-800/50">
            <Moon className="w-4 h-4 text-amber-400 flex-shrink-0" />
            <div>
              <span className="font-bold text-amber-300 block">Off-Hours (&lt; 1 kW Individually)</span>
              <span className="text-[10px] text-slate-400">Night Standby, Transition, Dispersal & Baseload all &lt; 1 kW. Corridor lights: 0.45 kW.</span>
            </div>
          </div>
        </div>

        {/* Redesigned ComposedChart with Multi-Category Wastage Bars */}
        <div className="h-80 w-full">
          <ResponsiveContainer width="100%" height="100%">
            <ComposedChart data={hourlyData} margin={{ top: 15, right: 10, left: -20, bottom: 0 }}>
              <CartesianGrid strokeDasharray="3 3" stroke="#1e293b" opacity={0.6} />
              <XAxis dataKey="hour" stroke="#64748b" tick={{ fontSize: 11 }} />
              <YAxis stroke="#64748b" tick={{ fontSize: 11 }} />
              <Tooltip content={<CustomWastageTooltip />} />
              <Legend wrapperStyle={{ fontSize: "11px", paddingTop: "8px" }} />

              <ReferenceArea
                x1="09:00"
                x2="18:00"
                stroke="#0284c7"
                strokeOpacity={0.3}
                strokeDasharray="3 3"
                fill="#0284c7"
                fillOpacity={0.03}
              />
              <ReferenceArea
                x1="13:00"
                x2="14:00"
                stroke="#a855f7"
                strokeOpacity={0.8}
                fill="#a855f7"
                fillOpacity={0.12}
              />

              {/* Total Telemetry Draw */}
              <Area
                type="monotone"
                dataKey="actual"
                name="Actual Telemetry Draw (kW)"
                stroke="#00f0ff"
                fill="#00f0ff"
                fillOpacity={0.12}
                strokeWidth={2.5}
              />

              {/* Expected Baseline */}
              <Line
                type="monotone"
                dataKey="baseline"
                name="Expected Baseline (kW)"
                stroke="#10b981"
                strokeDasharray="4 4"
                strokeWidth={2}
                dot={false}
              />

              {/* Category 1: Continuous Staircase & Corridor Lights Waste (Off-Hours) */}
              <Bar
                dataKey="corridorWasteKW"
                name="Staircase/Corridor Lights Waste (Off-Hours)"
                stackId="wastage"
                fill="#f59e0b"
              />

              {/* Category 2: Lunch Break Classroom AC & Lighting Overrun */}
              <Bar
                dataKey="lunchWasteKW"
                name="Lunch Break (1-2 PM) Vacant AC Waste"
                stackId="wastage"
                fill="#a855f7"
              />

              {/* Category 3: Idle Equipment & Other Wastage */}
              <Bar
                dataKey="equipmentIdleWasteKW"
                name="Standby / Equipment Inefficiencies"
                stackId="wastage"
                fill="#f43f5e"
                radius={[4, 4, 0, 0]}
              />
            </ComposedChart>
          </ResponsiveContainer>
        </div>
      </div>

      {/* Severity Filter & Detected Inefficiency Cases List */}
      <div className="space-y-4">
        <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3">
          <div>
            <h2 className="text-base font-bold text-white flex items-center gap-2">
              <ShieldAlert className="w-5 h-5 text-amber-400" />
              <span>Detected Cases & Root Cause Analysis</span>
            </h2>
            <p className="text-xs text-slate-400">
              AI classified incidents across campus with specific risk severity rankings
            </p>
          </div>

          {/* Severity Tabs (Requirement 24) */}
          <div className="flex items-center gap-1 bg-slate-900 p-1 rounded-xl border border-slate-800 text-xs">
            {["all", "CRITICAL", "HIGH", "MEDIUM", "LOW"].map((sev) => (
              <button
                key={sev}
                onClick={() => setFilterSeverity(sev)}
                className={`px-2.5 py-1 rounded-lg font-mono text-[11px] transition cursor-pointer ${
                  filterSeverity === sev
                    ? "bg-slate-800 text-white font-bold border border-slate-700"
                    : "text-slate-400 hover:text-white"
                }`}
              >
                {sev}
              </button>
            ))}
          </div>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {filteredCases.map((c, idx) => (
            <div
              key={c.id || idx}
              className={`p-5 rounded-2xl bg-[#0b1329] border transition-all space-y-3.5 ${
                c.severity === "CRITICAL"
                  ? "border-rose-500/60 shadow-lg shadow-rose-950/30"
                  : c.severity === "HIGH"
                  ? "border-amber-500/50"
                  : "border-slate-800"
              }`}
            >
              <div className="flex items-start justify-between gap-2">
                <div>
                  <div className="flex items-center gap-2">
                    <span className={`text-[10px] font-mono px-2 py-0.5 rounded-full border font-bold ${severityBadges[c.severity]}`}>
                      {c.severity} SEVERITY
                    </span>
                    <span className="text-xs font-mono text-cyan-400">
                      {c.building} — {c.floor}
                    </span>
                  </div>
                  <h3 className="text-base font-bold text-white mt-1">
                    {c.title}
                  </h3>
                </div>

                <div className="p-2 rounded-xl bg-slate-900 border border-slate-800 text-slate-300">
                  <AlertTriangle className="w-4 h-4 text-amber-400" />
                </div>
              </div>

              <div className="p-3 rounded-xl bg-slate-950/80 border border-slate-800/80 text-xs space-y-1.5">
                <div className="flex justify-between">
                  <span className="text-slate-400 font-medium">Risk:</span>
                  <span className="text-rose-300 font-semibold">{c.risk}</span>
                </div>
                {c.observedMetric && (
                  <div className="flex justify-between">
                    <span className="text-slate-400 font-medium">Observed:</span>
                    <span className="text-slate-200 font-mono">{c.observedMetric}</span>
                  </div>
                )}
                {c.normalBaselineKW && (
                  <div className="flex justify-between">
                    <span className="text-slate-400 font-medium">Baseline vs Anomaly:</span>
                    <span className="text-slate-200 font-mono">{c.normalBaselineKW} kW → {c.anomalyMeasuredKW} kW (+{c.percentageIncrease}%)</span>
                  </div>
                )}
                {c.excessKWhPerDay && (
                  <div className="flex justify-between pt-1 border-t border-slate-800">
                    <span className="text-slate-400 font-medium">Avoidable Daily Waste:</span>
                    <span className="text-emerald-400 font-mono font-bold">
                      {c.excessKWhPerDay} kWh (₹{c.costWastedPerDay}/day)
                    </span>
                  </div>
                )}
              </div>

              <p className="text-xs text-slate-300 leading-relaxed">
                {c.description}
              </p>

              <div className="pt-2 border-t border-slate-800/80 flex items-center justify-between gap-3">
                <div className="text-[11px] text-slate-400 truncate">
                  <strong className="text-cyan-300">AI Action:</strong> {c.recommendedAction}
                </div>
                <button
                  onClick={() => setCurrentTab("recommendations")}
                  className="px-3 py-1.5 rounded-xl bg-cyan-500/20 hover:bg-cyan-500/30 text-cyan-300 border border-cyan-500/40 text-xs font-bold whitespace-nowrap cursor-pointer transition"
                >
                  Optimize
                </button>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
