import React from "react";
import {
  Compass,
  Cpu,
  Sun,
  Droplets,
  Trash2,
  ShieldCheck,
  AlertCircle,
  Network,
  Radio,
  BatteryCharging,
  CheckCircle2
} from "lucide-react";

export function FutureExtensionsPage() {
  const extensions = [
    {
      id: "iot",
      icon: Radio,
      color: "from-blue-500 to-cyan-500",
      title: "ESP32 & Physical IoT Hardware Metering",
      badge: "FUTURE HARDWARE EXTENSION",
      badgeColor: "bg-blue-950 text-blue-300 border-blue-800",
      status: "Architecture Ready (Driver Blueprint Developed)",
      summary: "Direct physical sub-metering via ESP32 microcontrollers and industrial Modbus/RS485 energy meters.",
      features: [
        "SCT-013 non-invasive split-core Current Transformer (CT) clamp integration",
        "ZMPT101B precision voltage transformers for real-time RMS phase calculation",
        "MQTT Broker & WebSocket lightweight JSON payload telemetry publisher",
        "PIR / Doppler microwave occupancy sensors installed in lecture halls",
        "Over-the-air (OTA) firmware updating and watchdog failsafes"
      ],
      notice: "Note: In the current MVP, telemetry is simulated via the Realistic Simulated Data Engine. Physical hardware is not currently deployed."
    },
    {
      id: "solar",
      icon: Sun,
      color: "from-amber-500 to-yellow-500",
      title: "Rooftop Solar PV & Battery Storage Optimization",
      badge: "FUTURE RESOURCE EXTENSION",
      badgeColor: "bg-amber-950 text-amber-300 border-amber-800",
      status: "Roadmap Phase 2",
      summary: "Bi-directional metering optimizing campus solar generation against peak commercial tariff periods.",
      features: [
        "Rooftop solar PV inverter telemetry tracking instantaneous solar irradiance",
        "Campus Net Metering: Grid import vs Solar self-consumption vs Export credit",
        "BESS (Battery Energy Storage System) peak shaving charge/discharge scheduling",
        "AI Solar Generation Forecast based on satellite cloud cover APIs"
      ],
      notice: "Note: Architecture is expandable to Solar, but electricity grid optimization is the core MVP."
    },
    {
      id: "water",
      icon: Droplets,
      color: "from-cyan-500 to-teal-500",
      title: "Campus Water Intelligence & Acoustic Leak Detection",
      badge: "FUTURE RESOURCE EXTENSION",
      badgeColor: "bg-cyan-950 text-cyan-300 border-cyan-800",
      status: "Roadmap Phase 3",
      summary: "Continuous sub-metering of overhead water tanks, RO plants, and pipeline pressure sensors.",
      features: [
        "Ultrasonic pulse water meters measuring liter/minute flow rate across hostel blocks",
        "Acoustic & pressure gradient pipe leak isolation algorithms",
        "Rainwater harvesting reservoir capacity & percolation monitoring",
        "Sewage treatment plant (STP) recycled water recycling balance"
      ],
      notice: "Note: Reserved for Phase 3. The current MVP focuses exclusively on electricity/energy."
    },
    {
      id: "waste",
      icon: Trash2,
      color: "from-emerald-500 to-green-600",
      title: "Smart Waste Logistics & Composting Analytics",
      badge: "FUTURE RESOURCE EXTENSION",
      badgeColor: "bg-emerald-950 text-emerald-300 border-emerald-800",
      status: "Roadmap Phase 4",
      summary: "IoT fill-level bin sensors and cafeteria organic waste digester telemetry.",
      features: [
        "Time-of-flight ultrasonic sensors in campus recycling & trash receptacles",
        "Dynamic custodial route optimization for collection trucks",
        "Cafeteria wet food waste biogas digestion mass tracking",
        "Zero-Waste-to-Landfill campus certification auditing"
      ],
      notice: "Note: Reserved for Phase 4. The current MVP focuses exclusively on electricity/energy."
    }
  ];

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 p-5 rounded-2xl bg-gradient-to-r from-blue-950/50 via-slate-900 to-indigo-950/50 border border-blue-500/30">
        <div>
          <div className="flex items-center gap-2">
            <span className="px-2.5 py-0.5 rounded-full bg-blue-950 border border-blue-700 text-blue-300 font-mono text-[10px] font-bold uppercase tracking-wider">
              ROADMAP & EXTENSIBILITY
            </span>
            <span className="text-xs text-amber-300 font-bold">
              FUTURE EXTENSIONS (CLEARLY LABELED)
            </span>
          </div>
          <h1 className="text-2xl font-black text-white mt-1">
            System Expansion Roadmap & Future IoT Integrations
          </h1>
          <p className="text-xs text-slate-300 mt-0.5">
            The platform architecture was designed from day one to ingest physical IoT microcontrollers and multi-resource sustainability streams.
          </p>
        </div>
      </div>

      {/* Mandatory Data Integrity Disclaimer Card (Requirement 8 & 49) */}
      <div className="p-4 rounded-xl bg-slate-900/90 border border-amber-500/60 flex items-start gap-3">
        <AlertCircle className="w-5 h-5 text-amber-400 flex-shrink-0 mt-0.5" />
        <div className="text-xs text-slate-300 leading-relaxed">
          <strong className="text-amber-300 uppercase font-mono">Data Integrity & Competition Rules Notice: </strong>
          The features detailed on this page are <strong className="text-white">FUTURE ARCHITECTURAL EXTENSIONS</strong>. The current working MVP focuses exclusively on <strong className="text-cyan-400">ELECTRICITY / ENERGY OPTIMIZATION</strong> powered by our verified Simulated Data Engine. We do not falsely claim active physical IoT sensor deployment or multi-resource operations at this stage.
        </div>
      </div>

      {/* Grid of Future Extensions */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {extensions.map((ext) => {
          const Icon = ext.icon;
          return (
            <div
              key={ext.id}
              className="p-6 rounded-2xl bg-[#0b1329] border border-slate-800 space-y-4 flex flex-col justify-between shadow-xl"
            >
              <div className="space-y-3">
                <div className="flex items-start justify-between">
                  <div className={`p-3 rounded-xl bg-gradient-to-br ${ext.color} text-black font-bold`}>
                    <Icon className="w-6 h-6 text-white" />
                  </div>
                  <span className={`text-[10px] font-mono px-2.5 py-0.5 rounded-full border font-bold ${ext.badgeColor}`}>
                    {ext.badge}
                  </span>
                </div>

                <div>
                  <h2 className="text-lg font-bold text-white">{ext.title}</h2>
                  <span className="text-[11px] font-mono text-cyan-400 font-medium">
                    Status: {ext.status}
                  </span>
                  <p className="text-xs text-slate-300 mt-1.5 leading-relaxed">
                    {ext.summary}
                  </p>
                </div>

                <div className="pt-2">
                  <span className="text-[11px] font-mono font-bold text-slate-400 uppercase">
                    Planned Architectural Capabilities:
                  </span>
                  <ul className="mt-2 space-y-1.5 text-xs text-slate-400">
                    {ext.features.map((f, fIdx) => (
                      <li key={fIdx} className="flex items-start gap-2">
                        <CheckCircle2 className="w-3.5 h-3.5 text-slate-600 flex-shrink-0 mt-0.5" />
                        <span>{f}</span>
                      </li>
                    ))}
                  </ul>
                </div>
              </div>

              <div className="p-3 rounded-xl bg-slate-950 border border-slate-800/80 text-[11px] text-slate-400 italic font-mono mt-4">
                {ext.notice}
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
}
