import React, { useState } from "react";
import {
  LineChart,
  BarChart,
  AreaChart,
  Line,
  Bar,
  Area,
  XAxis,
  YAxis,
  Tooltip,
  Legend,
  ResponsiveContainer,
  CartesianGrid,
  ReferenceArea
} from "recharts";
import {
  Calendar,
  Filter,
  Building2,
  Layers,
  ArrowUpDown,
  Download,
  Flame,
  Activity,
  Zap,
  TrendingUp
} from "lucide-react";
import { useEnergy } from "../context/EnergyContext";
import { exportSimulationDataset } from "../services/exportUtils";

export function EnergyAnalyticsPage() {
  const {
    hourlyData,
    weeklyData,
    monthlyData,
    campusConfig,
    selectedBuilding,
    setSelectedBuilding,
    selectedFloor,
    setSelectedFloor
  } = useEnergy();

  const [viewType, setViewType] = useState("building-compare"); // "building-compare" | "floor-compare" | "baseline-actual" | "seasonal"
  const [selectedSeason, setSelectedSeason] = useState("Autumn");

  // Building comparison dataset across all 4 Campus Blocks (Off-hours < 1 kW individually)
  const buildingComparisonData = [
    { name: "00:00", "Block A": 0.16, "Block B": 0.15, "Block C": 0.16, "Block D": 0.15 }, // Night Deep Standby (< 1 kW)
    { name: "04:00", "Block A": 0.15, "Block B": 0.15, "Block C": 0.14, "Block D": 0.15 }, // Night Deep Standby (< 1 kW)
    { name: "07:30", "Block A": 0.22, "Block B": 0.20, "Block C": 0.18, "Block D": 0.20 }, // Pre-College Transition (< 1 kW)
    { name: "10:00", "Block A": 24.0, "Block B": 22.2, "Block C": 21.4, "Block D": 23.1 },
    { name: "12:00", "Block A": 25.5, "Block B": 23.8, "Block C": 22.5, "Block D": 24.2 },
    { name: "13:30", "Block A": 16.5, "Block B": 15.0, "Block C": 14.5, "Block D": 15.5 }, // Lunch break dip (13:00 - 14:00)
    { name: "15:00", "Block A": 26.0, "Block B": 24.5, "Block C": 23.0, "Block D": 25.0 },
    { name: "17:00", "Block A": 23.2, "Block B": 21.5, "Block C": 20.0, "Block D": 22.4 },
    { name: "19:00", "Block A": 0.22, "Block B": 0.21, "Block C": 0.20, "Block D": 0.21 }, // Post-College Dispersal (< 1 kW)
    { name: "22:00", "Block A": 0.17, "Block B": 0.16, "Block C": 0.16, "Block D": 0.17 }  // Night Baseload (< 1 kW)
  ];

  // Floor comparison data within selected building
  const floorComparisonData = [
    { name: "Floor 1", Actual: 11.2, Baseline: 9.8, Wastage: 1.4 },
    { name: "Floor 2", Actual: 14.8, Baseline: 8.5, Wastage: 6.3 },
    { name: "Floor 3", Actual: 10.4, Baseline: 9.0, Wastage: 1.4 }
  ];

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4 p-5 rounded-2xl bg-gradient-to-r from-blue-950/50 via-slate-900 to-cyan-950/50 border border-blue-500/30">
        <div>
          <div className="flex items-center gap-2">
            <span className="px-2.5 py-0.5 rounded-full bg-blue-950 border border-blue-700 text-blue-300 font-mono text-[10px] font-bold uppercase tracking-wider">
              LONGITUDINAL TELEMETRY
            </span>
            <span className="text-xs text-blue-300">
              Trident Campus Historical Archives
            </span>
          </div>
          <h1 className="text-2xl font-black text-white mt-1">
            Historical Energy Analytics & Comparative Benchmarks
          </h1>
          <p className="text-xs text-slate-300 mt-0.5">
            Cross-sectional analysis comparing building blocks, floor distributions, and seasonal baselines.
          </p>
        </div>

        <button
          onClick={exportSimulationDataset}
          className="px-3.5 py-2 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-semibold flex items-center gap-1.5 cursor-pointer"
        >
          <Download className="w-4 h-4 text-cyan-400" />
          <span>Export Analytics CSV</span>
        </button>
      </div>

      {/* Analytics View Switcher & Filters (Requirement 19) */}
      <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-3 p-3 rounded-xl bg-[#0b1329] border border-slate-800">
        <div className="flex items-center gap-1.5 flex-wrap">
          {[
            { id: "building-compare", label: "Building Comparison" },
            { id: "floor-compare", label: "Floor Comparison" },
            { id: "baseline-actual", label: "Baseline vs Actual" },
            { id: "seasonal", label: "Seasonal Trend (12 Mo)" }
          ].map((tab) => (
            <button
              key={tab.id}
              onClick={() => setViewType(tab.id)}
              className={`px-3 py-1.5 rounded-lg text-xs font-medium transition cursor-pointer ${
                viewType === tab.id
                  ? "bg-cyan-500/20 text-cyan-300 border border-cyan-500/50 font-bold"
                  : "bg-slate-900 text-slate-400 hover:text-white"
              }`}
            >
              {tab.label}
            </button>
          ))}
        </div>

        {/* Season Selector Filter */}
        <div className="flex items-center gap-2">
          <span className="text-xs text-slate-400 font-mono flex items-center gap-1">
            <Filter className="w-3.5 h-3.5" /> Season:
          </span>
          <select
            value={selectedSeason}
            onChange={(e) => setSelectedSeason(e.target.value)}
            className="bg-slate-950 text-slate-200 border border-slate-700 rounded-lg px-2.5 py-1 text-xs font-medium focus:outline-none focus:border-cyan-400"
          >
            <option value="Autumn">Autumn (Moderate 28–34°C)</option>
            <option value="Summer">Summer (Extreme 36–44°C)</option>
            <option value="Winter">Winter (Cool 18–26°C)</option>
            <option value="Monsoon">Monsoon (Humid 30–35°C)</option>
          </select>
        </div>
      </div>

      {/* Primary Analytics Chart Card */}
      <div className="bg-[#0b1329] border border-slate-800 rounded-2xl p-6 shadow-xl space-y-4">
        <div className="flex items-center justify-between border-b border-slate-800 pb-3">
          <div>
            <h2 className="text-base font-bold text-white">
              {viewType === "building-compare"
                ? "Simultaneous Building Load Profile (Block A vs B vs C vs D)"
                : viewType === "floor-compare"
                ? "Floor Load Breakdown & Waste Distribution"
                : viewType === "baseline-actual"
                ? "Actual Telemetry vs Clean Baseline (College Hours 09:00 - 18:00)"
                : "12-Month Annual Seasonal Energy Pattern"}
            </h2>
            <p className="text-xs text-slate-400">
              High-resolution submetering comparison across academic blocks
            </p>
          </div>
        </div>

        <div className="h-80 w-full">
          <ResponsiveContainer width="100%" height="100%">
            {viewType === "building-compare" ? (
              <AreaChart data={buildingComparisonData} margin={{ top: 10, right: 10, left: -20, bottom: 0 }}>
                <CartesianGrid strokeDasharray="3 3" stroke="#1e293b" opacity={0.6} />
                <XAxis dataKey="name" stroke="#64748b" tick={{ fontSize: 11 }} />
                <YAxis stroke="#64748b" tick={{ fontSize: 11 }} />
                <Tooltip
                  contentStyle={{
                    backgroundColor: "#070b14",
                    borderColor: "#334155",
                    borderRadius: "0.75rem",
                    fontSize: "12px",
                    color: "#f8fafc"
                  }}
                  formatter={(val, name) => [`${val} kW`, name]}
                />
                <Legend wrapperStyle={{ fontSize: "11px", paddingTop: "8px" }} />
                <Area type="monotone" dataKey="Block A" stroke="#00f0ff" fill="#00f0ff" fillOpacity={0.2} strokeWidth={2} />
                <Area type="monotone" dataKey="Block B" stroke="#8b5cf6" fill="#8b5cf6" fillOpacity={0.2} strokeWidth={2} />
                <Area type="monotone" dataKey="Block C" stroke="#10b981" fill="#10b981" fillOpacity={0.2} strokeWidth={2} />
                <Area type="monotone" dataKey="Block D" stroke="#f59e0b" fill="#f59e0b" fillOpacity={0.2} strokeWidth={2} />
              </AreaChart>
            ) : viewType === "floor-compare" ? (
              <BarChart data={floorComparisonData} margin={{ top: 10, right: 10, left: -20, bottom: 0 }}>
                <CartesianGrid strokeDasharray="3 3" stroke="#1e293b" opacity={0.6} />
                <XAxis dataKey="name" stroke="#64748b" tick={{ fontSize: 11 }} />
                <YAxis stroke="#64748b" tick={{ fontSize: 11 }} />
                <Tooltip
                  contentStyle={{
                    backgroundColor: "#070b14",
                    borderColor: "#334155",
                    borderRadius: "0.75rem",
                    fontSize: "12px",
                    color: "#f8fafc"
                  }}
                  formatter={(val, name) => [`${val} kW`, name]}
                />
                <Legend wrapperStyle={{ fontSize: "11px", paddingTop: "8px" }} />
                <Bar dataKey="Actual" fill="#00f0ff" radius={[4, 4, 0, 0]} />
                <Bar dataKey="Baseline" fill="#64748b" radius={[4, 4, 0, 0]} />
                <Bar dataKey="Wastage" fill="#f43f5e" radius={[4, 4, 0, 0]} />
              </BarChart>
            ) : viewType === "baseline-actual" ? (
              <LineChart data={hourlyData} margin={{ top: 10, right: 10, left: -20, bottom: 0 }}>
                <CartesianGrid strokeDasharray="3 3" stroke="#1e293b" opacity={0.6} />
                <XAxis dataKey="hour" stroke="#64748b" tick={{ fontSize: 11 }} />
                <YAxis stroke="#64748b" tick={{ fontSize: 11 }} />
                <Tooltip
                  contentStyle={{
                    backgroundColor: "#070b14",
                    borderColor: "#334155",
                    borderRadius: "0.75rem",
                    fontSize: "12px",
                    color: "#f8fafc"
                  }}
                  formatter={(val, name) => [`${val} kW`, name]}
                />
                <Legend wrapperStyle={{ fontSize: "11px", paddingTop: "8px" }} />
                <ReferenceArea x1="09:00" x2="18:00" stroke="#00f0ff" strokeOpacity={0.2} fill="#00f0ff" fillOpacity={0.05} />
                <ReferenceArea x1="13:00" x2="14:00" stroke="#a855f7" strokeOpacity={0.3} fill="#a855f7" fillOpacity={0.08} />
                <Line type="monotone" dataKey="actual" name="Actual Draw (kW)" stroke="#00f0ff" strokeWidth={2.5} dot={false} />
                <Line type="monotone" dataKey="baseline" name="Expected Baseline (kW)" stroke="#10b981" strokeWidth={2} strokeDasharray="3 3" dot={false} />
              </LineChart>
            ) : (
              <BarChart data={monthlyData} margin={{ top: 10, right: 10, left: -10, bottom: 0 }}>
                <CartesianGrid strokeDasharray="3 3" stroke="#1e293b" opacity={0.6} />
                <XAxis dataKey="month" stroke="#64748b" tick={{ fontSize: 11 }} />
                <YAxis stroke="#64748b" tick={{ fontSize: 11 }} />
                <Tooltip
                  contentStyle={{
                    backgroundColor: "#070b14",
                    borderColor: "#334155",
                    borderRadius: "0.75rem",
                    fontSize: "12px",
                    color: "#f8fafc"
                  }}
                  formatter={(val, name) => [`${val} kWh`, name]}
                />
                <Legend wrapperStyle={{ fontSize: "11px", paddingTop: "8px" }} />
                <Bar dataKey="consumed" name="Total Electricity (kWh)" fill="#3b82f6" radius={[4, 4, 0, 0]} />
                <Bar dataKey="baseline" name="Target Efficient Baseline (kWh)" fill="#10b981" radius={[4, 4, 0, 0]} />
              </BarChart>
            )}
          </ResponsiveContainer>
        </div>
      </div>
    </div>
  );
}
