import React from "react";
import { Zap, Play, Building2, Bell, User, Cpu, Sparkles, RefreshCw, LogOut, ExternalLink, Box, Database, Sliders, Download } from "lucide-react";
import { useEnergy } from "../context/EnergyContext";
import { downloadCodebaseZip } from "../services/zipDownloader";

export function Navbar({ onLogout, currentTab, setCurrentTab }) {
  const {
    campusConfig,
    selectedBuilding,
    setSelectedBuilding,
    selectedFloor,
    setSelectedFloor,
    isSimulating,
    startSimulation,
    pauseSimulation,
    startAiDemo,
    alerts,
    lastUpdated
  } = useEnergy();

  const selectedBuildingObj = campusConfig.buildings.find(b => b.id === selectedBuilding) || campusConfig.buildings[0];
  const criticalAlertCount = alerts.filter(a => a.severity === "CRITICAL" || a.severity === "HIGH").length;

  const openDedicatedTab = (path) => {
    window.open(`${window.location.origin}${path}`, "_blank");
  };

  const handleDownloadZip = () => {
    // Trigger download of complete codebase
    const link = document.createElement("a");
    link.href = "/ENERGYINTEL_AI_Complete_Source_Code.zip";
    link.download = "ENERGYINTEL_AI_Complete_Source_Code.zip";
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  return (
    <header className="sticky top-0 z-40 bg-[#070b14]/90 backdrop-blur-md border-b border-slate-800/80 px-4 py-2.5">
      <div className="flex flex-col md:flex-row items-center justify-between gap-3">
        {/* Brand & AI Engine Indicator */}
        <div className="flex items-center gap-3 w-full md:w-auto justify-between md:justify-start">
          <div 
            onClick={() => setCurrentTab("overview")} 
            className="flex items-center gap-2.5 cursor-pointer group"
          >
            <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-cyan-500 to-blue-600 flex items-center justify-center shadow-lg shadow-cyan-500/20 group-hover:shadow-cyan-500/40 transition-all">
              <Zap className="w-6 h-6 text-black fill-current" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <span className="font-bold text-lg tracking-wider text-white">
                  ENERGY<span className="text-cyan-400">INTEL</span> AI
                </span>
                <span className="text-[10px] uppercase font-mono px-1.5 py-0.5 rounded bg-cyan-950/80 border border-cyan-800 text-cyan-300">
                  v2.4 Pro
                </span>
              </div>
              <p className="text-[11px] text-slate-400 font-medium">Campus Energy Intelligence Platform</p>
            </div>
          </div>

          {/* Quick Tab Launcher Pills */}
          <div className="hidden xl:flex items-center gap-1.5 pl-3 border-l border-slate-800">
            <button
              onClick={() => setCurrentTab("floorsim")}
              className="flex items-center gap-1 px-2.5 py-1 rounded-lg bg-cyan-950/80 border border-cyan-700 text-[11px] font-mono text-cyan-300 hover:bg-cyan-900 hover:text-white transition cursor-pointer"
              title="Open Floor-Wise 3D Simulation & % Sliders"
            >
              <Sliders className="w-3 h-3 text-cyan-400" />
              <span>Floor Controls</span>
            </button>

            <button
              onClick={() => openDedicatedTab("/?view=digitaltwin")}
              className="flex items-center gap-1 px-2.5 py-1 rounded-lg bg-slate-900 border border-slate-800 text-[11px] font-mono text-cyan-300 hover:border-cyan-500 hover:text-white transition cursor-pointer"
              title="Launch 3D Digital Twin in a separate browser tab"
            >
              <Box className="w-3 h-3 text-cyan-400" />
              <span>Digital Twin ↗</span>
            </button>

            <button
              onClick={() => openDedicatedTab("/?view=bigdata")}
              className="flex items-center gap-1 px-2.5 py-1 rounded-lg bg-slate-900 border border-slate-800 text-[11px] font-mono text-blue-300 hover:border-blue-500 hover:text-white transition cursor-pointer"
              title="Launch Big Data Explorer in a separate browser tab"
            >
              <Database className="w-3 h-3 text-blue-400" />
              <span>Big Data ↗</span>
            </button>
          </div>
        </div>

        {/* Campus & Hierarchy Selector Bar (Requirement 12) */}
        <div className="flex flex-wrap items-center gap-2 bg-slate-900/90 p-1 rounded-xl border border-slate-800 text-xs">
          {/* Building Select (4 Buildings) */}
          <div className="flex items-center gap-1">
            <Building2 className="w-3.5 h-3.5 text-cyan-400" />
            <select
              value={selectedBuilding}
              onChange={(e) => setSelectedBuilding(e.target.value)}
              className="bg-slate-950 text-slate-200 border border-slate-700/80 rounded-lg px-2.5 py-1 text-xs focus:outline-none focus:border-cyan-400 font-medium"
            >
              {campusConfig.buildings.map((b) => (
                <option key={b.id} value={b.id}>
                  🏢 {b.name}
                </option>
              ))}
            </select>
          </div>

          <div className="h-4 w-px bg-slate-700"></div>

          {/* Floor Select (3 Floors) */}
          <div className="flex items-center gap-1">
            <select
              value={selectedFloor}
              onChange={(e) => setSelectedFloor(e.target.value)}
              className="bg-slate-950 text-purple-300 border border-slate-700/80 rounded-lg px-2.5 py-1 text-xs focus:outline-none focus:border-cyan-400 font-medium"
            >
              {selectedBuildingObj?.floors.map((f) => (
                <option key={f.id} value={f.id}>
                  📑 Floor {f.number}
                </option>
              ))}
            </select>
          </div>
        </div>

        {/* Master AI Demo Trigger & Profile Actions */}
        <div className="flex items-center gap-2 w-full md:w-auto justify-end">
          {/* DOWNLOAD CODE ZIP (Requested by user!) */}
          <button
            onClick={handleDownloadZip}
            className="px-3 py-1.5 rounded-xl bg-emerald-500/20 hover:bg-emerald-500/30 text-emerald-300 border border-emerald-500/50 text-xs font-bold font-mono flex items-center gap-1.5 cursor-pointer shadow-md shadow-emerald-500/20 transition"
            title="Download complete website source code in a single ZIP folder"
          >
            <Download className="w-3.5 h-3.5 text-emerald-400" />
            <span>Download ZIP</span>
          </button>

          {/* RUN AI DEMO */}
          <button
            onClick={startAiDemo}
            className="relative group overflow-hidden px-4 py-2 rounded-xl bg-gradient-to-r from-cyan-500 via-blue-600 to-indigo-600 text-white font-bold text-xs uppercase tracking-wider shadow-lg shadow-cyan-500/30 hover:shadow-cyan-400/50 hover:scale-[1.02] active:scale-[0.98] transition-all flex items-center gap-2 cursor-pointer border border-cyan-300/40"
          >
            <span className="absolute inset-0 w-full h-full bg-white/20 transform -skew-x-12 -translate-x-full group-hover:translate-x-full transition-transform duration-700"></span>
            <Sparkles className="w-4 h-4 text-cyan-200 animate-spin-slow" />
            <span>RUN AI DEMO</span>
          </button>

          {/* Alerts Center Notification Quick Link */}
          <button
            onClick={() => setCurrentTab("alerts")}
            className="relative p-2 rounded-xl bg-slate-900 border border-slate-800 text-slate-300 hover:text-white hover:border-slate-700 transition cursor-pointer"
            title="Alerts Center"
          >
            <Bell className="w-4 h-4" />
            {criticalAlertCount > 0 && (
              <span className="absolute -top-1 -right-1 w-4 h-4 rounded-full bg-rose-500 text-white text-[10px] font-bold flex items-center justify-center animate-pulse">
                {criticalAlertCount}
              </span>
            )}
          </button>

          {/* User & Logout */}
          <div className="flex items-center gap-2 pl-2 border-l border-slate-800">
            <button
              onClick={onLogout}
              title="Logout"
              className="p-2 rounded-xl bg-slate-900 border border-slate-800 text-slate-400 hover:text-rose-400 hover:border-rose-900/60 transition cursor-pointer"
            >
              <LogOut className="w-4 h-4" />
            </button>
          </div>
        </div>
      </div>
    </header>
  );
}
