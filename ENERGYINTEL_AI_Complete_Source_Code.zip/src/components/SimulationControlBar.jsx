import {
  Play,
  Pause,
  RotateCcw,
  Users,
  Thermometer,
  Flame,
  AlertOctagon,
  Trash2,
  Activity,
  SlidersHorizontal,
  Timer,
  Download,
  FileSpreadsheet,
  CheckCircle2
} from "lucide-react";
import { useEnergy } from "../context/EnergyContext";
import { ANOMALY_CASES } from "../services/aiAnomalyService";

export function SimulationControlBar() {
  const {
    isSimulating,
    startSimulation,
    pauseSimulation,
    resetSimulation,
    occupancyMultiplier,
    triggerIncreaseOccupancy,
    tempOffset,
    triggerIncreaseTemperature,
    isPeakLoadActive,
    triggerPeakLoad,
    activeAnomaly,
    triggerAnomaly,
    activeWastageScenario,
    triggerWastageScenario,
    environmentalParams,
    electricalParams,
    elapsedSimulationSeconds,
    hasAutoDownloaded1Hr,
    oneHourCompletedNotification,
    setOneHourCompletedNotification,
    triggerFastForward1Hour,
    download1HourDataset
  } = useEnergy();

  const minutesElapsed = Math.floor(elapsedSimulationSeconds / 60);
  const secondsRemainder = elapsedSimulationSeconds % 60;
  const timeFormatted = `${String(minutesElapsed).padStart(2, "0")}:${String(secondsRemainder).padStart(2, "0")}`;
  const pct1Hr = Math.min(100, Math.round((elapsedSimulationSeconds / 3600) * 100));

  return (
    <div className="bg-[#0b1224] border-b border-slate-800/80 px-4 py-2 text-xs">
      <div className="flex flex-wrap items-center justify-between gap-3">
        {/* Simulation Execution Controls */}
        <div className="flex items-center gap-1.5 flex-wrap">
          <div className="flex items-center gap-1 bg-slate-900/90 p-1 rounded-xl border border-slate-800">
            {isSimulating ? (
              <button
                onClick={pauseSimulation}
                className="flex items-center gap-1 px-2.5 py-1 rounded-lg bg-amber-500/20 text-amber-300 hover:bg-amber-500/30 font-medium transition cursor-pointer"
                title="Pause simulation telemetry"
              >
                <Pause className="w-3.5 h-3.5" />
                <span>PAUSE</span>
              </button>
            ) : (
              <button
                onClick={startSimulation}
                className="flex items-center gap-1 px-2.5 py-1 rounded-lg bg-emerald-500/20 text-emerald-300 hover:bg-emerald-500/30 font-medium transition cursor-pointer"
                title="Start simulation telemetry"
              >
                <Play className="w-3.5 h-3.5" />
                <span>START SIMULATION</span>
              </button>
            )}

            <button
              onClick={resetSimulation}
              className="flex items-center gap-1 px-2.5 py-1 rounded-lg bg-slate-800 text-slate-300 hover:bg-slate-700 hover:text-white font-medium transition cursor-pointer"
              title="Reset parameters to campus baseline"
            >
              <RotateCcw className="w-3.5 h-3.5" />
              <span>RESET</span>
            </button>
          </div>

          <div className="h-4 w-px bg-slate-800 hidden sm:block"></div>

          {/* Interactive Scenario Buttons */}
          <div className="flex items-center gap-1.5 flex-wrap">
            {/* Increase Occupancy */}
            <button
              onClick={triggerIncreaseOccupancy}
              className={`flex items-center gap-1 px-2.5 py-1 rounded-lg border font-medium transition cursor-pointer ${
                occupancyMultiplier > 1
                  ? "bg-cyan-500/20 border-cyan-500/50 text-cyan-300"
                  : "bg-slate-900 border-slate-800 text-slate-300 hover:border-slate-700"
              }`}
              title="Simulate increased campus activity & classroom population"
            >
              <Users className="w-3.5 h-3.5 text-cyan-400" />
              <span>
                OCCUPANCY {occupancyMultiplier > 1 ? `(${Math.round(occupancyMultiplier * 100)}%)` : "+25%"}
              </span>
            </button>

            {/* Increase Temperature */}
            <button
              onClick={triggerIncreaseTemperature}
              className={`flex items-center gap-1 px-2.5 py-1 rounded-lg border font-medium transition cursor-pointer ${
                tempOffset > 0
                  ? "bg-orange-500/20 border-orange-500/50 text-orange-300"
                  : "bg-slate-900 border-slate-800 text-slate-300 hover:border-slate-700"
              }`}
              title="Simulate hotter ambient conditions and higher AC refrigeration load"
            >
              <Thermometer className="w-3.5 h-3.5 text-orange-400" />
              <span>
                TEMP {tempOffset > 0 ? `(+${tempOffset}°C)` : "+2°C"}
              </span>
            </button>

            {/* Peak Load */}
            <button
              onClick={triggerPeakLoad}
              className={`flex items-center gap-1 px-2.5 py-1 rounded-lg border font-medium transition cursor-pointer ${
                isPeakLoadActive
                  ? "bg-amber-500/20 border-amber-500/60 text-amber-300 shadow-sm shadow-amber-500/20 animate-pulse"
                  : "bg-slate-900 border-slate-800 text-slate-300 hover:border-slate-700"
              }`}
              title="Create realistic energy peak (118 kW) during afternoon academic rush"
            >
              <Flame className="w-3.5 h-3.5 text-amber-400" />
              <span>PEAK LOAD (118 kW)</span>
            </button>

            {/* Generate Anomaly (Spike to 128 kW) */}
            <button
              onClick={triggerAnomaly}
              className={`flex items-center gap-1 px-2.5 py-1 rounded-lg border font-medium transition cursor-pointer ${
                activeAnomaly
                  ? "bg-rose-500/30 border-rose-500/80 text-rose-200 shadow-md shadow-rose-500/30 animate-pulse"
                  : "bg-slate-900 border-slate-800 text-slate-300 hover:border-rose-900/50 hover:text-rose-300"
              }`}
              title="Generate abnormal energy surge (+56% increase to 128 kW in Block B)"
            >
              <AlertOctagon className="w-3.5 h-3.5 text-rose-400" />
              <span>GENERATE ANOMALY (128 kW)</span>
            </button>

            {/* Generate Wastage Scenarios */}
            <button
              onClick={() => triggerWastageScenario(ANOMALY_CASES.AC_LOW_OCCUPANCY)}
              className={`flex items-center gap-1 px-2.5 py-1 rounded-lg border font-medium transition cursor-pointer ${
                activeWastageScenario === ANOMALY_CASES.AC_LOW_OCCUPANCY
                  ? "bg-purple-500/20 border-purple-500/60 text-purple-200"
                  : "bg-slate-900 border-slate-800 text-slate-300 hover:border-slate-700"
              }`}
              title="Simulate AC ON + Low Occupancy in Block B Floor 2"
            >
              <Trash2 className="w-3.5 h-3.5 text-purple-400" />
              <span>GENERATE WASTAGE (AC/Lights)</span>
            </button>
          </div>
        </div>

        {/* 1-Hour Simulation Buffer & Telemetry Tele-Stream (Requirement 1s refresh & 1-hr auto download) */}
        <div className="flex items-center gap-2.5 flex-wrap">
          {/* 1-Hour Buffer Monitor */}
          <div className="flex items-center gap-2 px-3 py-1 rounded-xl bg-slate-900 border border-slate-800 text-[11px] font-mono">
            <div className="flex items-center gap-1.5">
              <span className="w-2 h-2 rounded-full bg-cyan-400 animate-pulse"></span>
              <span className="text-slate-400">1s Tick:</span>
              <span className="text-cyan-300 font-bold">{timeFormatted}</span>
              <span className="text-slate-500">/ 60:00</span>
            </div>

            <div className="w-16 h-2 bg-slate-800 rounded-full overflow-hidden hidden sm:block">
              <div
                className="h-full bg-gradient-to-r from-cyan-500 to-emerald-400 transition-all duration-300"
                style={{ width: `${pct1Hr}%` }}
              ></div>
            </div>
            <span className="text-emerald-400 font-semibold">{pct1Hr}%</span>

            {hasAutoDownloaded1Hr && (
              <span className="px-1.5 py-0.5 rounded bg-emerald-950 border border-emerald-700 text-emerald-300 text-[10px] font-bold">
                1-HR READY
              </span>
            )}
          </div>

          {/* Quick Action: Instant 1-Hour Export & Fast-Forward */}
          <div className="flex items-center gap-1">
            <button
              onClick={() => triggerFastForward1Hour("excel")}
              className="px-2.5 py-1 rounded-lg bg-emerald-500/20 hover:bg-emerald-500/30 border border-emerald-500/50 text-emerald-300 font-mono text-[11px] font-semibold flex items-center gap-1 transition cursor-pointer"
              title="Fast-forward simulation buffer to 1 Hour (3,600s) and export dataset immediately"
            >
              <FileSpreadsheet className="w-3.5 h-3.5" />
              <span>1-Hr Excel</span>
            </button>

            <button
              onClick={() => download1HourDataset("csv")}
              className="px-2.5 py-1 rounded-lg bg-cyan-500/20 hover:bg-cyan-500/30 border border-cyan-500/50 text-cyan-300 font-mono text-[11px] font-semibold flex items-center gap-1 transition cursor-pointer"
              title="Download 1-Hour second-by-second high-resolution CSV dataset (3,600 rows)"
            >
              <Download className="w-3.5 h-3.5" />
              <span>1-Hr CSV</span>
            </button>
          </div>

          {/* Live Parameter Telemetry Badges */}
          <div className="hidden 2xl:flex items-center gap-3 font-mono text-[11px] text-slate-400 pl-2 border-l border-slate-800">
            <div className="flex items-center gap-1">
              <span className="text-slate-500">V:</span>
              <span className="text-slate-200">{electricalParams.voltage}V</span>
            </div>
            <div className="flex items-center gap-1">
              <span className="text-slate-500">I:</span>
              <span className="text-slate-200">{electricalParams.current}A</span>
            </div>
            <div className="flex items-center gap-1">
              <span className="text-slate-500">PF:</span>
              <span className="text-emerald-400">{electricalParams.powerFactor}</span>
            </div>
            <div className="flex items-center gap-1">
              <span className="text-slate-500">Temp:</span>
              <span className="text-amber-300">{environmentalParams.ambientTemp}°C</span>
            </div>
          </div>
        </div>
      </div>

      {/* 1-Hour Completed Auto-Download Notification Banner */}
      {oneHourCompletedNotification && (
        <div className="mt-1.5 p-2 rounded-xl bg-gradient-to-r from-emerald-950/80 via-slate-900 to-cyan-950/80 border border-emerald-500/50 flex items-center justify-between text-xs animate-in fade-in">
          <div className="flex items-center gap-2">
            <CheckCircle2 className="w-4 h-4 text-emerald-400" />
            <span className="font-semibold text-emerald-200">
              1-Hour Full Campus Simulation Completed! (3,600 Second Records Generated)
            </span>
            <span className="text-slate-300 text-[11px] hidden sm:inline">
              — Automated second-by-second dataset download has been initiated for 4 Blocks & 12 Floors.
            </span>
          </div>
          <button
            onClick={() => setOneHourCompletedNotification(false)}
            className="text-slate-400 hover:text-white px-2 py-0.5 text-xs font-mono cursor-pointer"
          >
            ✕ Dismiss
          </button>
        </div>
      )}
    </div>
  );
}
