import React from "react";
import { CheckCircle2, AlertCircle, Info, RefreshCw } from "lucide-react";

export function EmptyState({
  title = "No data found",
  description = "No records match the current filters or operational parameters.",
  type = "info", // "info" | "success" | "warning"
  actionText,
  onAction
}) {
  const icons = {
    info: Info,
    success: CheckCircle2,
    warning: AlertCircle
  };

  const colors = {
    info: "text-cyan-400 bg-cyan-950/40 border-cyan-800/60",
    success: "text-emerald-400 bg-emerald-950/40 border-emerald-800/60",
    warning: "text-amber-400 bg-amber-950/40 border-amber-800/60"
  };

  const Icon = icons[type] || Info;

  return (
    <div className="flex flex-col items-center justify-center p-8 rounded-2xl bg-slate-900/40 border border-slate-800/80 text-center my-4">
      <div className={`p-3 rounded-2xl border ${colors[type]} mb-3`}>
        <Icon className="w-8 h-8" />
      </div>
      <h3 className="text-base font-semibold text-slate-200">{title}</h3>
      <p className="text-xs text-slate-400 max-w-sm mt-1">{description}</p>
      {actionText && onAction && (
        <button
          onClick={onAction}
          className="mt-4 px-4 py-1.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-medium flex items-center gap-1.5 transition cursor-pointer"
        >
          <RefreshCw className="w-3.5 h-3.5" />
          <span>{actionText}</span>
        </button>
      )}
    </div>
  );
}
