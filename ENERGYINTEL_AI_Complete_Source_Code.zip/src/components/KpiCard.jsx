import React from "react";
import { TrendingUp, TrendingDown, Minus } from "lucide-react";

export function KpiCard({
  title,
  value,
  unit = "",
  trend,
  trendType = "neutral", // "good" | "bad" | "neutral"
  icon: Icon,
  subtitle,
  badgeText,
  badgeColor = "cyan",
  color = "cyan",
  onClick
}) {
  const colorGradients = {
    cyan: "from-cyan-500/10 to-blue-500/5 border-cyan-500/20 text-cyan-400",
    green: "from-emerald-500/10 to-teal-500/5 border-emerald-500/20 text-emerald-400",
    amber: "from-amber-500/10 to-orange-500/5 border-amber-500/20 text-amber-400",
    rose: "from-rose-500/10 to-red-500/5 border-rose-500/20 text-rose-400",
    purple: "from-purple-500/10 to-indigo-500/5 border-purple-500/20 text-purple-400",
    blue: "from-blue-500/10 to-cyan-500/5 border-blue-500/20 text-blue-400"
  };

  const badgeStyles = {
    cyan: "bg-cyan-950/80 text-cyan-300 border-cyan-800",
    green: "bg-emerald-950/80 text-emerald-300 border-emerald-800",
    amber: "bg-amber-950/80 text-amber-300 border-amber-800",
    rose: "bg-rose-950/80 text-rose-300 border-rose-800",
    purple: "bg-purple-950/80 text-purple-300 border-purple-800",
    blue: "bg-blue-950/80 text-blue-300 border-blue-800"
  };

  return (
    <div
      onClick={onClick}
      className={`relative overflow-hidden rounded-2xl p-4 bg-gradient-to-br ${colorGradients[color] || colorGradients.cyan} border backdrop-blur-md transition-all duration-200 hover:border-cyan-500/40 hover:shadow-lg hover:shadow-cyan-500/10 ${onClick ? 'cursor-pointer' : ''}`}
    >
      <div className="flex items-start justify-between gap-2">
        <span className="text-xs font-medium text-slate-400 tracking-wide uppercase font-mono">
          {title}
        </span>
        {Icon && (
          <div className="p-2 rounded-xl bg-slate-900/80 border border-slate-800 text-slate-300">
            <Icon className="w-4 h-4" />
          </div>
        )}
      </div>

      <div className="mt-2 flex items-baseline gap-1.5">
        <span className="text-2xl lg:text-3xl font-black font-mono tracking-tight text-white">
          {value}
        </span>
        {unit && (
          <span className="text-xs font-semibold text-slate-400 font-mono">
            {unit}
          </span>
        )}
      </div>

      <div className="mt-2.5 flex items-center justify-between text-xs">
        {subtitle && (
          <span className="text-[11px] text-slate-400 truncate max-w-[140px]">
            {subtitle}
          </span>
        )}

        {badgeText && (
          <span className={`text-[10px] font-mono px-2 py-0.5 rounded-full border font-semibold ${badgeStyles[badgeColor] || badgeStyles.cyan}`}>
            {badgeText}
          </span>
        )}

        {trend && (
          <span className={`flex items-center gap-0.5 text-[11px] font-semibold font-mono ${
            trendType === "good" ? "text-emerald-400" : trendType === "bad" ? "text-rose-400" : "text-slate-400"
          }`}>
            {trendType === "good" && <TrendingDown className="w-3 h-3" />}
            {trendType === "bad" && <TrendingUp className="w-3 h-3" />}
            {trendType === "neutral" && <Minus className="w-3 h-3" />}
            {trend}
          </span>
        )}
      </div>
    </div>
  );
}
