import React, { useEffect, useRef, useState } from "react";
import * as THREE from "three";
import {
  RotateCcw,
  ZoomIn,
  ZoomOut,
  Eye,
  Maximize2,
  Sparkles,
  Layers,
  Zap,
  Fan,
  Sun
} from "lucide-react";
import { useEnergy } from "../context/EnergyContext";

export function ThreeDigitalTwinCanvas({
  selectedBuildingId,
  selectedFloorId,
  floorApplianceState
}) {
  const mountRef = useRef(null);
  const { campusConfig, activeAnomaly } = useEnergy();

  const [cameraView, setCameraView] = useState("isometric"); // "isometric" | "building" | "floor" | "top"

  // Scene references
  const sceneRef = useRef(null);
  const cameraRef = useRef(null);
  const rendererRef = useRef(null);
  const fanMeshesRef = useRef([]);
  const bulbMeshesRef = useRef([]);
  const pointLightsRef = useRef([]);
  const buildingGroupsRef = useRef({});
  const isMouseDownRef = useRef(false);
  const mousePosRef = useRef({ x: 0, y: 0 });
  const cameraTargetRef = useRef(new THREE.Vector3(0, 5, 0));

  // Building 3D Coordinates on the campus terrain
  const BUILDING_COORDS = {
    "bldg-1": { x: -16, z: -10, name: "Building 1 (Block A)", color: 0x0284c7 },
    "bldg-2": { x: -16, z: 12, name: "Building 2 (Block B)", color: 0x7c3aed },
    "bldg-3": { x: 16, z: -10, name: "Building 3 (Block C)", color: 0x059669 },
    "bldg-4": { x: 16, z: 12, name: "Building 4 (Block D)", color: 0xd97706 }
  };

  useEffect(() => {
    const mount = mountRef.current;
    if (!mount) return;

    // 1. SCENE SETUP
    const scene = new THREE.Scene();
    sceneRef.current = scene;
    scene.background = new THREE.Color(0x060a14);
    scene.fog = new THREE.FogExp2(0x060a14, 0.015);

    // 2. CAMERA SETUP
    const width = mount.clientWidth;
    const height = mount.clientHeight || 450;
    const camera = new THREE.PerspectiveCamera(45, width / height, 0.1, 1000);
    cameraRef.current = camera;
    camera.position.set(38, 32, 42);
    camera.lookAt(0, 4, 0);

    // 3. RENDERER SETUP
    const renderer = new THREE.WebGLRenderer({ antialias: true, alpha: true, powerPreference: "high-performance" });
    rendererRef.current = renderer;
    renderer.setSize(width, height);
    renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
    renderer.shadowMap.enabled = true;
    renderer.shadowMap.type = THREE.PCFSoftShadowMap;
    mount.appendChild(renderer.domElement);

    // 4. LIGHTING SETUP
    const ambientLight = new THREE.AmbientLight(0x1e293b, 1.8);
    scene.add(ambientLight);

    const sunLight = new THREE.DirectionalLight(0xffffff, 1.2);
    sunLight.position.set(30, 50, 20);
    sunLight.castShadow = true;
    sunLight.shadow.mapSize.width = 1024;
    sunLight.shadow.mapSize.height = 1024;
    scene.add(sunLight);

    const blueHemisphere = new THREE.HemisphereLight(0x00f0ff, 0x0f172a, 0.6);
    scene.add(blueHemisphere);

    // 5. CAMPUS TERRAIN & GROUND
    const groundGeo = new THREE.PlaneGeometry(120, 120, 32, 32);
    const groundMat = new THREE.MeshStandardMaterial({
      color: 0x090f1f,
      roughness: 0.85,
      metalness: 0.15
    });
    const ground = new THREE.Mesh(groundGeo, groundMat);
    ground.rotation.x = -Math.PI / 2;
    ground.position.y = 0;
    ground.receiveShadow = true;
    scene.add(ground);

    // Campus Grid Lines on Ground
    const gridHelper = new THREE.GridHelper(100, 40, 0x1e2e5c, 0x0f1a36);
    gridHelper.position.y = 0.02;
    scene.add(gridHelper);

    // Campus Pathways & Road network
    const roadMat = new THREE.MeshStandardMaterial({ color: 0x111c38, roughness: 0.7 });
    const roadX = new THREE.Mesh(new THREE.PlaneGeometry(100, 4), roadMat);
    roadX.rotation.x = -Math.PI / 2;
    roadX.position.set(0, 0.05, 1);
    scene.add(roadX);

    const roadZ = new THREE.Mesh(new THREE.PlaneGeometry(4, 100), roadMat);
    roadZ.rotation.x = -Math.PI / 2;
    roadZ.position.set(0, 0.05, 0);
    scene.add(roadZ);

    // Central Substation Model (in the middle crossroads)
    const subGeo = new THREE.BoxGeometry(4.5, 2.5, 4.5);
    const subMat = new THREE.MeshStandardMaterial({ color: 0xd97706, roughness: 0.4, metalness: 0.6 });
    const subMesh = new THREE.Mesh(subGeo, subMat);
    subMesh.position.set(0, 1.25, 0);
    subMesh.castShadow = true;
    scene.add(subMesh);

    // Substation Beacon Light
    const beacon = new THREE.PointLight(0xf59e0b, 1.5, 12);
    beacon.position.set(0, 3.2, 0);
    scene.add(beacon);

    // 6. BUILD THE 4 BUILDINGS
    const bGroups = {};
    buildingGroupsRef.current = bGroups;

    Object.entries(BUILDING_COORDS).forEach(([bId, info]) => {
      const bGroup = new THREE.Group();
      bGroup.position.set(info.x, 0, info.z);
      scene.add(bGroup);
      bGroups[bId] = bGroup;

      const floorHeight = 3.6;
      const bWidth = 16;
      const bDepth = 12;

      // 3 Stacked Floors per building
      for (let f = 1; f <= 3; f++) {
        const floorY = (f - 1) * floorHeight + 0.1;
        const floorGroup = new THREE.Group();
        floorGroup.name = `${bId}-f${f}`;
        floorGroup.position.y = floorY;
        bGroup.add(floorGroup);

        // Floor Concrete Slab
        const slabGeo = new THREE.BoxGeometry(bWidth, 0.35, bDepth);
        const slabMat = new THREE.MeshStandardMaterial({
          color: 0x1e293b,
          roughness: 0.6,
          metalness: 0.2
        });
        const slab = new THREE.Mesh(slabGeo, slabMat);
        slab.position.y = 0.175;
        slab.castShadow = true;
        slab.receiveShadow = true;
        floorGroup.add(slab);

        // Glass Curtain Walls
        const glassGeo = new THREE.BoxGeometry(bWidth - 0.2, floorHeight - 0.4, bDepth - 0.2);
        const isBldg2Anomaly = bId === "bldg-2" && f === 2 && activeAnomaly;
        const glassMat = new THREE.MeshPhysicalMaterial({
          color: isBldg2Anomaly ? 0xf43f5e : info.color,
          transparent: true,
          opacity: 0.22,
          roughness: 0.1,
          transmission: 0.85,
          thickness: 0.5
        });
        const glass = new THREE.Mesh(glassGeo, glassMat);
        glass.position.y = floorHeight / 2;
        floorGroup.add(glass);

        // Columns / Pillars
        const colGeo = new THREE.CylinderGeometry(0.2, 0.2, floorHeight - 0.35, 8);
        const colMat = new THREE.MeshStandardMaterial({ color: 0x334155, metalness: 0.4 });
        [
          [-bWidth / 2 + 0.5, -bDepth / 2 + 0.5],
          [bWidth / 2 - 0.5, -bDepth / 2 + 0.5],
          [-bWidth / 2 + 0.5, bDepth / 2 - 0.5],
          [bWidth / 2 - 0.5, bDepth / 2 - 0.5]
        ].forEach(([cx, cz]) => {
          const col = new THREE.Mesh(colGeo, colMat);
          col.position.set(cx, floorHeight / 2, cz);
          floorGroup.add(col);
        });
      }

      // Rooftop Slabs & Chiller HVAC model on roof
      const roofY = 3 * floorHeight + 0.1;
      const roofSlab = new THREE.Mesh(
        new THREE.BoxGeometry(bWidth, 0.4, bDepth),
        new THREE.MeshStandardMaterial({ color: 0x0f172a, roughness: 0.8 })
      );
      roofSlab.position.y = roofY;
      roofSlab.castShadow = true;
      bGroup.add(roofSlab);

      // Rooftop Chiller Unit
      const chiller = new THREE.Mesh(
        new THREE.BoxGeometry(4, 1.8, 2.5),
        new THREE.MeshStandardMaterial({ color: 0x475569, metalness: 0.7, roughness: 0.3 })
      );
      chiller.position.set(0, roofY + 0.9, 0);
      chiller.castShadow = true;
      bGroup.add(chiller);
    });

    // 7. BUILD APPLIANCE MESHES (20 Bulbs, 10 Fans, 5 ACs) inside the Selected Floor
    const appliancesGroup = new THREE.Group();
    appliancesGroup.name = "activeAppliances";
    scene.add(appliancesGroup);

    // 8. INTERACTION: MOUSE ROTATION / DRAG
    const onMouseDown = (e) => {
      isMouseDownRef.current = true;
      mousePosRef.current = { x: e.clientX, y: e.clientY };
    };

    const onMouseMove = (e) => {
      if (!isMouseDownRef.current) return;
      const deltaX = e.clientX - mousePosRef.current.x;
      const deltaY = e.clientY - mousePosRef.current.y;
      mousePosRef.current = { x: e.clientX, y: e.clientY };

      const radius = camera.position.distanceTo(cameraTargetRef.current);
      const theta = Math.atan2(camera.position.x - cameraTargetRef.current.x, camera.position.z - cameraTargetRef.current.z) - deltaX * 0.008;
      const phi = Math.max(0.15, Math.min(Math.PI / 2 - 0.05, Math.atan2(camera.position.y - cameraTargetRef.current.y, Math.sqrt(Math.pow(camera.position.x - cameraTargetRef.current.x, 2) + Math.pow(camera.position.z - cameraTargetRef.current.z, 2))) + deltaY * 0.008));

      camera.position.x = cameraTargetRef.current.x + radius * Math.cos(phi) * Math.sin(theta);
      camera.position.y = cameraTargetRef.current.y + radius * Math.sin(phi);
      camera.position.z = cameraTargetRef.current.z + radius * Math.cos(phi) * Math.cos(theta);
      camera.lookAt(cameraTargetRef.current);
    };

    const onMouseUp = () => {
      isMouseDownRef.current = false;
    };

    const onWheel = (e) => {
      e.preventDefault();
      const zoomFactor = e.deltaY * 0.03;
      const dir = camera.position.clone().sub(cameraTargetRef.current).normalize();
      const newPos = camera.position.clone().addScaledVector(dir, zoomFactor);
      if (newPos.distanceTo(cameraTargetRef.current) > 10 && newPos.distanceTo(cameraTargetRef.current) < 120) {
        camera.position.copy(newPos);
      }
    };

    const domEl = renderer.domElement;
    domEl.addEventListener("mousedown", onMouseDown);
    window.addEventListener("mousemove", onMouseMove);
    window.addEventListener("mouseup", onMouseUp);
    domEl.addEventListener("wheel", onWheel, { passive: false });

    // Handle Window Resize
    const handleResize = () => {
      if (!mountRef.current) return;
      const w = mountRef.current.clientWidth;
      const h = mountRef.current.clientHeight || 450;
      camera.aspect = w / h;
      camera.updateProjectionMatrix();
      renderer.setSize(w, h);
    };
    window.addEventListener("resize", handleResize);

    // 9. ANIMATION LOOP
    let animId;
    const animate = () => {
      animId = requestAnimationFrame(animate);

      // Rotate fan blades dynamically based on speed
      fanMeshesRef.current.forEach((fan) => {
        if (fan && fan.rotationSpeed > 0) {
          fan.rotation.y += fan.rotationSpeed;
        }
      });

      renderer.render(scene, camera);
    };
    animate();

    return () => {
      cancelAnimationFrame(animId);
      domEl.removeEventListener("mousedown", onMouseDown);
      window.removeEventListener("mousemove", onMouseMove);
      window.removeEventListener("mouseup", onMouseUp);
      domEl.removeEventListener("wheel", onWheel);
      window.removeEventListener("resize", handleResize);
      if (mount.contains(renderer.domElement)) {
        mount.removeChild(renderer.domElement);
      }
      renderer.dispose();
    };
  }, []);

  // Update Appliances Inside the Selected Floor (20 Bulbs, 10 Fans, 5 ACs)
  useEffect(() => {
    const scene = sceneRef.current;
    if (!scene || !floorApplianceState) return;

    // Remove old appliance meshes
    const oldGroup = scene.getObjectByName("activeAppliances");
    if (oldGroup) scene.remove(oldGroup);

    const appliancesGroup = new THREE.Group();
    appliancesGroup.name = "activeAppliances";
    scene.add(appliancesGroup);

    fanMeshesRef.current = [];
    bulbMeshesRef.current = [];
    pointLightsRef.current = [];

    const bInfo = BUILDING_COORDS[selectedBuildingId] || BUILDING_COORDS["bldg-1"];
    const floorHeight = 3.6;
    const floorNum = floorApplianceState.floorNumber || 1;
    const floorY = (floorNum - 1) * floorHeight + 0.1;
    const ceilingY = floorY + floorHeight - 0.4;

    appliancesGroup.position.set(bInfo.x, 0, bInfo.z);

    // 1. CREATE 20 BULBS (4 rows × 5 columns on ceiling)
    const bulbCols = 5;
    const bulbRows = 4;
    const spacingX = 2.4;
    const spacingZ = 2.2;

    for (let i = 0; i < 20; i++) {
      const col = i % bulbCols;
      const row = Math.floor(i / bulbCols);
      const bx = (col - 2) * spacingX;
      const bz = (row - 1.5) * spacingZ;
      const isOn = floorApplianceState.bulbs && floorApplianceState.bulbs[i];

      // Cord from ceiling
      const cord = new THREE.Mesh(
        new THREE.CylinderGeometry(0.02, 0.02, 0.5, 6),
        new THREE.MeshBasicMaterial({ color: 0x1e293b })
      );
      cord.position.set(bx, ceilingY - 0.25, bz);
      appliancesGroup.add(cord);

      // Bulb Mesh
      const bulbGeo = new THREE.SphereGeometry(0.2, 12, 12);
      const bulbMat = new THREE.MeshStandardMaterial({
        color: isOn ? 0xfff3a1 : 0x334155,
        emissive: isOn ? 0xfef08a : 0x0f172a,
        emissiveIntensity: isOn ? 1.4 : 0.05,
        roughness: 0.2
      });
      const bulbMesh = new THREE.Mesh(bulbGeo, bulbMat);
      bulbMesh.position.set(bx, ceilingY - 0.55, bz);
      appliancesGroup.add(bulbMesh);
      bulbMeshesRef.current.push(bulbMesh);

      // Real Point Light illumination (if on)
      if (isOn && i % 2 === 0) { // Add illumination lights strategically
        const pLight = new THREE.PointLight(0xffedd5, 0.6, 5);
        pLight.position.set(bx, ceilingY - 0.7, bz);
        appliancesGroup.add(pLight);
        pointLightsRef.current.push(pLight);
      }
    }

    // 2. CREATE 10 FANS (2 rows × 5 columns)
    const fanCols = 5;
    const fanRows = 2;
    const fanSpacingX = 2.6;
    const fanSpacingZ = 3.8;

    for (let j = 0; j < 10; j++) {
      const col = j % fanCols;
      const row = Math.floor(j / fanCols);
      const fx = (col - 2) * fanSpacingX;
      const fz = (row - 0.5) * fanSpacingZ;
      const isOn = floorApplianceState.fans && floorApplianceState.fans[j];

      const fanAssembly = new THREE.Group();
      fanAssembly.position.set(fx, ceilingY - 0.45, fz);
      appliancesGroup.add(fanAssembly);

      // Fan Rod
      const rod = new THREE.Mesh(
        new THREE.CylinderGeometry(0.04, 0.04, 0.4, 6),
        new THREE.MeshStandardMaterial({ color: 0x64748b })
      );
      rod.position.y = 0.2;
      fanAssembly.add(rod);

      // Rotating Hub & Blades Group
      const rotatingBlades = new THREE.Group();
      rotatingBlades.rotationSpeed = isOn ? 0.35 : 0; // Speed when active
      fanAssembly.add(rotatingBlades);
      fanMeshesRef.current.push(rotatingBlades);

      // Motor Hub
      const motor = new THREE.Mesh(
        new THREE.CylinderGeometry(0.25, 0.25, 0.15, 12),
        new THREE.MeshStandardMaterial({ color: 0x38bdf8, metalness: 0.5 })
      );
      rotatingBlades.add(motor);

      // 3 Blades at 120 degrees
      for (let b = 0; b < 3; b++) {
        const bladeGeo = new THREE.BoxGeometry(0.85, 0.02, 0.2);
        const bladeMat = new THREE.MeshStandardMaterial({ color: 0x94a3b8, roughness: 0.4 });
        const blade = new THREE.Mesh(bladeGeo, bladeMat);
        blade.position.x = 0.45;
        const bladeWrapper = new THREE.Group();
        bladeWrapper.rotation.y = (b * Math.PI * 2) / 3;
        bladeWrapper.add(blade);
        rotatingBlades.add(bladeWrapper);
      }
    }

    // 3. CREATE 5 AC UNITS (Mounted along the back wall)
    const acSpacing = 2.8;
    for (let k = 0; k < 5; k++) {
      const ax = (k - 2) * acSpacing;
      const az = -5.4; // along back wall
      const isOn = floorApplianceState.acs && floorApplianceState.acs[k];

      const acMesh = new THREE.Mesh(
        new THREE.BoxGeometry(1.4, 0.6, 0.4),
        new THREE.MeshStandardMaterial({
          color: isOn ? 0xffffff : 0x64748b,
          roughness: 0.3,
          metalness: 0.1
        })
      );
      acMesh.position.set(ax, ceilingY - 0.7, az);
      appliancesGroup.add(acMesh);

      // AC Status LED Indicator
      const led = new THREE.Mesh(
        new THREE.SphereGeometry(0.05, 8, 8),
        new THREE.MeshBasicMaterial({ color: isOn ? 0x00f0ff : 0xef4444 })
      );
      led.position.set(ax + 0.5, ceilingY - 0.8, az + 0.21);
      appliancesGroup.add(led);

      // Cool Air Flow Particle Plane (if on)
      if (isOn) {
        const flowMat = new THREE.MeshBasicMaterial({
          color: 0x38bdf8,
          transparent: true,
          opacity: 0.3
        });
        const airflow = new THREE.Mesh(new THREE.PlaneGeometry(1.2, 0.8), flowMat);
        airflow.rotation.x = Math.PI / 4;
        airflow.position.set(ax, ceilingY - 1.1, az + 0.4);
        appliancesGroup.add(airflow);
      }
    }

    // Glowing Neon Highlight Box around the Selected Floor
    const highlightGeo = new THREE.BoxGeometry(16.2, 0.1, 12.2);
    const highlightMat = new THREE.MeshBasicMaterial({
      color: 0x00f0ff,
      wireframe: true
    });
    const highlightMesh = new THREE.Mesh(highlightGeo, highlightMat);
    highlightMesh.position.set(0, floorY + 0.05, 0);
    appliancesGroup.add(highlightMesh);

  }, [selectedBuildingId, selectedFloorId, floorApplianceState]);

  // Handle Camera Presets
  const setCameraPreset = (preset) => {
    const camera = cameraRef.current;
    if (!camera) return;
    setCameraView(preset);

    const bInfo = BUILDING_COORDS[selectedBuildingId] || BUILDING_COORDS["bldg-1"];

    if (preset === "isometric") {
      cameraTargetRef.current.set(0, 4, 0);
      camera.position.set(38, 32, 42);
      camera.lookAt(0, 4, 0);
    } else if (preset === "building") {
      cameraTargetRef.current.set(bInfo.x, 6, bInfo.z);
      camera.position.set(bInfo.x + 18, 14, bInfo.z + 18);
      camera.lookAt(bInfo.x, 6, bInfo.z);
    } else if (preset === "floor") {
      const floorNum = floorApplianceState?.floorNumber || 1;
      const floorY = (floorNum - 1) * 3.6 + 2.0;
      cameraTargetRef.current.set(bInfo.x, floorY, bInfo.z);
      camera.position.set(bInfo.x, floorY + 4, bInfo.z + 14);
      camera.lookAt(bInfo.x, floorY, bInfo.z);
    } else if (preset === "top") {
      cameraTargetRef.current.set(0, 0, 0);
      camera.position.set(0, 65, 0.1);
      camera.lookAt(0, 0, 0);
    }
  };

  return (
    <div className="relative w-full h-[480px] rounded-2xl overflow-hidden bg-[#060a14] border border-slate-800 shadow-2xl">
      {/* 3D WebGL Canvas Mount */}
      <div ref={mountRef} className="w-full h-full cursor-grab active:cursor-grabbing" />

      {/* Top Floating View Controls */}
      <div className="absolute top-3 left-3 flex items-center gap-1.5 bg-[#0b1329]/90 backdrop-blur-md p-1.5 rounded-xl border border-slate-700/80 text-xs">
        <span className="text-[10px] font-mono text-cyan-400 font-bold px-1.5">3D VIEWS:</span>
        {[
          { id: "isometric", label: "Campus 3D" },
          { id: "building", label: "Building Focus" },
          { id: "floor", label: "Floor X-Ray" },
          { id: "top", label: "Top View" }
        ].map((view) => (
          <button
            key={view.id}
            onClick={() => setCameraPreset(view.id)}
            className={`px-2.5 py-1 rounded-lg font-mono text-[11px] font-medium transition cursor-pointer ${
              cameraView === view.id
                ? "bg-cyan-500 text-black font-bold shadow-md shadow-cyan-500/30"
                : "text-slate-300 hover:text-white hover:bg-slate-800"
            }`}
          >
            {view.label}
          </button>
        ))}
      </div>

      {/* Live 3D Overlay Telemetry HUD */}
      <div className="absolute top-3 right-3 bg-[#0b1329]/90 backdrop-blur-md p-3 rounded-xl border border-slate-700/80 text-xs font-mono space-y-1 text-slate-300">
        <div className="flex items-center justify-between gap-4">
          <span className="text-slate-400">Target:</span>
          <span className="text-cyan-300 font-bold">
            {BUILDING_COORDS[selectedBuildingId]?.name || "Building 1"}
          </span>
        </div>
        <div className="flex items-center justify-between gap-4">
          <span className="text-slate-400">Active Floor:</span>
          <span className="text-emerald-400 font-bold">
            Floor {floorApplianceState?.floorNumber || 1}
          </span>
        </div>
        <div className="flex items-center justify-between gap-4 border-t border-slate-800 pt-1 text-[11px]">
          <span className="flex items-center gap-1 text-yellow-300">
            <Sun className="w-3 h-3 text-yellow-400" />
            {floorApplianceState?.activeBulbsCount || 0}/20 Bulbs
          </span>
          <span className="flex items-center gap-1 text-cyan-300">
            <Fan className="w-3 h-3 text-cyan-400" />
            {floorApplianceState?.activeFansCount || 0}/10 Fans
          </span>
          <span className="flex items-center gap-1 text-blue-300">
            <Zap className="w-3 h-3 text-blue-400" />
            {floorApplianceState?.activeAcsCount || 0}/5 ACs
          </span>
        </div>
      </div>

      {/* Bottom Floating Legend / Help Hint */}
      <div className="absolute bottom-3 left-3 bg-[#0b1329]/90 backdrop-blur-md px-3 py-1.5 rounded-lg border border-slate-800 text-[11px] font-mono text-slate-400 flex items-center gap-3">
        <span>🖱️ Drag to rotate 3D view</span>
        <span>•</span>
        <span>📜 Scroll to zoom</span>
        <span>•</span>
        <span className="text-cyan-400">Active Bulbs cast real 3D light & Fans rotate!</span>
      </div>
    </div>
  );
}
