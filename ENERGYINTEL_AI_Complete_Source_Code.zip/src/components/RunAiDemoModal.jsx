import React, { useState, useEffect } from "react";
import {
  X,
  Sparkles,
  ChevronRight,
  ChevronLeft,
  Play,
  Pause,
  RotateCcw,
  Activity,
  Brain,
  AlertTriangle,
  Lightbulb,
  Coins,
  Leaf,
  CheckCircle2,
  Building2,
  ArrowRight,
  Zap
} from "lucide-react";
import confetti from "canvas-confetti";
import { useEnergy } from "../context/EnergyContext";

export function RunAiDemoModal() {
  const {
    isAiDemoModalOpen,
    closeAiDemo,
    aiDemoCurrentStep,
    setAiDemoCurrentStep,
    tariffINR,
    carbonSavingsKg,
    potentialSavingsINR,
    potentialWastageKWh,
    applyRecommendation,
    recommendations
  } = useEnergy();

  const [isAutoPlaying, setIsAutoPlaying] = useState(true);

  const STEPS = [
    {
      step: 1,
      title: "Step 1: Generate Facility Telemetry",
      subtitle: "Initializing Trident Campus simulated sensor data stream",
      icon: Activity,
      color: "from-cyan-500 to-blue-600",
      content: {
        headline: "Real-Time Telemetry Stream Ingested",
        details: [
          { label: "Campus Facility", value: "Trident Campus (Block A, B, C, D)" },
          { label: "Sensors Monitored", value: "Voltage, Current, Power Factor, Temp, Occupancy, AC, Lighting" },
          { label: "Sampling Frequency", value: "1.0-second high-resolution sub-metering telemetry (1 Hz)" },
          { label: "Data Integrity Status", value: "Verified (Cleaned & Validated Demonstration Data)" }
        ],
        highlight: "Data Layer initialized. 4 Blocks, 12 floors, 320 rooms continuously monitored at 1 Hz."
      }
    },
    {
      step: 2,
      title: "Step 2: Display Energy Consumption",
      subtitle: "Mapping active campus load & power draw against baseline",
      icon: Zap,
      color: "from-blue-500 to-indigo-600",
      content: {
        headline: "Active Campus Load: 82.4 kW | Today: 1,284 kWh",
        details: [
          { label: "Block A (Academic)", value: "33.45 kW (Efficiency: 91%)" },
          { label: "Block B (Labs & Compute)", value: "33.45 kW (Efficiency: 84%)" },
          { label: "Block C (Library & Audit)", value: "33.45 kW (Efficiency: 86%)" },
          { label: "Block D (Research Hub)", value: "33.45 kW (Efficiency: 89%)" }
        ],
        highlight: "Normal operations detected across 78% of circuits, but efficiency variance observed in Block B."
      }
    },
    {
      step: 3,
      title: "Step 3: AI Predicts Future Demand",
      subtitle: "Multivariate regression forecasts tomorrow's campus demand",
      icon: Brain,
      color: "from-purple-500 to-indigo-600",
      content: {
        headline: "Predicted Tomorrow: 1,420 kWh (+10.6% vs Today)",
        details: [
          { label: "Next Hour Load", value: "84.8 kW (Confidence Interval: ±4.2%)" },
          { label: "Expected Peak Period", value: "13:00 – 15:00 (Thermal & Academic Peak)" },
          { label: "Key Prediction Factor 1", value: "Ambient temperature rising to 36°C (+18% cooling load)" },
          { label: "Key Prediction Factor 2", value: "Afternoon lab schedule at 92% occupancy" }
        ],
        highlight: "Facility managers warned in advance of impending peak demand spike."
      }
    },
    {
      step: 4,
      title: "Step 4: AI Detects Abnormal Energy Pattern",
      subtitle: "Anomaly detection engine flags sudden deviation from expected curve",
      icon: AlertTriangle,
      color: "from-rose-500 to-amber-600",
      content: {
        headline: "Abnormal Consumption Flagged in Block B",
        details: [
          { label: "Observed Draw", value: "128.4 kW (Instantaneous Spike)" },
          { label: "Expected Baseline", value: "82.4 kW (56% unexpected surge)" },
          { label: "Location", value: "Block B — Floor 2 (Engineering Labs & Studio)" },
          { label: "Severity", value: "CRITICAL (Statistical z-score > 3.8)" }
        ],
        highlight: "AI differentiates between natural timetable activity and true electrical anomalies."
      }
    },
    {
      step: 5,
      title: "Step 5: AI Identifies Root-Cause Wastage",
      subtitle: "Cross-referencing occupancy sensors with HVAC telemetry",
      icon: Activity,
      color: "from-amber-500 to-orange-600",
      content: {
        headline: "Root Cause: Case 2 — AC ON + Low Occupancy",
        details: [
          { label: "Target Area", value: "Block B — Floor 2 (Microelectronics & Design Studio)" },
          { label: "Room Occupancy", value: "24% (Only 6 students present during lunch break)" },
          { label: "HVAC Duty Cycle", value: "78% continuous operation at 18°C setpoint" },
          { label: "Wasted Power", value: "8.6 kW unnecessary thermal draw" }
        ],
        highlight: "Sensors reveal heavy chilled air being dumped into nearly empty rooms."
      }
    },
    {
      step: 6,
      title: "Step 6: Generate Real-Time Alert",
      subtitle: "Automated notification pushed to Facility Operations Center",
      icon: AlertTriangle,
      color: "from-rose-600 to-red-600",
      content: {
        headline: "🔴 CRITICAL ALERT Dispatched",
        details: [
          { label: "Alert Subject", value: "HIGH ENERGY WASTAGE: Block B — Floor 2" },
          { label: "Dispatch Channel", value: "Dashboard, SMS, and BMS Automation Webhook" },
          { label: "Timestamp", value: "Immediate (Zero latency response)" },
          { label: "Assigned To", value: "Duty Facilities Engineer — HVAC Lead" }
        ],
        highlight: "Alert includes exact room numbers and root cause instead of vague alarm noise."
      }
    },
    {
      step: 7,
      title: "Step 7: Generate AI Recommendation",
      subtitle: "AI synthesizes actionable, prioritized instructions",
      icon: Lightbulb,
      color: "from-yellow-400 to-amber-500",
      content: {
        headline: "Intelligent Action Plan Generated",
        details: [
          { label: "Problem", value: "AC operating at 18°C setpoint during 24% occupancy period" },
          { label: "Reason", value: "Manual override switch engaged by previous morning lecture" },
          { label: "Recommended Action", value: "Reset setpoint to 24°C & enable PIR motion-damper modulation" },
          { label: "Implementation Ease", value: "Immediate (1-click BMS remote command)" }
        ],
        highlight: "Action tells the facility manager exactly what to do in plain language."
      }
    },
    {
      step: 8,
      title: "Step 8: Calculate Energy Savings",
      subtitle: "Quantifying daily and monthly kilowatt-hour conservation",
      icon: Zap,
      color: "from-emerald-500 to-teal-600",
      content: {
        headline: "Estimated Energy Saved: 186 kWh / Day",
        details: [
          { label: "Floor 2 AC Optimization", value: "34.2 kWh / day saved" },
          { label: "Campus-Wide Rollout", value: "186.0 kWh / day cumulative wastage eliminated" },
          { label: "Monthly Energy Saved", value: "5,580 kWh / month" },
          { label: "Campus Efficiency Gain", value: "Efficiency improves from 87% to 94%" }
        ],
        highlight: "186 kWh saved per day equals powering 18 average households."
      }
    },
    {
      step: 9,
      title: "Step 9: Calculate Cost Savings",
      subtitle: "Converting energy savings into INR financial reduction",
      icon: Coins,
      color: "from-emerald-400 to-green-600",
      content: {
        headline: "Direct Financial Savings: ₹1,488 / Day",
        details: [
          { label: "Campus Electricity Tariff", value: `₹${tariffINR.toFixed(2)} per kWh (Commercial Grid Rate)` },
          { label: "Daily Savings (186 kWh × ₹8)", value: "₹1,488 / day saved" },
          { label: "Monthly Bill Reduction", value: "₹44,640 / month" },
          { label: "Annual Projected Savings", value: "₹5,35,680 / year recurring ROI" }
        ],
        highlight: "Direct operational budget reduction with zero capital expenditure."
      }
    },
    {
      step: 10,
      title: "Step 10: Show Sustainability Impact",
      subtitle: "Quantifying CO₂ reduction and environmental footprint",
      icon: Leaf,
      color: "from-teal-400 to-emerald-500",
      content: {
        headline: "Environmental Impact: 152.5 kg CO₂ Reduced / Day",
        details: [
          { label: "Grid Carbon Factor", value: "0.82 kg CO₂ per kWh (CEA National Grid Standard)" },
          { label: "Daily Carbon Avoided", value: "152.5 kg CO₂ / day" },
          { label: "Annual Carbon Offset", value: "55.6 Metric Tonnes CO₂e / year" },
          { label: "Equivalent Impact", value: "Equivalent to planting 2,530 mature trees" }
        ],
        highlight: "Aligns university with Scope 2 Net-Zero and GRI sustainability standards."
      }
    }
  ];

  const currentStepData = STEPS[aiDemoCurrentStep - 1];

  // Auto-advance timer when autoplay is on
  useEffect(() => {
    if (!isAiDemoModalOpen || !isAutoPlaying) return;

    if (aiDemoCurrentStep === 10) {
      // Fire confetti celebration on step 10
      confetti({
        particleCount: 100,
        spread: 70,
        origin: { y: 0.6 }
      });
      return;
    }

    const timer = setTimeout(() => {
      setAiDemoCurrentStep(prev => Math.min(10, prev + 1));
    }, 4500);

    return () => clearTimeout(timer);
  }, [isAiDemoModalOpen, isAutoPlaying, aiDemoCurrentStep, setAiDemoCurrentStep]);

  if (!isAiDemoModalOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 backdrop-blur-md p-4 animate-fadeIn">
      <div className="bg-[#0b1329] border border-cyan-500/40 rounded-2xl w-full max-w-4xl shadow-2xl shadow-cyan-500/20 overflow-hidden flex flex-col max-h-[92vh]">
        {/* Modal Header */}
        <div className="px-6 py-4 bg-slate-900/90 border-b border-slate-800 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-xl bg-gradient-to-r from-cyan-500 to-blue-600 flex items-center justify-center shadow-lg shadow-cyan-500/30">
              <Sparkles className="w-5 h-5 text-black" />
            </div>
            <div>
              <div className="flex items-center gap-2">
                <h2 className="text-base font-bold text-white tracking-wide">
                  AI ENERGY INTELLIGENCE DEMONSTRATION
                </h2>
                <span className="text-[10px] font-mono px-2 py-0.5 rounded-full bg-cyan-950 border border-cyan-700 text-cyan-300 font-bold">
                  STEP {aiDemoCurrentStep} OF 10
                </span>
              </div>
              <p className="text-xs text-slate-400">
                End-to-End Guided Value Workflow for Evaluators & Facility Leaders
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={() => setIsAutoPlaying(prev => !prev)}
              className="px-2.5 py-1 rounded-lg bg-slate-800 text-slate-300 hover:text-white text-xs font-medium flex items-center gap-1 cursor-pointer"
            >
              {isAutoPlaying ? <Pause className="w-3.5 h-3.5" /> : <Play className="w-3.5 h-3.5" />}
              <span>{isAutoPlaying ? "Auto-Play ON" : "Paused"}</span>
            </button>
            <button
              onClick={closeAiDemo}
              className="p-1.5 rounded-lg bg-slate-800 text-slate-400 hover:text-white transition cursor-pointer"
            >
              <X className="w-5 h-5" />
            </button>
          </div>
        </div>

        {/* 10-Step Progress Stepper Line */}
        <div className="bg-slate-950 px-6 py-2.5 border-b border-slate-800/80 overflow-x-auto">
          <div className="flex items-center justify-between min-w-[650px] gap-1">
            {STEPS.map((s) => {
              const isPast = s.step < aiDemoCurrentStep;
              const isCurrent = s.step === aiDemoCurrentStep;
              return (
                <button
                  key={s.step}
                  onClick={() => {
                    setAiDemoCurrentStep(s.step);
                    setIsAutoPlaying(false);
                  }}
                  className={`flex flex-col items-center gap-1 group flex-1 cursor-pointer transition ${
                    isCurrent ? "opacity-100" : isPast ? "opacity-75" : "opacity-35"
                  }`}
                >
                  <div
                    className={`w-6 h-6 rounded-full flex items-center justify-center text-[10px] font-bold font-mono transition ${
                      isCurrent
                        ? "bg-cyan-400 text-black shadow-md shadow-cyan-400/50 scale-110"
                        : isPast
                        ? "bg-emerald-500 text-black"
                        : "bg-slate-800 text-slate-400"
                    }`}
                  >
                    {isPast ? "✓" : s.step}
                  </div>
                  <span className="text-[9px] font-medium text-slate-300 truncate max-w-[65px] text-center">
                    {s.title.split(":")[0].replace("Step ", "S")}
                  </span>
                </button>
              );
            })}
          </div>
        </div>

        {/* Step Body */}
        <div className="p-6 overflow-y-auto space-y-6 flex-1 bg-gradient-to-b from-[#0b1329] to-[#070b14]">
          {/* Step Header Card */}
          <div className="flex items-start gap-4 p-4 rounded-xl bg-slate-900/80 border border-slate-800 shadow-md">
            <div className={`p-3 rounded-xl bg-gradient-to-br ${currentStepData.color} text-white shadow-lg`}>
              <currentStepData.icon className="w-7 h-7" />
            </div>
            <div className="flex-1">
              <span className="text-xs font-mono font-bold text-cyan-400 uppercase tracking-wider">
                {currentStepData.title}
              </span>
              <h3 className="text-xl font-bold text-white mt-0.5">
                {currentStepData.content.headline}
              </h3>
              <p className="text-xs text-slate-300 mt-1">
                {currentStepData.subtitle}
              </p>
            </div>
          </div>

          {/* Step Key Details Grid */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
            {currentStepData.content.details.map((item, idx) => (
              <div
                key={idx}
                className="p-3.5 rounded-xl bg-slate-900/60 border border-slate-800/80 flex flex-col justify-between"
              >
                <span className="text-xs text-slate-400 font-medium">{item.label}</span>
                <span className="text-sm font-semibold text-slate-100 font-mono mt-1">
                  {item.value}
                </span>
              </div>
            ))}
          </div>

          {/* AI Intelligence Highlight Banner */}
          <div className="p-4 rounded-xl bg-gradient-to-r from-cyan-950/40 via-blue-950/30 to-purple-950/40 border border-cyan-800/50 flex items-center gap-3">
            <Brain className="w-6 h-6 text-cyan-400 flex-shrink-0" />
            <p className="text-xs text-cyan-200 font-medium">
              <strong className="text-white">AI Core Insight: </strong>
              {currentStepData.content.highlight}
            </p>
          </div>

          {/* Step 10 Grand Summary Card (Requirement 38 finish) */}
          {aiDemoCurrentStep === 10 && (
            <div className="p-5 rounded-2xl bg-gradient-to-br from-emerald-950/60 via-slate-900 to-cyan-950/60 border-2 border-emerald-500/60 shadow-xl shadow-emerald-500/20 text-center space-y-4 animate-scaleUp">
              <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-emerald-500/20 border border-emerald-400/50 text-emerald-300 text-xs font-bold tracking-wider uppercase">
                <CheckCircle2 className="w-4 h-4 text-emerald-400" />
                AI IDENTIFIED A SAVING OPPORTUNITY
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 pt-2">
                <div className="p-3 rounded-xl bg-slate-900/90 border border-slate-800">
                  <div className="text-xs text-slate-400">Potential Energy Saving</div>
                  <div className="text-2xl font-black text-emerald-400 font-mono mt-1">
                    186 kWh/day
                  </div>
                  <div className="text-[10px] text-slate-400 mt-0.5">5,580 kWh monthly</div>
                </div>

                <div className="p-3 rounded-xl bg-slate-900/90 border border-slate-800">
                  <div className="text-xs text-slate-400">Potential Cost Saving</div>
                  <div className="text-2xl font-black text-cyan-400 font-mono mt-1">
                    ₹1,488/day
                  </div>
                  <div className="text-[10px] text-slate-400 mt-0.5">₹44,640 monthly (at ₹8/kWh)</div>
                </div>

                <div className="p-3 rounded-xl bg-slate-900/90 border border-slate-800">
                  <div className="text-xs text-slate-400">Potential CO₂ Reduction</div>
                  <div className="text-2xl font-black text-teal-400 font-mono mt-1">
                    152.5 kg CO₂/day
                  </div>
                  <div className="text-[10px] text-slate-400 mt-0.5">55.6 Tonnes annually</div>
                </div>
              </div>

              <div className="pt-2 flex flex-wrap items-center justify-center gap-3">
                <button
                  onClick={() => {
                    recommendations.forEach(r => applyRecommendation(r.id));
                    closeAiDemo();
                  }}
                  className="px-5 py-2.5 rounded-xl bg-gradient-to-r from-emerald-500 to-teal-600 hover:from-emerald-400 hover:to-teal-500 text-black font-bold text-xs uppercase tracking-wider shadow-lg shadow-emerald-500/30 flex items-center gap-2 cursor-pointer transition transform hover:scale-105"
                >
                  <CheckCircle2 className="w-4 h-4" />
                  <span>Apply Optimization Recommendations to Live Campus</span>
                </button>
              </div>
            </div>
          )}
        </div>

        {/* Modal Navigation Footer */}
        <div className="px-6 py-3.5 bg-slate-900/95 border-t border-slate-800 flex items-center justify-between">
          <button
            onClick={() => {
              setAiDemoCurrentStep(prev => Math.max(1, prev - 1));
              setIsAutoPlaying(false);
            }}
            disabled={aiDemoCurrentStep === 1}
            className="px-3.5 py-1.5 rounded-xl bg-slate-800 text-slate-300 hover:bg-slate-700 disabled:opacity-40 disabled:cursor-not-allowed text-xs font-semibold flex items-center gap-1.5 cursor-pointer"
          >
            <ChevronLeft className="w-4 h-4" />
            <span>Previous Step</span>
          </button>

          <div className="flex items-center gap-2 text-xs text-slate-400 font-mono">
            <span>Progress: {Math.round((aiDemoCurrentStep / 10) * 100)}%</span>
            <div className="w-24 h-1.5 bg-slate-800 rounded-full overflow-hidden">
              <div
                className="h-full bg-gradient-to-r from-cyan-400 to-emerald-400 transition-all duration-300"
                style={{ width: `${(aiDemoCurrentStep / 10) * 100}%` }}
              ></div>
            </div>
          </div>

          {aiDemoCurrentStep < 10 ? (
            <button
              onClick={() => {
                setAiDemoCurrentStep(prev => Math.min(10, prev + 1));
                setIsAutoPlaying(false);
              }}
              className="px-4 py-1.5 rounded-xl bg-gradient-to-r from-cyan-500 to-blue-600 hover:from-cyan-400 hover:to-blue-500 text-white text-xs font-bold flex items-center gap-1.5 cursor-pointer shadow-md shadow-cyan-500/20"
            >
              <span>Next Step</span>
              <ChevronRight className="w-4 h-4" />
            </button>
          ) : (
            <button
              onClick={closeAiDemo}
              className="px-4 py-1.5 rounded-xl bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-bold cursor-pointer"
            >
              Close Demo
            </button>
          )}
        </div>
      </div>
    </div>
  );
}
