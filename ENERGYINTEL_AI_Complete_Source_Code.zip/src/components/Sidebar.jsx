import React from "react";
import {
  LayoutDashboard,
  LineChart,
  Brain,
  AlertTriangle,
  Building,
  Lightbulb,
  Sliders,
  Flame,
  Coins,
  Award,
  MessageSquareWarning,
  BellRing,
  FileSpreadsheet,
  FileText,
  Network,
  Compass,
  HelpCircle,
  Box,
  Database,
  ExternalLink,
  Share2,
  Download
} from "lucide-react";
import { downloadCodebaseZip } from "../services/zipDownloader";

export function Sidebar({ currentTab, setCurrentTab }) {
  const openInNewTab = (e, path) => {
    e.stopPropagation();
    window.open(`${window.location.origin}${path}`, "_blank");
  };

  const navSections = [
    {
      category: "FLOOR CONTROLS & 3D TWIN",
      items: [
        { id: "floorsim", label: "Floor % Sliders & 3D Twin", icon: Sliders, highlight: true },
        { id: "overview", label: "Campus Overview", icon: LayoutDashboard },
        { id: "digitaltwin", label: "Campus 3D Digital Twin", icon: Box, highlight: true, popoutPath: "/?view=digitaltwin" },
        { id: "bigdata", label: "Big Data Stream & SQL", icon: Database, highlight: true, popoutPath: "/?view=bigdata" },
        { id: "building", label: "Building Intelligence", icon: Building }
      ]
    },
    {
      category: "AI DIAGNOSTICS & ACTIONS",
      items: [
        { id: "analytics", label: "Energy Analytics", icon: LineChart },
        { id: "predictions", label: "AI Predictions", icon: Brain, highlight: true },
        { id: "wastage", label: "Wastage & Anomalies", icon: AlertTriangle, highlight: true },
        { id: "recommendations", label: "AI Recommendations", icon: Lightbulb, highlight: true }
      ]
    },
    {
      category: "SIMULATION & STRESS TEST",
      items: [
        { id: "simulations", label: "Simulation Lab & Stress", icon: Sliders, highlight: true, popoutPath: "/?view=simulations" },
        { id: "whatif", label: "What-If Simulator", icon: Sliders },
        { id: "peakdemand", label: "Peak Demand AI", icon: Flame }
      ]
    },
    {
      category: "FINANCIAL & ESG ACCOUNTING",
      items: [
        { id: "costcarbon", label: "Cost & Carbon ROI", icon: Coins },
        { id: "sustainability", label: "Campus Eco Score", icon: Award }
      ]
    },
    {
      category: "OPERATIONS, LOGS & APIS",
      items: [
        { id: "external", label: "External Links & APIs", icon: Share2, highlight: true, popoutPath: "/?view=external" },
        { id: "complaints", label: "Complaint NLP", icon: MessageSquareWarning },
        { id: "alerts", label: "Alerts Center", icon: BellRing },
        { id: "csvimport", label: "1-Hr Telemetry Export (1s)", icon: FileSpreadsheet, highlight: true },
        { id: "reports", label: "Reports & Export", icon: FileText, popoutPath: "/?view=reports" }
      ]
    },
    {
      category: "SYSTEM ARCHITECTURE",
      items: [
        { id: "architecture", label: "System Architecture", icon: Network },
        { id: "extensions", label: "Future Extensions", icon: Compass },
        { id: "pitch", label: "Why EnergyIntel AI?", icon: HelpCircle }
      ]
    }
  ];

  return (
    <aside className="w-64 flex-shrink-0 bg-[#080d1a] border-r border-slate-800/80 flex flex-col h-[calc(100vh-61px)] sticky top-[61px] overflow-y-auto">
      <div className="p-3 space-y-4">
        {navSections.map((section, idx) => (
          <div key={idx} className="space-y-1">
            <h3 className="px-3 text-[10px] font-bold uppercase tracking-wider text-slate-500 font-mono">
              {section.category}
            </h3>
            <div className="space-y-0.5">
              {section.items.map((item) => {
                const Icon = item.icon;
                const isActive = currentTab === item.id;
                return (
                  <button
                    key={item.id}
                    onClick={() => setCurrentTab(item.id)}
                    className={`w-full flex items-center justify-between px-3 py-2 rounded-xl text-xs font-medium transition-all cursor-pointer group ${
                      isActive
                        ? "bg-gradient-to-r from-cyan-500/20 to-blue-600/10 text-cyan-300 border border-cyan-500/30 shadow-sm shadow-cyan-500/10 font-semibold"
                        : "text-slate-400 hover:text-slate-100 hover:bg-slate-900/60"
                    }`}
                  >
                    <div className="flex items-center gap-2.5 truncate">
                      <Icon className={`w-4 h-4 flex-shrink-0 ${isActive ? "text-cyan-400" : "text-slate-400"}`} />
                      <span className="truncate">{item.label}</span>
                    </div>

                    <div className="flex items-center gap-1.5 flex-shrink-0">
                      {item.popoutPath && (
                        <span
                          onClick={(e) => openInNewTab(e, item.popoutPath)}
                          className="opacity-0 group-hover:opacity-100 p-1 hover:text-cyan-300 transition"
                          title="Open in dedicated separate browser tab"
                        >
                          <ExternalLink className="w-3 h-3 text-cyan-400" />
                        </span>
                      )}
                      {item.highlight && !isActive && (
                        <span className="w-1.5 h-1.5 rounded-full bg-cyan-400/80"></span>
                      )}
                    </div>
                  </button>
                );
              })}
            </div>
          </div>
        ))}
      </div>

      {/* Download Project Source Code ZIP button */}
      <div className="px-3 py-2">
        <a
          href="/ENERGYINTEL_AI_Complete_Source_Code.zip"
          download="ENERGYINTEL_AI_Complete_Source_Code.zip"
          className="w-full flex items-center justify-center gap-2 py-2 px-3 rounded-xl bg-emerald-500/15 border border-emerald-500/40 text-emerald-300 hover:bg-emerald-500/25 hover:text-white text-xs font-bold font-mono transition cursor-pointer"
        >
          <Download className="w-3.5 h-3.5" />
          <span>Download Code (ZIP)</span>
        </a>
      </div>

      {/* Footer System Status Info */}
      <div className="mt-auto p-3 m-2 rounded-xl bg-slate-900/80 border border-slate-800 text-[11px] space-y-1.5">
        <div className="flex items-center justify-between text-slate-400">
          <span>Three.js 3D Twin</span>
          <span className="text-emerald-400 font-mono font-semibold flex items-center gap-1">
            <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-ping"></span> Active
          </span>
        </div>
        <div className="flex items-center justify-between text-slate-400">
          <span>Grid Frequency</span>
          <span className="text-slate-200 font-mono">50.02 Hz</span>
        </div>
        <div className="flex items-center justify-between text-slate-400">
          <span>Campus Layout</span>
          <span className="text-cyan-300 font-mono font-semibold">4 Bldgs / 12 Floors</span>
        </div>
      </div>
    </aside>
  );
}
