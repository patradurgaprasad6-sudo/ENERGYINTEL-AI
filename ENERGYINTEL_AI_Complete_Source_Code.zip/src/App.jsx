import React, { useState, useEffect } from "react";
import { EnergyProvider } from "./context/EnergyContext";
import { LoginPage } from "./pages/LoginPage";
import { Navbar } from "./components/Navbar";
import { Sidebar } from "./components/Sidebar";
import { SimulationControlBar } from "./components/SimulationControlBar";
import { RunAiDemoModal } from "./components/RunAiDemoModal";

// Core Pages
import { OverviewDashboard } from "./pages/OverviewDashboard";
import { EnergyAnalyticsPage } from "./pages/EnergyAnalyticsPage";
import { AiPredictionsPage } from "./pages/AiPredictionsPage";
import { WastageDetectionPage } from "./pages/WastageDetectionPage";
import { BuildingIntelligencePage } from "./pages/BuildingIntelligencePage";
import { RecommendationsPage } from "./pages/RecommendationsPage";
import { WhatIfSimulatorPage } from "./pages/WhatIfSimulatorPage";
import { PeakDemandPage } from "./pages/PeakDemandPage";
import { CostCarbonPage } from "./pages/CostCarbonPage";
import { SustainabilityScorePage } from "./pages/SustainabilityScorePage";
import { ComplaintAnalyticsPage } from "./pages/ComplaintAnalyticsPage";
import { AlertsCenterPage } from "./pages/AlertsCenterPage";
import { CsvImportPage } from "./pages/CsvImportPage";
import { ReportsPage } from "./pages/ReportsPage";
import { SystemArchitecturePage } from "./pages/SystemArchitecturePage";
import { FutureExtensionsPage } from "./pages/FutureExtensionsPage";
import { WhyThisSolutionPage } from "./pages/WhyThisSolutionPage";

// Multi-Tab & 3D Simulation Pages
import { FloorSimulationStudioPage } from "./pages/FloorSimulationStudioPage";
import { DigitalTwinPage } from "./pages/DigitalTwinPage";
import { BigDataExplorerPage } from "./pages/BigDataExplorerPage";
import { AdvancedSimulationSuitePage } from "./pages/AdvancedSimulationSuitePage";
import { ExternalLinksConnectorsPage } from "./pages/ExternalLinksConnectorsPage";

export function AppContent() {
  const [currentUser, setCurrentUser] = useState(null);
  const [currentTab, setCurrentTab] = useState("floorsim"); // Default directly to Floor % Sliders & 3D Twin!
  const [standaloneView, setStandaloneView] = useState(null);

  // Check URL parameters for standalone separate tab views (?view=digitaltwin, etc.)
  useEffect(() => {
    const params = new URLSearchParams(window.location.search);
    const viewParam = params.get("view") || params.get("tab");
    if (viewParam) {
      setStandaloneView(viewParam);
      // Automatically enable authenticated demo session for standalone tabs
      setCurrentUser({ username: "admin", role: "Facility Administrator", mode: "standalone" });
    }
  }, []);

  const handleLoginSuccess = (user) => {
    setCurrentUser(user);
  };

  const handleLogout = () => {
    setCurrentUser(null);
  };

  // If running in a dedicated standalone separate browser tab
  if (standaloneView) {
    return (
      <div className="min-h-screen bg-[#070b14] text-slate-100 flex flex-col font-sans">
        <header className="bg-[#0b1329] border-b border-slate-800 px-6 py-3 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <span className="font-bold text-white tracking-wider">
              ENERGY<span className="text-cyan-400">INTEL</span> AI
            </span>
            <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-cyan-950 text-cyan-300 border border-cyan-800 font-bold uppercase">
              STANDALONE WORKSPACE TAB
            </span>
          </div>
          <div className="flex items-center gap-3">
            <button
              onClick={() => {
                window.location.href = window.location.origin;
              }}
              className="text-xs text-slate-400 hover:text-white transition cursor-pointer font-mono"
            >
              ← Back to Main Operations Center
            </button>
          </div>
        </header>

        <SimulationControlBar />

        <main className="flex-1 p-4 md:p-6 lg:p-8 max-w-7xl mx-auto w-full">
          {standaloneView === "floorsim" && <FloorSimulationStudioPage />}
          {standaloneView === "digitaltwin" && <DigitalTwinPage isStandalone={true} />}
          {standaloneView === "bigdata" && <BigDataExplorerPage isStandalone={true} />}
          {standaloneView === "simulations" && <AdvancedSimulationSuitePage isStandalone={true} />}
          {standaloneView === "external" && <ExternalLinksConnectorsPage isStandalone={true} />}
          {standaloneView === "reports" && <ReportsPage />}
          {!["floorsim", "digitaltwin", "bigdata", "simulations", "external", "reports"].includes(standaloneView) && (
            <FloorSimulationStudioPage />
          )}
        </main>
      </div>
    );
  }

  if (!currentUser) {
    return <LoginPage onLoginSuccess={handleLoginSuccess} />;
  }

  const renderActiveTab = () => {
    switch (currentTab) {
      case "floorsim":
        return <FloorSimulationStudioPage />;
      case "overview":
        return <OverviewDashboard setCurrentTab={setCurrentTab} />;
      case "digitaltwin":
        return <DigitalTwinPage />;
      case "bigdata":
        return <BigDataExplorerPage />;
      case "simulations":
        return <AdvancedSimulationSuitePage />;
      case "external":
        return <ExternalLinksConnectorsPage />;
      case "analytics":
        return <EnergyAnalyticsPage />;
      case "predictions":
        return <AiPredictionsPage />;
      case "wastage":
        return <WastageDetectionPage setCurrentTab={setCurrentTab} />;
      case "building":
        return <BuildingIntelligencePage setCurrentTab={setCurrentTab} />;
      case "recommendations":
        return <RecommendationsPage />;
      case "whatif":
        return <WhatIfSimulatorPage />;
      case "peakdemand":
        return <PeakDemandPage />;
      case "costcarbon":
        return <CostCarbonPage />;
      case "sustainability":
        return <SustainabilityScorePage />;
      case "complaints":
        return <ComplaintAnalyticsPage />;
      case "alerts":
        return <AlertsCenterPage setCurrentTab={setCurrentTab} />;
      case "csvimport":
        return <CsvImportPage />;
      case "reports":
        return <ReportsPage />;
      case "architecture":
        return <SystemArchitecturePage />;
      case "extensions":
        return <FutureExtensionsPage />;
      case "pitch":
        return <WhyThisSolutionPage setCurrentTab={setCurrentTab} />;
      default:
        return <FloorSimulationStudioPage />;
    }
  };

  return (
    <div className="min-h-screen bg-[#070b14] text-slate-100 flex flex-col font-sans">
      {/* Top Navbar */}
      <Navbar
        onLogout={handleLogout}
        currentTab={currentTab}
        setCurrentTab={setCurrentTab}
      />

      {/* Global Interactive Simulation Telemetry Control Bar */}
      <SimulationControlBar />

      {/* Main Layout Area */}
      <div className="flex flex-1 w-full">
        {/* Left Navigation Sidebar */}
        <Sidebar currentTab={currentTab} setCurrentTab={setCurrentTab} />

        {/* Content View Area */}
        <main className="flex-1 p-4 md:p-6 lg:p-8 max-w-7xl mx-auto w-full overflow-y-auto">
          {renderActiveTab()}
        </main>
      </div>

      {/* RUN AI DEMO Global 10-Step Interactive Sequence Modal */}
      <RunAiDemoModal />
    </div>
  );
}

export default function App() {
  return (
    <EnergyProvider>
      <AppContent />
    </EnergyProvider>
  );
}
