// Realistic Data Generator & Models for TRIDENT CAMPUS
// SPECIFICATION: 4 Buildings, 3 Floors each.
// PER FLOOR: 20 Bulbs (20W each), 10 Fans (75W each), 5 ACs (2000W each).
// Max Floor Appliance Load = 400W + 750W + 10,000W = 11,150W (11.15 kW).

export const APPLIANCE_SPECS = {
  bulbs: {
    count: 20,
    wattagePerUnit: 20, // 20 Watts each
    totalCapacityW: 400,
    name: "LED Bulbs",
    unit: "Bulb"
  },
  fans: {
    count: 10,
    wattagePerUnit: 75, // 75 Watts each
    totalCapacityW: 750,
    name: "Ceiling Fans",
    unit: "Fan"
  },
  acs: {
    count: 5,
    wattagePerUnit: 2000, // 2000 Watts (2kW) each
    totalCapacityW: 10000,
    name: "Split AC Units",
    unit: "AC"
  }
};

export const CAMPUS_CONFIG = {
  name: "Trident Campus",
  totalStudents: 3250,
  totalFacultyStaff: 320,
  totalAreaSqFt: 240000,
  gridTariffINR: 8.0, // ₹8 per kWh commercial tariff
  co2Factor: 0.82, // CEA India grid emission factor: 0.82 kg CO2 / kWh
  baselinePowerKW: 82.4,
  buildings: [
    {
      id: "bldg-1",
      name: "Building 1 — Block A (Academic Complex)",
      shortName: "Building 1 (Block A)",
      code: "1",
      type: "Lecture Halls & Administration",
      nominalPowerKW: 33.45,
      nominalEfficiency: 91,
      floors: [
        {
          id: "b1-f1",
          number: 1,
          name: "Floor 1: Lecture Halls 101-104 & Dean Office",
          rooms: 6,
          areaSqFt: 20000,
          occupancyCapacity: 350
        },
        {
          id: "b1-f2",
          number: 2,
          name: "Floor 2: Classrooms 201-208 & Faculty Cabins",
          rooms: 8,
          areaSqFt: 20000,
          occupancyCapacity: 400
        },
        {
          id: "b1-f3",
          number: 3,
          name: "Floor 3: Seminar Hall, Conference Suite & Media Lab",
          rooms: 6,
          areaSqFt: 20000,
          occupancyCapacity: 250
        }
      ]
    },
    {
      id: "bldg-2",
      name: "Building 2 — Block B (Engineering & Compute Labs)",
      shortName: "Building 2 (Block B)",
      code: "2",
      type: "High-Tech Laboratories & Server Compute",
      nominalPowerKW: 33.45,
      nominalEfficiency: 84,
      floors: [
        {
          id: "b2-f1",
          number: 1,
          name: "Floor 1: AI & Robotics Labs, Server Room",
          rooms: 6,
          areaSqFt: 20000,
          occupancyCapacity: 220
        },
        {
          id: "b2-f2",
          number: 2,
          name: "Floor 2: Microelectronics, IoT Lab & Design Studio",
          rooms: 8,
          areaSqFt: 20000,
          occupancyCapacity: 300
        },
        {
          id: "b2-f3",
          number: 3,
          name: "Floor 3: Advanced Computing & Postgraduate Suites",
          rooms: 6,
          areaSqFt: 20000,
          occupancyCapacity: 200
        }
      ]
    },
    {
      id: "bldg-3",
      name: "Building 3 — Block C (Central Library & Auditorium)",
      shortName: "Building 3 (Block C)",
      code: "3",
      type: "Library, Dining & Large Auditorium",
      nominalPowerKW: 33.45,
      nominalEfficiency: 86,
      floors: [
        {
          id: "b3-f1",
          number: 1,
          name: "Floor 1: Digital Library & Silent Reading Lounges",
          rooms: 5,
          areaSqFt: 20000,
          occupancyCapacity: 450
        },
        {
          id: "b3-f2",
          number: 2,
          name: "Floor 2: Main Auditorium (600 Pax) & Exhibition Hall",
          rooms: 4,
          areaSqFt: 20000,
          occupancyCapacity: 650
        },
        {
          id: "b3-f3",
          number: 3,
          name: "Floor 3: Student Recreation, Lounge & Cafeteria",
          rooms: 6,
          areaSqFt: 20000,
          occupancyCapacity: 350
        }
      ]
    },
    {
      id: "bldg-4",
      name: "Building 4 — Block D (Research & Innovation Hub)",
      shortName: "Building 4 (Block D)",
      code: "4",
      type: "Incubation Center, Startup Bays & Cleanrooms",
      nominalPowerKW: 33.45,
      nominalEfficiency: 89,
      floors: [
        {
          id: "b4-f1",
          number: 1,
          name: "Floor 1: Startup Incubation Bays & Maker Space",
          rooms: 6,
          areaSqFt: 20000,
          occupancyCapacity: 250
        },
        {
          id: "b4-f2",
          number: 2,
          name: "Floor 2: Nanotech Cleanrooms & Advanced Photonics",
          rooms: 5,
          areaSqFt: 20000,
          occupancyCapacity: 180
        },
        {
          id: "b4-f3",
          number: 3,
          name: "Floor 3: IP Cell, Patent Drafting & Executive Boardroom",
          rooms: 5,
          areaSqFt: 20000,
          occupancyCapacity: 160
        }
      ]
    }
  ]
};

// Generate initial floor states with 20 bulbs, 10 fans, 5 ACs per floor
export function createInitialCampusFloorStates() {
  const states = {};

  CAMPUS_CONFIG.buildings.forEach((bldg) => {
    bldg.floors.forEach((fl) => {
      // Default initial on-rates
      const isSpecialAnomaly = bldg.id === "bldg-2" && fl.number === 2; // Building 2 Floor 2 anomaly
      const initialBulbsPct = isSpecialAnomaly ? 100 : 70; // 14 or 20 on
      const initialFansPct = isSpecialAnomaly ? 90 : 60;  // 6 or 9 on
      const initialAcsPct = isSpecialAnomaly ? 100 : 60;  // 3 or 5 on

      const activeBulbsCount = Math.round((initialBulbsPct / 100) * APPLIANCE_SPECS.bulbs.count);
      const activeFansCount = Math.round((initialFansPct / 100) * APPLIANCE_SPECS.fans.count);
      const activeAcsCount = Math.round((initialAcsPct / 100) * APPLIANCE_SPECS.acs.count);

      // Create individual boolean arrays for each appliance
      const bulbs = Array(APPLIANCE_SPECS.bulbs.count).fill(false).map((_, i) => i < activeBulbsCount);
      const fans = Array(APPLIANCE_SPECS.fans.count).fill(false).map((_, i) => i < activeFansCount);
      const acs = Array(APPLIANCE_SPECS.acs.count).fill(false).map((_, i) => i < activeAcsCount);

      states[fl.id] = {
        floorId: fl.id,
        buildingId: bldg.id,
        floorNumber: fl.number,
        bulbsPct: initialBulbsPct,
        fansPct: initialFansPct,
        acsPct: initialAcsPct,
        bulbs, // boolean[20]
        fans,  // boolean[10]
        acs,   // boolean[5]
        activeBulbsCount,
        activeFansCount,
        activeAcsCount,
        occupancyPct: isSpecialAnomaly ? 24 : Math.round(55 + Math.random() * 30),
        temperatureC: isSpecialAnomaly ? 19.5 : Number((23.5 + Math.random() * 2).toFixed(1))
      };
    });
  });

  return states;
}

// Compute power for a single floor in Watts and kW
export function calculateFloorConsumption(floorState) {
  if (!floorState) return { bulbsW: 0, fansW: 0, acsW: 0, totalW: 0, totalKW: 0 };

  const bulbsW = floorState.activeBulbsCount * APPLIANCE_SPECS.bulbs.wattagePerUnit; // active * 20W
  const fansW = floorState.activeFansCount * APPLIANCE_SPECS.fans.wattagePerUnit;     // active * 75W
  const acsW = floorState.activeAcsCount * APPLIANCE_SPECS.acs.wattagePerUnit;         // active * 2000W

  const totalW = bulbsW + fansW + acsW;
  const totalKW = Number((totalW / 1000).toFixed(2));

  return {
    bulbsW,
    fansW,
    acsW,
    totalW,
    totalKW
  };
}

// Generate 24-hour historical profile reflecting college operational schedule:
// Working Hours: 9:00 AM to 6:00 PM (09:00 - 18:00)
// Lunch Break: 1:00 PM to 2:00 PM (13:00 - 14:00)
// Pre-Hours & Post-Hours: 00:00 - 09:00 & 18:00 - 24:00 (Staircase & corridor lights continuously burning)
export function generateHourlyEnergyProfile(dateStr = "2026-10-08", anomalyOptions = {}) {
  const hours = [];
  const scheduleProfile = [
    // 00:00 - 05:00: Night Deep Standby (Campus Locked & Closed) — MUST BE < 1 kW individually
    // Essential IT & Emergency baseload: 0.18 - 0.20 kW (< 1 kW)
    // Continuous Staircase & Corridor lighting wastage: 0.42 - 0.44 kW (< 1 kW)
    // Total Actual Power Draw: 0.60 - 0.64 kW (STRICTLY < 1 kW)
    { hour: "00:00", status: "Night Deep Standby (< 1 kW)", occ: 0.01, temp: 24, baselineKW: 0.20, actualKW: 0.64, corridorWasteKW: 0.44, lunchWasteKW: 0, isOfficialWorking: false, isLunchBreak: false },
    { hour: "01:00", status: "Night Deep Standby (< 1 kW)", occ: 0.01, temp: 23, baselineKW: 0.18, actualKW: 0.60, corridorWasteKW: 0.42, lunchWasteKW: 0, isOfficialWorking: false, isLunchBreak: false },
    { hour: "02:00", status: "Night Deep Standby (< 1 kW)", occ: 0.01, temp: 23, baselineKW: 0.18, actualKW: 0.60, corridorWasteKW: 0.42, lunchWasteKW: 0, isOfficialWorking: false, isLunchBreak: false },
    { hour: "03:00", status: "Night Deep Standby (< 1 kW)", occ: 0.01, temp: 22, baselineKW: 0.18, actualKW: 0.60, corridorWasteKW: 0.42, lunchWasteKW: 0, isOfficialWorking: false, isLunchBreak: false },
    { hour: "04:00", status: "Night Deep Standby (< 1 kW)", occ: 0.01, temp: 22, baselineKW: 0.18, actualKW: 0.60, corridorWasteKW: 0.42, lunchWasteKW: 0, isOfficialWorking: false, isLunchBreak: false },
    { hour: "05:00", status: "Night Deep Standby (< 1 kW)", occ: 0.02, temp: 23, baselineKW: 0.19, actualKW: 0.62, corridorWasteKW: 0.43, lunchWasteKW: 0, isOfficialWorking: false, isLunchBreak: false },

    // 06:00 - 08:00: Pre-College Transition (Before 9 AM Opening) — MUST BE < 1 kW individually
    // Natural sunlight available, custodians & staff prep: 0.28 - 0.45 kW (< 1 kW)
    // Continuous Staircase & Corridor lighting burning: 0.44 - 0.45 kW (< 1 kW)
    // Total Actual Power Draw: 0.72 - 0.90 kW (STRICTLY < 1 kW)
    { hour: "06:00", status: "Pre-College Transition (< 1 kW)", occ: 0.06, temp: 24, baselineKW: 0.28, actualKW: 0.72, corridorWasteKW: 0.44, lunchWasteKW: 0, isOfficialWorking: false, isLunchBreak: false },
    { hour: "07:00", status: "Pre-College Transition (< 1 kW)", occ: 0.15, temp: 26, baselineKW: 0.35, actualKW: 0.80, corridorWasteKW: 0.45, lunchWasteKW: 0, isOfficialWorking: false, isLunchBreak: false },
    { hour: "08:00", status: "Pre-College Transition (< 1 kW)", occ: 0.42, temp: 28, baselineKW: 0.45, actualKW: 0.90, corridorWasteKW: 0.45, lunchWasteKW: 0, isOfficialWorking: false, isLunchBreak: false },

    // 09:00 - 13:00: Official Working Hours (Morning Academic Session)
    // Full classes, active laboratories, lecture halls. Occupancy: 88-96%. High operational efficiency.
    { hour: "09:00", status: "Official Hours (Classes Active)", occ: 0.88, temp: 31, baselineKW: 78.5, actualKW: 82.4, corridorWasteKW: 0, lunchWasteKW: 0, isOfficialWorking: true, isLunchBreak: false },
    { hour: "10:00", status: "Official Hours (Classes Active)", occ: 0.94, temp: 33, baselineKW: 84.0, actualKW: 88.2, corridorWasteKW: 0, lunchWasteKW: 0, isOfficialWorking: true, isLunchBreak: false },
    { hour: "11:00", status: "Official Hours (Peak Lecture Load)", occ: 0.96, temp: 34, baselineKW: 87.5, actualKW: 91.8, corridorWasteKW: 0, lunchWasteKW: 0, isOfficialWorking: true, isLunchBreak: false },
    { hour: "12:00", status: "Official Hours (Classes Active)", occ: 0.92, temp: 36, baselineKW: 86.0, actualKW: 90.5, corridorWasteKW: 0, lunchWasteKW: 0, isOfficialWorking: true, isLunchBreak: false },

    // 13:00 - 14:00: LUNCH BREAK (1:00 PM to 2:00 PM)
    // Occupancy drops to 22%! BUT empty classrooms & labs leave split ACs (18°C) and lights ON!
    // Legitimate Need: 42.0 kW. Actual Draw: 76.5 kW. Lunch Hour Wastage: 34.5 kW!
    { hour: "13:00", status: "LUNCH BREAK (1:00 - 2:00 PM)", occ: 0.22, temp: 37, baselineKW: 42.0, actualKW: 76.5, corridorWasteKW: 0, lunchWasteKW: 34.5, isOfficialWorking: false, isLunchBreak: true },

    // 14:00 - 18:00: Official Working Hours (Afternoon Session & High-Tech Labs)
    // Classes resume, afternoon heat high (36-37°C), heavy compressor refrigeration.
    { hour: "14:00", status: "Official Hours (Afternoon Labs)", occ: 0.90, temp: 37, baselineKW: 85.0, actualKW: 89.4, corridorWasteKW: 0, lunchWasteKW: 0, isOfficialWorking: true, isLunchBreak: false },
    { hour: "15:00", status: "Official Hours (Peak Lab Load)", occ: 0.88, temp: 36, baselineKW: 83.5, actualKW: 88.0, corridorWasteKW: 0, lunchWasteKW: 0, isOfficialWorking: true, isLunchBreak: false },
    { hour: "16:00", status: "Official Hours (Seminars & Classes)", occ: 0.78, temp: 34, baselineKW: 76.0, actualKW: 80.5, corridorWasteKW: 0, lunchWasteKW: 0, isOfficialWorking: true, isLunchBreak: false },
    { hour: "17:00", status: "Official Hours (Wrap-Up / Prep)", occ: 0.55, temp: 32, baselineKW: 62.0, actualKW: 67.2, corridorWasteKW: 0, lunchWasteKW: 0, isOfficialWorking: true, isLunchBreak: false },

    // 18:00 - 21:00: Post-College Dispersal (Past 6:00 PM Official Closing) — MUST BE < 1 kW individually
    // Classes ended at 18:00. Occupancy drops to <12%. Baselines: 0.30 - 0.42 kW (< 1 kW)
    // Continuous Staircase & Corridor lighting burning: 0.45 kW (< 1 kW)
    // Total Actual Power Draw: 0.76 - 0.92 kW (STRICTLY < 1 kW)
    { hour: "18:00", status: "Post-College Dispersal (< 1 kW)", occ: 0.12, temp: 30, baselineKW: 0.42, actualKW: 0.92, corridorWasteKW: 0.45, lunchWasteKW: 0, isOfficialWorking: false, isLunchBreak: false },
    { hour: "19:00", status: "Post-College Dispersal (< 1 kW)", occ: 0.08, temp: 28, baselineKW: 0.36, actualKW: 0.84, corridorWasteKW: 0.45, lunchWasteKW: 0, isOfficialWorking: false, isLunchBreak: false },
    { hour: "20:00", status: "Post-College Dispersal (< 1 kW)", occ: 0.05, temp: 27, baselineKW: 0.30, actualKW: 0.76, corridorWasteKW: 0.45, lunchWasteKW: 0, isOfficialWorking: false, isLunchBreak: false },

    // 21:00 - 23:59: Night Baseload (Campus Closed) — MUST BE < 1 kW individually
    // Essential Night standby & emergency: 0.18 - 0.24 kW (< 1 kW)
    // Continuous Staircase & Corridor lighting burning: 0.45 kW (< 1 kW)
    // Total Actual Power Draw: 0.62 - 0.70 kW (STRICTLY < 1 kW)
    { hour: "21:00", status: "Night Baseload (< 1 kW)", occ: 0.03, temp: 26, baselineKW: 0.24, actualKW: 0.70, corridorWasteKW: 0.45, lunchWasteKW: 0, isOfficialWorking: false, isLunchBreak: false },
    { hour: "22:00", status: "Night Baseload (< 1 kW)", occ: 0.02, temp: 25, baselineKW: 0.20, actualKW: 0.65, corridorWasteKW: 0.45, lunchWasteKW: 0, isOfficialWorking: false, isLunchBreak: false },
    { hour: "23:00", status: "Night Baseload (< 1 kW)", occ: 0.01, temp: 24, baselineKW: 0.18, actualKW: 0.62, corridorWasteKW: 0.45, lunchWasteKW: 0, isOfficialWorking: false, isLunchBreak: false }
  ];

  scheduleProfile.forEach((item) => {
    let actualKW = item.actualKW;
    let isAnomaly = false;

    if (anomalyOptions.includeSpike && (item.hour === "14:00" || item.hour === "15:00")) {
      actualKW = 128.4;
      isAnomaly = true;
    }

    const baseline = item.baselineKW;
    const predicted = Number((baseline + (item.isOfficialWorking ? 2.5 : 0.05)).toFixed(2));
    const totalWastageKW = Number(Math.max(0, actualKW - baseline).toFixed(2));

    hours.push({
      hour: item.hour,
      status: item.status,
      baseline,
      actual: actualKW,
      predicted,
      occupancyPct: Math.round(item.occ * 100),
      temperature: item.temp,
      corridorWasteKW: item.corridorWasteKW,
      lunchWasteKW: item.lunchWasteKW,
      equipmentIdleWasteKW: Number(Math.max(0, totalWastageKW - item.corridorWasteKW - item.lunchWasteKW).toFixed(2)),
      wastageKW: totalWastageKW,
      isOfficialWorking: item.isOfficialWorking,
      isLunchBreak: item.isLunchBreak,
      isAfterHours: !item.isOfficialWorking && !item.isLunchBreak,
      isAnomaly
    });
  });

  return hours;
}

export function generateWeeklyData() {
  const days = ["Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun"];
  return days.map((day, idx) => {
    const isWeekend = idx >= 5;
    const baseKWh = isWeekend ? 680 : 1310;
    const actual = isWeekend ? (idx === 6 ? 710 : 780) : Math.round(baseKWh + (Math.sin(idx) * 60));
    const predicted = isWeekend ? 660 : Math.round(baseKWh + 20);
    const wastage = actual > predicted ? actual - predicted : Math.round(actual * 0.12);
    return {
      day,
      actual,
      predicted,
      baseline: isWeekend ? 620 : 1220,
      wastage,
      efficiencyPct: Math.round(100 - (wastage / actual * 100)),
      costINR: Math.round(actual * 8)
    };
  });
}

export function generateMonthlyData() {
  const months = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];
  const factors = [0.85, 0.88, 1.05, 1.35, 1.48, 1.42, 1.25, 1.20, 1.15, 1.02, 0.90, 0.82];
  
  return months.map((month, idx) => {
    const baseMonthlyKWh = 38000;
    const consumed = Math.round(baseMonthlyKWh * factors[idx]);
    const baseline = Math.round(baseMonthlyKWh * factors[idx] * 0.88);
    const predicted = Math.round(consumed * 0.97);
    const wastage = Math.round(consumed - baseline);
    return {
      month,
      consumed,
      baseline,
      predicted,
      wastage,
      costINR: consumed * 8,
      savingsINR: wastage * 8,
      co2Tonnes: Number((consumed * 0.82 / 1000).toFixed(1))
    };
  });
}

export const INITIAL_RECOMMENDATIONS = [
  {
    id: "rec-1",
    title: "Staircase & Corridor Lighting Automation (Before 9 AM & After 6 PM)",
    building: "All 4 Blocks (Blocks A, B, C, D)",
    floor: "Stairwells & Hallways (All 12 Floors)",
    problem: "Staircase and corridor lighting circuits remain continuously illuminated before 9:00 AM and after 6:00 PM, drawing ~0.45 kW continuously (< 1 kW individually) across 15 off-duty hours.",
    reason: "Manual wall toggle switches left ON 24/7; absence of astronomical timers or PIR motion sensors in common areas.",
    action: "Deploy astronomical digital time-switches and dual-technology PIR motion sensors to automatically dim stairwell & corridor lighting to 15% standby mode (< 0.15 kW) outside official 9 AM - 6 PM hours.",
    energySavingKWh: 6.75,
    costSavingINR: 54.0,
    co2SavingKg: 5.5,
    priority: "CRITICAL",
    category: "Lighting Automation",
    easeOfImplementation: "Low effort (Relay & Sensor Retrofit)",
    status: "Active"
  },
  {
    id: "rec-2",
    title: "Lunch Break (1:00 PM - 2:00 PM) Classroom AC & Lighting Setback",
    building: "Block A & Block B Complex",
    floor: "Floors 1-3 (Lecture Halls & Labs)",
    problem: "Lecture halls are vacated during the 1:00 PM - 2:00 PM lunch break (occupancy drops to 22%), yet 18 split AC units (18°C setpoint) and lights run at full blast in empty rooms.",
    reason: "Students and faculty vacate for canteens without switching off; absence of automated lunch intermission setbacks.",
    action: "Enforce scheduled BMS lunch profile: float AC thermostats to 26°C and switch off classroom lighting between 13:00 and 14:00.",
    energySavingKWh: 34.5,
    costSavingINR: 276.0,
    co2SavingKg: 28.3,
    priority: "HIGH",
    category: "Schedule & HVAC Optimization",
    easeOfImplementation: "Immediate (Software Schedule)",
    status: "Active"
  },
  {
    id: "rec-3",
    title: "Peak Demand Load Shifting (Pre-Cooling)",
    building: "Campus Wide",
    floor: "All 4 Buildings",
    problem: "Severe 118 kW peak spike projected between 13:00 and 15:00 resulting in maximum demand penalty charges.",
    reason: "Simultaneous thermal peak combined with afternoon lab sessions.",
    action: "Pre-cool academic lecture blocks by 1.5°C between 11:30–12:30, then float chillers during peak tariff hours.",
    energySavingKWh: 58.0,
    costSavingINR: 464.0,
    co2SavingKg: 47.5,
    priority: "CRITICAL",
    category: "Peak Demand",
    easeOfImplementation: "Medium effort",
    status: "Active"
  },
  {
    id: "rec-4",
    title: "Post-Working Hours Lab Equipment Standby",
    building: "Building 2 (Block B)",
    floor: "Floor 1 (Robotics & AI)",
    problem: "Compute servers, laser cutters, and oscilloscope rigs draw 14.2 kW vampire load overnight.",
    reason: "No centralized smart power strips or end-of-day shutoff protocol.",
    action: "Deploy automated smart contactor shutoff for non-critical bench outlets at 20:30.",
    energySavingKWh: 42.0,
    costSavingINR: 336.0,
    co2SavingKg: 34.4,
    priority: "HIGH",
    category: "Plug Load Management",
    easeOfImplementation: "Low effort",
    status: "Active"
  },
  {
    id: "rec-5",
    title: "Weekend Base Load Audit & Compressor Isolation",
    building: "Building 3 (Block C)",
    floor: "Floor 2 (Auditorium)",
    problem: "Air handling units cycling continuously in 600-seater auditorium during zero-event weekends.",
    reason: "BMS weekend calendar override was not cleared after Friday guest lecture.",
    action: "Enforce event calendar integration to lock AHU operations on non-scheduled days.",
    energySavingKWh: 29.0,
    costSavingINR: 232.0,
    co2SavingKg: 23.8,
    priority: "MEDIUM",
    category: "BMS Automation",
    easeOfImplementation: "Immediate",
    status: "Active"
  }
];

export const INITIAL_ALERTS = [
  {
    id: "alert-1",
    severity: "CRITICAL",
    title: "Unexpected Energy Spike (+56%)",
    building: "Building 2 (Block B)",
    floor: "Floor 2 (Labs)",
    timestamp: "10 mins ago",
    description: "Abnormal surge from 82.4 kW to 128.4 kW. Chiller compressor cycling erratically.",
    recommendedAction: "Dispatch electrical technician to inspect Chiller Pump B2 and reset breaker."
  },
  {
    id: "alert-2",
    severity: "HIGH",
    title: "High Energy Wastage Detected",
    building: "Building 2 (Block B)",
    floor: "Floor 2",
    timestamp: "24 mins ago",
    description: "AC consumption is 42% above expected baseline while occupancy is only 28%.",
    recommendedAction: "Reduce AC operation or adjust temperature setpoint to 24°C."
  },
  {
    id: "alert-3",
    severity: "MEDIUM",
    title: "Lights Active in Zero-Occupancy Zone",
    building: "Building 1 (Block A)",
    floor: "Floor 3",
    timestamp: "1 hour ago",
    description: "Seminar Hall 301 drawing 4.2 kW lighting load with 0 detected people.",
    recommendedAction: "Execute automated lighting cut-off command."
  },
  {
    id: "alert-4",
    severity: "LOW",
    title: "Power Factor Deviation",
    building: "Building 3 (Block C)",
    floor: "Floor 1",
    timestamp: "2 hours ago",
    description: "Power factor dipped to 0.89 due to heavy inductive elevator and pump load.",
    recommendedAction: "Activate APFC (Automatic Power Factor Correction) capacitor bank."
  }
];

export const INITIAL_COMPLAINTS = [
  {
    id: "cmp-101",
    building: "Building 2 (Block B)",
    floor: "Floor 2",
    room: "Lab 204",
    category: "AC",
    text: "AC is freezing cold all afternoon even when only 4 students are working. Nobody can change the thermostat.",
    urgency: "Medium",
    status: "Open",
    date: "2026-10-08 08:30"
  },
  {
    id: "cmp-102",
    building: "Building 1 (Block A)",
    floor: "Floor 3",
    room: "Seminar Hall 301",
    category: "Lighting",
    text: "Lights remain on the entire night after evening sessions. Please automate switch off.",
    urgency: "Low",
    status: "Open",
    date: "2026-10-07 19:40"
  },
  {
    id: "cmp-103",
    building: "Building 2 (Block B)",
    floor: "Floor 1",
    room: "Server Room B1",
    category: "Electrical",
    text: "AC not cooling properly in server room, warning sensor buzzes during 2 PM peak heat.",
    urgency: "Critical",
    status: "Pending Investigation",
    date: "2026-10-08 09:10"
  },
  {
    id: "cmp-104",
    building: "Building 3 (Block C)",
    floor: "Floor 2",
    room: "Auditorium",
    category: "AC",
    text: "AC was running full blast on Sunday when the auditorium was completely locked and empty.",
    urgency: "Medium",
    status: "Resolved",
    date: "2026-10-05 14:22"
  },
  {
    id: "cmp-105",
    building: "Building 2 (Block B)",
    floor: "Floor 2",
    room: "Design Studio",
    category: "AC",
    text: "AC not cooling in morning but freezing in afternoon. Irregular temperature swings.",
    urgency: "Medium",
    status: "Open",
    date: "2026-10-07 11:15"
  },
  {
    id: "cmp-106",
    building: "Building 1 (Block A)",
    floor: "Floor 1",
    room: "Lecture Hall 102",
    category: "Equipment",
    text: "Projector and amplifier rack humming loudly after hours, hot to touch.",
    urgency: "Medium",
    status: "Open",
    date: "2026-10-06 17:50"
  }
];
