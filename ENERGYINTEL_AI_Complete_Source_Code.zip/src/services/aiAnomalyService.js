// AI Wastage & Anomaly Detection Service
// Detects Core Campus Inefficiencies: College Working Hours (9 AM - 6 PM),
// Lunch Break Intermission (1 PM - 2 PM), and Continuous Staircase/Corridor Lighting Off-Hours

export const ANOMALY_CASES = {
  STAIRCASE_CORRIDOR_OFFHOURS: "case_staircase_corridor",
  LUNCH_BREAK_CLASSROOM_AC: "case_lunch_break_ac",
  LIGHTS_ZERO_OCCUPANCY: "case_1_lights_zero_occ",
  AC_LOW_OCCUPANCY: "case_2_ac_low_occ",
  AFTER_HOURS_CONSUMPTION: "case_3_after_hours",
  UNEXPECTED_ENERGY_SPIKE: "case_4_energy_spike",
  WEEKEND_ANOMALY: "case_5_weekend_anomaly"
};

export function evaluateWastageAndAnomalies({
  campusPowerKW = 82.4,
  occupancyMultiplier = 1.0,
  tempOffset = 0,
  activeAnomaly = false,
  activeWastageScenario = null,
  tariffINR = 8.0,
  selectedBuilding = "all",
  selectedFloor = "all"
}) {
  const anomalies = [];
  const wastageCases = [];

  // Primary Case A: Continuous Staircase & Corridor Lighting Outside Official Hours (Before 9 AM & After 6 PM)
  // College hours are 9:00 AM to 6:00 PM. During the 15 off-duty hours (18:00 - 09:00),
  // staircase and corridor lights across all 4 blocks remain illuminated without motion dimming.
  wastageCases.push({
    id: "case-corridor-stairs",
    caseType: ANOMALY_CASES.STAIRCASE_CORRIDOR_OFFHOURS,
    title: "Case 1: Continuous Staircase & Corridor Lighting (Before 9 AM & After 6 PM)",
    building: "All 4 Blocks (Blocks A, B, C, D)",
    floor: "Staircases & Corridors (All 12 Floors)",
    room: "Main Central Stairwells, Fire Escapes & Floor Corridors",
    severity: "HIGH",
    risk: "Continuous unnecessary base illumination across 15 off-duty hours (6 PM - 9 AM)",
    observedMetric: "Continuous Lighting: 0.45 kW draw (< 1 kW) during non-operational hours (18:00 - 09:00)",
    baselineExpected: "Expected Sensor-Dimmed Off-Hours Baseline: 0.15 kW (< 1 kW)",
    excessKWhPerDay: 6.75, // 0.45 kW × 15 off-hours = 6.75 kWh/day
    costWastedPerDay: Math.round(6.75 * tariffINR),
    description: "Staircase and corridor lighting fixtures remain ON before 9:00 AM and after 6:00 PM across all 4 buildings, consuming 0.45 kW continuously (< 1 kW individually) during Deep Standby, Transition, and Dispersal.",
    recommendedAction: "Deploy dual-technology PIR/microwave motion sensors & astronomical clock to dim corridor/staircase lighting to 15% (< 0.1 kW) outside 9 AM - 6 PM."
  });

  // Primary Case B: Lunch Break Classroom AC & Lighting Overrun (1:00 PM - 2:00 PM)
  // College lunch break is 1:00 PM to 2:00 PM. Occupancy plunges from 92% to 22%,
  // but split ACs and room lights in 18 lecture halls stay ON at full blast.
  const isLunchElevated = activeWastageScenario === ANOMALY_CASES.LUNCH_BREAK_CLASSROOM_AC || activeWastageScenario === ANOMALY_CASES.AC_LOW_OCCUPANCY || activeWastageScenario === "ALL";
  const lunchExcess = isLunchElevated ? 46.5 : 34.5;
  wastageCases.push({
    id: "case-lunch-overrun",
    caseType: ANOMALY_CASES.LUNCH_BREAK_CLASSROOM_AC,
    title: "Case 2: Lunch Break Classroom AC & Lighting Overrun (1:00 PM - 2:00 PM)",
    building: "Block A & Block B Complex",
    floor: "Floors 1-3 (Lecture Halls & Studios)",
    room: "Classrooms 101-304 & Microelectronics Lab",
    severity: isLunchElevated ? "CRITICAL" : "HIGH",
    risk: "Excessive cooling and illumination of vacant lecture halls during lunch intermission",
    observedMetric: `Lunch Hour Load: 76.5 kW | Occupancy: ${Math.round(22 * occupancyMultiplier)}% (Students in Canteen/Cafeteria)`,
    baselineExpected: "Expected Lunch Setback Baseline: 42.0 kW (26°C eco-float & lights standby)",
    excessKWhPerDay: lunchExcess,
    costWastedPerDay: Math.round(lunchExcess * tariffINR),
    description: "During the official 1:00 PM - 2:00 PM lunch intermission, classroom occupancy drops to 22%, yet 18 classrooms leave split AC units (18°C setpoint) and 20W LED fixtures running in empty rooms.",
    recommendedAction: "Enforce automated BMS lunch-break setback profile: automatically switch off lighting and setback AC thermostats to 26°C between 1:00 PM and 2:00 PM."
  });

  // Case 3: Post-College Dispersal Equipment Standby (Past 6:00 PM Official Closing)
  const isCase3 = activeWastageScenario === ANOMALY_CASES.AFTER_HOURS_CONSUMPTION || activeWastageScenario === "ALL";
  if (isCase3 || true) {
    wastageCases.push({
      id: "case-after-hours",
      caseType: ANOMALY_CASES.AFTER_HOURS_CONSUMPTION,
      title: "Case 3: Post-College Dispersal Equipment Standby (Post-6 PM)",
      building: "Block B",
      floor: "Floor 1 (Robotics & AI)",
      room: "AI Server & Rapid Prototyping Workshop",
      severity: "MEDIUM",
      risk: "Equipment and testing rigs left running unmonitored after official 6:00 PM departure",
      observedMetric: "Evening Post-6 PM Load: 0.92 kW (< 1 kW) (Expected baseload: 0.35 kW)",
      baselineExpected: "Nominal Dispersal Baseload: 0.35 kW (< 1 kW)",
      excessKWhPerDay: 2.8,
      costWastedPerDay: Math.round(2.8 * tariffINR),
      description: "Laser cutters, compute workstations, and 3D printers drawing idle vampire power after official 6:00 PM working hours (< 1 kW total).",
      recommendedAction: "Trigger BMS schedule to switch off non-essential smart breaker sub-circuits at 18:30."
    });
  }

  // Case 4: Unexpected Energy Spike (Critical Anomaly Spike Demo)
  if (activeAnomaly || activeWastageScenario === ANOMALY_CASES.UNEXPECTED_ENERGY_SPIKE) {
    anomalies.push({
      id: "spike-1",
      caseType: ANOMALY_CASES.UNEXPECTED_ENERGY_SPIKE,
      title: "Case 4: Unexpected Chiller Compressor Spike",
      building: "Block B",
      floor: "Floor 2",
      severity: "CRITICAL",
      normalBaselineKW: 82.4,
      anomalyMeasuredKW: 128.4,
      percentageIncrease: 55.8,
      timestamp: "Detected Just Now",
      risk: "Abnormal equipment behavior or impending compressor locked rotor failure",
      description: "Sudden +56% jump from 82.4 kW to 128.4 kW during afternoon hours. Chiller compressor cycling erratically.",
      recommendedAction: "Immediate dispatch: Inspect Chiller Loop B2, check phase balance, and isolate faulted unit."
    });
  }

  // Case 5: Weekend Idle Inefficiency (Campus Closed)
  const isCase5 = activeWastageScenario === ANOMALY_CASES.WEEKEND_ANOMALY || activeWastageScenario === "ALL";
  if (isCase5) {
    wastageCases.push({
      id: "case-5",
      caseType: ANOMALY_CASES.WEEKEND_ANOMALY,
      title: "Case 5: Weekend Idle Inefficiency (Campus Closed)",
      building: "Block C",
      floor: "Floor 2 (Auditorium)",
      room: "Central Auditorium Air Handling Units",
      severity: "MEDIUM",
      risk: "Unexpected consumption during low-activity weekend period",
      observedMetric: "Weekend Load: 12.2 kW | Campus Activity: Campus Closed",
      baselineExpected: "Weekend Baseline: 1.1 kW",
      excessKWhPerDay: 18.0,
      costWastedPerDay: Math.round(18.0 * tariffINR),
      description: "Air handling unit scheduled run flags not cleared after Friday university symposium.",
      recommendedAction: "Enforce digital event calendar synchronization to lock AHU fans during non-event days."
    });
  }

  // Calculate totals
  const totalWastageKWhPerDay = wastageCases.reduce((sum, c) => sum + c.excessKWhPerDay, 0);
  const totalWastedCostINR = Math.round(totalWastageKWhPerDay * tariffINR);

  return {
    anomalies,
    wastageCases,
    totalWastageKWhPerDay: Number(totalWastageKWhPerDay.toFixed(1)),
    totalWastedCostINR,
    potentialCO2SavingsKg: Number((totalWastageKWhPerDay * 0.82).toFixed(1))
  };
}
