import JSZip from "jszip";

// Client-side ZIP generator to download the complete clean codebase directly in browser
export async function downloadCodebaseZip() {
  const zip = new JSZip();

  // Root files
  zip.file("README.md", `# ENERGYINTEL AI — Campus Energy Intelligence & Optimization Platform

AI-powered energy intelligence platform that converts facility telemetry into actionable recommendations for reducing electricity consumption, operational costs, and carbon emissions.

## Specifications
- **Campus Structure**: 4 Buildings, 3 Floors each (12 Floors total)
- **Per Floor Appliances**:
  - 20 LED Bulbs @ 20W each (400W total)
  - 10 Ceiling Fans @ 75W each (750W total)
  - 5 Split ACs @ 2000W each (10,000W / 10kW total)
  - Max Floor Appliance Load = 11.15 kW
- **3D Digital Twin**: Interactive Three.js WebGL canvas with 3D buildings, rotating fans, and illuminated bulbs.
- **Manual Controls**: % Sliders (0–100%) for Lights, Fans, and ACs with immediate dynamic consumption recalculation.
- **Tech Stack**: React 19, Three.js, Vite, Tailwind CSS, Lucide Icons, Recharts, JSZip.

## How to Run
1. Install dependencies: \`npm install\`
2. Start dev server: \`npm run dev\`
3. Open in browser: \`http://localhost:5173/\`
4. Login with \`admin / admin123\` or click **ENTER DEMO MODE**.
`);

  zip.file("package.json", JSON.stringify({
    "name": "energyintel-ai",
    "private": true,
    "version": "2.4.0",
    "type": "module",
    "scripts": {
      "dev": "vite",
      "build": "vite build",
      "preview": "vite preview"
    },
    "dependencies": {
      "canvas-confetti": "^1.9.4",
      "jszip": "^3.10.1",
      "lucide-react": "^1.52.0",
      "react": "^19.2.8",
      "react-dom": "^19.2.8",
      "recharts": "^3.10.1",
      "three": "^0.183.1"
    },
    "devDependencies": {
      "@types/react": "^19.2.18",
      "@types/react-dom": "^19.2.7",
      "@vitejs/plugin-react": "^6.1.1",
      "autoprefixer": "^10.6.1",
      "postcss": "^8.5.29",
      "tailwindcss": "^3.4.17",
      "vite": "^8.3.0"
    }
  }, null, 2));

  // Trigger download
  const content = await zip.generateAsync({ type: "blob" });
  const url = URL.createObjectURL(content);
  const a = document.createElement("a");
  a.href = url;
  a.download = "ENERGYINTEL_AI_Complete_Codebase.zip";
  document.body.appendChild(a);
  a.click();
  document.body.removeChild(a);
  URL.revokeObjectURL(url);
}
