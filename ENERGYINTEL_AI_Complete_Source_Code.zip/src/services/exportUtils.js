// Export utilities for CSV & 1-Hour Second-by-Second High-Resolution Telemetry Simulation
// Covers all 4 Buildings (Block A, Block B, Block C, Block D) × 3 Floors (12 Floors total)

export function exportToCSV(filename = "trident_campus_energy_data.csv", data = []) {
  if (!data || data.length === 0) {
    alert("No data available to export.");
    return;
  }

  const headers = Object.keys(data[0]);
  const csvRows = [];
  csvRows.push(headers.join(","));

  data.forEach(row => {
    const values = headers.map(header => {
      const val = row[header];
      if (val === null || val === undefined) return "";
      const escaped = String(val).replace(/"/g, '""');
      return `"${escaped}"`;
    });
    csvRows.push(values.join(","));
  });

  const csvString = "\uFEFF" + csvRows.join("\r\n");
  const blob = new Blob([csvString], { type: "text/csv;charset=utf-8;" });
  const url = URL.createObjectURL(blob);
  const link = document.createElement("a");
  link.setAttribute("href", url);
  link.setAttribute("download", filename);
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
  URL.revokeObjectURL(url);
}

// Native Microsoft Excel (.xls) exporter with styled tables
export function exportToExcel(filename = "trident_campus_1hour_simulation_telemetry.xls", data = []) {
  if (!data || data.length === 0) {
    alert("No data available to export.");
    return;
  }

  const headers = Object.keys(data[0]);
  let xml = '<html xmlns:o="urn:schemas-microsoft-com:office:office" xmlns:x="urn:schemas-microsoft-com:office:excel" xmlns="http://www.w3.org/TR/REC-html40">';
  xml += '<head><meta charset="utf-8"><!--[if gte mso 9]><xml><x:ExcelWorkbook><x:ExcelWorksheets><x:ExcelWorksheet><x:Name>1-Hour 1Hz Simulation Telemetry</x:Name><x:WorksheetOptions><x:DisplayGridlines/></x:WorksheetOptions></x:ExcelWorksheet></x:ExcelWorksheets></x:ExcelWorkbook></xml><![endif]--></head><body>';
  xml += '<table border="1"><thead><tr style="background-color:#0284c7;color:#ffffff;font-weight:bold;">';
  headers.forEach(h => {
    xml += `<th style="padding:6px;background-color:#0284c7;color:#ffffff;font-weight:bold;">${h}</th>`;
  });
  xml += '</tr></thead><tbody>';

  data.forEach((row, i) => {
    const bg = i % 2 === 0 ? "#f8fafc" : "#ffffff";
    xml += `<tr style="background-color:${bg};">`;
    headers.forEach(h => {
      const val = row[h] !== null && row[h] !== undefined ? row[h] : "";
      xml += `<td style="padding:4px;">${val}</td>`;
    });
    xml += '</tr>';
  });

  xml += '</tbody></table></body></html>';

  const blob = new Blob([xml], { type: "application/vnd.ms-excel;charset=utf-8;" });
  const url = URL.createObjectURL(blob);
  const link = document.createElement("a");
  link.setAttribute("href", url);
  link.setAttribute("download", filename);
  document.body.appendChild(link);
  link.click();
  document.body.removeChild(link);
  URL.revokeObjectURL(url);
}

// Export 1-Hour Second-by-Second High-Resolution Telemetry Dataset (3,600 Seconds)
// Exactly reflects 4 buildings, 3 floors each (12 floors), 20 bulbs (20W), 10 fans (75W), 5 ACs (2000W)
export function export1HourSecondTelemetry(format = "csv") {
  const records = [];
  const buildings = [
    { name: "Building 1 — Block A (Academic)", baseOcc: 70 },
    { name: "Building 2 — Block B (Engineering Labs)", baseOcc: 60 },
    { name: "Building 3 — Block C (Library & Audit)", baseOcc: 50 },
    { name: "Building 4 — Block D (Research Hub)", baseOcc: 55 }
  ];
  const floors = ["Floor 1", "Floor 2", "Floor 3"];

  const startTime = new Date();
  startTime.setMinutes(0, 0, 0); // Start of simulation hour

  // Generate 3600 seconds of simulation
  let cumulativeEnergyKWh = 0;

  for (let sec = 0; sec < 3600; sec++) {
    const timestampSec = new Date(startTime.getTime() + sec * 1000)
      .toTimeString()
      .split(" ")[0]; // HH:MM:SS

    // Subtle sinusoidal micro-fluctuation per second
    const secCycle = Math.sin(sec * 0.1) * 0.4;
    const voltage = Number((231.2 + Math.sin(sec * 0.05) * 1.5).toFixed(1));
    const pf = Number((0.95 + Math.cos(sec * 0.02) * 0.02).toFixed(2));

    // Choose active building/floor sample or campus consolidated state for high performance
    const bldg = buildings[sec % 4];
    const floor = floors[(Math.floor(sec / 4)) % 3];

    // Appliance on-counts based on second
    const activeBulbs = Math.min(20, Math.max(8, Math.round(14 + Math.sin(sec * 0.03) * 4))); // 20W each
    const activeFans = Math.min(10, Math.max(3, Math.round(7 + Math.cos(sec * 0.04) * 2)));   // 75W each
    const activeACs = Math.min(5, Math.max(1, Math.round(3 + Math.sin(sec * 0.01) * 1.5)));    // 2000W each

    const bulbPowerW = activeBulbs * 20;
    const fanPowerW = activeFans * 75;
    const acPowerW = activeACs * 2000;
    const floorPowerW = bulbPowerW + fanPowerW + acPowerW;
    const floorPowerKW = Number((floorPowerW / 1000).toFixed(3));

    // Campus power scaling ~82 - 95 kW
    const campusPowerKW = Number((78.5 + (secCycle * 2) + (activeACs * 3.5)).toFixed(2));
    cumulativeEnergyKWh += Number((campusPowerKW / 3600).toFixed(4));
    const currentA = Number(((campusPowerKW * 1000) / (Math.sqrt(3) * 400 * pf)).toFixed(1));

    records.push({
      Second_Index: sec + 1,
      Timestamp: `2026-10-08 ${timestampSec}`,
      Elapsed_Simulation_Time: `${String(Math.floor(sec / 60)).padStart(2, "0")}:${String(sec % 60).padStart(2, "0")}`,
      Building_Sampled: bldg.name,
      Floor_Sampled: floor,
      Active_Bulbs_20W: activeBulbs,
      Active_Fans_75W: activeFans,
      Active_ACs_2000W: activeACs,
      Bulb_Load_Watts: bulbPowerW,
      Fan_Load_Watts: fanPowerW,
      AC_Load_Watts: acPowerW,
      Sample_Floor_Power_kW: floorPowerKW,
      Campus_Net_Power_kW: campusPowerKW,
      Voltage_RMS_V: voltage,
      Current_Amps: currentA,
      Power_Factor: pf,
      Frequency_Hz: 50.02,
      Ambient_Temp_C: Number((32.0 + Math.sin(sec * 0.002) * 1.5).toFixed(1)),
      Campus_Occupancy_Pct: Math.round(bldg.baseOcc + Math.sin(sec * 0.005) * 12),
      Hourly_Cumulative_kWh: Number(cumulativeEnergyKWh.toFixed(3)),
      Tariff_Cost_INR: Number((cumulativeEnergyKWh * 8.0).toFixed(2)),
      Scope2_CO2_kg: Number((cumulativeEnergyKWh * 0.82).toFixed(3)),
      Sampling_Interval: "1 Second (1 Hz High Resolution)"
    });
  }

  if (format === "excel") {
    exportToExcel("trident_campus_1hour_simulation_telemetry.xls", records);
  } else {
    exportToCSV("trident_campus_1hour_simulation_telemetry.csv", records);
  }
}

// 24-Hour standard summary export for 4 Buildings
export function exportSimulationDataset() {
  const records = [];
  const buildings = [
    "Building 1 — Block A (Academic)",
    "Building 2 — Block B (Engineering Labs)",
    "Building 3 — Block C (Library & Audit)",
    "Building 4 — Block D (Research Hub)"
  ];
  const floors = ["Floor 1", "Floor 2", "Floor 3"];

  for (let h = 0; h < 24; h++) {
    const timeStr = `${String(h).padStart(2, "0")}:00`;
    buildings.forEach(b => {
      floors.forEach(f => {
        const isOfficial = h >= 9 && h < 18;
        const isLunch = h === 13;
        let power;
        if (!isOfficial) {
          // Night Deep Standby, Transition, Dispersal & Baseload: < 1 kW campus total (~0.05 kW/floor)
          power = Number((0.05 + Math.random() * 0.015).toFixed(3));
        } else if (isLunch) {
          power = Number((baseKW * 0.42).toFixed(2));
        } else {
          power = Number((baseKW * (occ / 60) * (temp / 26)).toFixed(2));
        }
        const voltage = Number((230 + (Math.random() * 4 - 2)).toFixed(1));
        const current = Number(((power * 1000) / (voltage * 0.95)).toFixed(1));

        records.push({
          Timestamp: `2026-10-08 ${timeStr}`,
          Building: b,
          Floor: f,
          Power_kW: power,
          Energy_kWh: Number((power * 1.0).toFixed(2)),
          Voltage_V: voltage,
          Current_A: current,
          Power_Factor: 0.96,
          Temperature_C: temp,
          Occupancy_Pct: occ,
          AC_Status: occ > 20 ? "Active (24°C)" : "Eco-Idle",
          Bulb_Count_20W: 20,
          Fan_Count_75W: 10,
          AC_Count_2000W: 5,
          Data_Source: "Simulated 1-Second Sensor Engine"
        });
      });
    });
  }

  exportToCSV("trident_campus_4blocks_24h_telemetry.csv", records);
}
