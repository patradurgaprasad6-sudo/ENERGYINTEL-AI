// NLP / Facility Complaint Intelligence Service
// Analyzes user complaints, extracts keywords, detects recurring issues (e.g. "AC not cooling"), hotspots

export function analyzeComplaintsNLP(complaintsList = []) {
  const keywordFrequency = {};
  const categoryCounts = {};
  const buildingHotspots = {};
  const recurringIssues = [];

  const STOP_WORDS = new Set([
    "the", "is", "at", "which", "on", "and", "a", "an", "in", "to", "for", "with", "all", "please",
    "are", "was", "when", "only", "of", "but", "not", "too", "so", "can", "nobody", "after", "by"
  ]);

  complaintsList.forEach(c => {
    // Category distribution
    categoryCounts[c.category] = (categoryCounts[c.category] || 0) + 1;

    // Building hotspots
    const locKey = `${c.building} — ${c.floor}`;
    buildingHotspots[locKey] = (buildingHotspots[locKey] || 0) + 1;

    // Tokenize text for keyword frequency
    const words = c.text
      .toLowerCase()
      .replace(/[^a-z0-9 ]/g, "")
      .split(/\s+/);

    words.forEach(w => {
      if (w.length > 2 && !STOP_WORDS.has(w)) {
        keywordFrequency[w] = (keywordFrequency[w] || 0) + 1;
      }
    });

    // Check for specific recurring pattern phrases
    const lowerText = c.text.toLowerCase();
    if (lowerText.includes("ac not cooling") || lowerText.includes("freezing") || lowerText.includes("cold") || lowerText.includes("thermostat")) {
      recurringIssues.push({
        issueType: "Thermal Comfort & AC Inefficiency",
        snippet: c.text,
        location: `${c.building} (${c.floor}, ${c.room})`,
        severity: "HIGH",
        energyCorrelation: "Strongly correlated with Case 2 AC Wastage (Manual override setpoints)"
      });
    }

    if (lowerText.includes("lights remain on") || lowerText.includes("entire night") || lowerText.includes("empty")) {
      recurringIssues.push({
        issueType: "Unoccupied Space Lighting Wastage",
        snippet: c.text,
        location: `${c.building} (${c.floor}, ${c.room})`,
        severity: "MEDIUM",
        energyCorrelation: "Correlates with Case 1 Zero Occupancy Lighting"
      });
    }

    if (lowerText.includes("humming") || lowerText.includes("hot to touch") || lowerText.includes("warning sensor")) {
      recurringIssues.push({
        issueType: "Equipment Overheating / Electrical Anomaly",
        snippet: c.text,
        location: `${c.building} (${c.floor}, ${c.room})`,
        severity: "CRITICAL",
        energyCorrelation: "Correlates with Case 4 High Draw / Spike Risk"
      });
    }
  });

  // Top keywords sorted
  const sortedKeywords = Object.entries(keywordFrequency)
    .map(([word, count]) => ({ word, count }))
    .sort((a, b) => b.count - a.count)
    .slice(0, 12);

  // Top hotspot location
  const topHotspot = Object.entries(buildingHotspots).sort((a, b) => b[1] - a[1])[0] || ["Block B — Floor 2", 3];

  return {
    totalComplaints: complaintsList.length,
    openComplaints: complaintsList.filter(c => c.status !== "Resolved").length,
    resolvedComplaints: complaintsList.filter(c => c.status === "Resolved").length,
    categoryCounts,
    topKeywords: sortedKeywords,
    topHotspot: {
      location: topHotspot[0],
      count: topHotspot[1]
    },
    recurringIssues
  };
}
