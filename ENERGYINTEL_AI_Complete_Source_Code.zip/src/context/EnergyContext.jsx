import React, { createContext, useContext, useState, useEffect, useMemo, useCallback } from "react";
import {
  CAMPUS_CONFIG,
  APPLIANCE_SPECS,
  createInitialCampusFloorStates,
  calculateFloorConsumption,
  generateHourlyEnergyProfile,
  generateWeeklyData,
  generateMonthlyData,
  INITIAL_RECOMMENDATIONS,
  INITIAL_ALERTS,
  INITIAL_COMPLAINTS
} from "../services/mockDataGenerator";
import { calculateEnergyPredictions } from "../services/aiPredictionService";
import { evaluateWastageAndAnomalies, ANOMALY_CASES } from "../services/aiAnomalyService";
import { analyzeComplaintsNLP } from "../services/nlpComplaintService";
import { export1HourSecondTelemetry } from "../services/exportUtils";

const EnergyContext = createContext();

export function EnergyProvider({ children }) {
  // Navigation / Selection State (4 Buildings, 3 Floors each)
  const [selectedBuilding, setSelectedBuilding] = useState("bldg-1");
  const [selectedFloor, setSelectedFloor] = useState("b1-f1");
  const [tariffINR, setTariffINR] = useState(8.0); // Editable electricity tariff (₹/kWh)

  // Floor-Wise Appliance States (4 Buildings × 3 Floors = 12 Floors)
  // Per floor: 20 Bulbs (20W), 10 Fans (75W), 5 ACs (2000W)
  const [floorApplianceStates, setFloorApplianceStates] = useState(createInitialCampusFloorStates);

  // Simulation Controls State
  const [isSimulating, setIsSimulating] = useState(true);
  const [occupancyMultiplier, setOccupancyMultiplier] = useState(1.0);
  const [tempOffset, setTempOffset] = useState(0); // °C deviation from 30°C
  const [isPeakLoadActive, setIsPeakLoadActive] = useState(false);
  const [activeAnomaly, setActiveAnomaly] = useState(false);
  const [activeWastageScenario, setActiveWastageScenario] = useState(null);
  const [tick, setTick] = useState(0);
  const [lastUpdated, setLastUpdated] = useState(new Date());

  // 1-Hour Simulation Telemetry Tracking State (Refreshes every 1 second / 1 Hz)
  const [elapsedSimulationSeconds, setElapsedSimulationSeconds] = useState(0);
  const [hasAutoDownloaded1Hr, setHasAutoDownloaded1Hr] = useState(false);
  const [oneHourCompletedNotification, setOneHourCompletedNotification] = useState(false);

  // Collections state
  const [recommendations, setRecommendations] = useState(INITIAL_RECOMMENDATIONS);
  const [alerts, setAlerts] = useState(INITIAL_ALERTS);
  const [complaints, setComplaints] = useState(INITIAL_COMPLAINTS);
  const [appliedRecommendations, setAppliedRecommendations] = useState(new Set());
  const [customCsvDataset, setCustomCsvDataset] = useState(null);

  // RUN AI DEMO Guided Modal State
  const [isAiDemoModalOpen, setIsAiDemoModalOpen] = useState(false);
  const [aiDemoCurrentStep, setAiDemoCurrentStep] = useState(1);

  // Simulation Timer Hook: Refreshes telemetry EVERY 1 SECOND (1000ms / 1 Hz)
  // Automatically triggers 1-hour dataset download upon reaching 3600 seconds (1 Hour)!
  useEffect(() => {
    if (!isSimulating) return;

    const interval = setInterval(() => {
      setTick(prev => prev + 1);
      setLastUpdated(new Date());

      setElapsedSimulationSeconds(prevSec => {
        const nextSec = prevSec + 1;
        // Automated trigger: When 1 hour (3600 seconds) of simulation completes, auto-download dataset!
        if (nextSec >= 3600 && !hasAutoDownloaded1Hr) {
          setHasAutoDownloaded1Hr(true);
          setOneHourCompletedNotification(true);
          try {
            export1HourSecondTelemetry("csv");
          } catch (e) {
            console.error("Auto-download error", e);
          }
        }
        return nextSec;
      });
    }, 1000);

    return () => clearInterval(interval);
  }, [isSimulating, hasAutoDownloaded1Hr]);

  // When selected building changes, update selected floor to valid floor of that building
  useEffect(() => {
    if (selectedBuilding === "all") {
      setSelectedFloor("all");
    } else {
      const bObj = CAMPUS_CONFIG.buildings.find(b => b.id === selectedBuilding);
      if (bObj) {
        const floorBelongs = bObj.floors.some(f => f.id === selectedFloor);
        if (!floorBelongs && bObj.floors.length > 0) {
          setSelectedFloor(bObj.floors[0].id);
        }
      }
    }
  }, [selectedBuilding, selectedFloor]);

  // Floor Appliance Control Functions
  const updateFloorBulbsPct = useCallback((floorId, pct) => {
    setFloorApplianceStates(prev => {
      const current = prev[floorId];
      if (!current) return prev;
      const count = Math.round((pct / 100) * APPLIANCE_SPECS.bulbs.count);
      const bulbs = Array(APPLIANCE_SPECS.bulbs.count).fill(false).map((_, i) => i < count);
      return {
        ...prev,
        [floorId]: {
          ...current,
          bulbsPct: pct,
          activeBulbsCount: count,
          bulbs
        }
      };
    });
  }, []);

  const updateFloorFansPct = useCallback((floorId, pct) => {
    setFloorApplianceStates(prev => {
      const current = prev[floorId];
      if (!current) return prev;
      const count = Math.round((pct / 100) * APPLIANCE_SPECS.fans.count);
      const fans = Array(APPLIANCE_SPECS.fans.count).fill(false).map((_, i) => i < count);
      return {
        ...prev,
        [floorId]: {
          ...current,
          fansPct: pct,
          activeFansCount: count,
          fans
        }
      };
    });
  }, []);

  const updateFloorAcsPct = useCallback((floorId, pct) => {
    setFloorApplianceStates(prev => {
      const current = prev[floorId];
      if (!current) return prev;
      const count = Math.round((pct / 100) * APPLIANCE_SPECS.acs.count);
      const acs = Array(APPLIANCE_SPECS.acs.count).fill(false).map((_, i) => i < count);
      return {
        ...prev,
        [floorId]: {
          ...current,
          acsPct: pct,
          activeAcsCount: count,
          acs
        }
      };
    });
  }, []);

  // Toggle individual appliance units
  const toggleSingleBulb = useCallback((floorId, index) => {
    setFloorApplianceStates(prev => {
      const current = prev[floorId];
      if (!current) return prev;
      const bulbs = [...current.bulbs];
      bulbs[index] = !bulbs[index];
      const count = bulbs.filter(Boolean).length;
      const pct = Math.round((count / APPLIANCE_SPECS.bulbs.count) * 100);
      return {
        ...prev,
        [floorId]: {
          ...current,
          bulbs,
          activeBulbsCount: count,
          bulbsPct: pct
        }
      };
    });
  }, []);

  const toggleSingleFan = useCallback((floorId, index) => {
    setFloorApplianceStates(prev => {
      const current = prev[floorId];
      if (!current) return prev;
      const fans = [...current.fans];
      fans[index] = !fans[index];
      const count = fans.filter(Boolean).length;
      const pct = Math.round((count / APPLIANCE_SPECS.fans.count) * 100);
      return {
        ...prev,
        [floorId]: {
          ...current,
          fans,
          activeFansCount: count,
          fansPct: pct
        }
      };
    });
  }, []);

  const toggleSingleAc = useCallback((floorId, index) => {
    setFloorApplianceStates(prev => {
      const current = prev[floorId];
      if (!current) return prev;
      const acs = [...current.acs];
      acs[index] = !acs[index];
      const count = acs.filter(Boolean).length;
      const pct = Math.round((count / APPLIANCE_SPECS.acs.count) * 100);
      return {
        ...prev,
        [floorId]: {
          ...current,
          acs,
          activeAcsCount: count,
          acsPct: pct
        }
      };
    });
  }, []);

  // Bulk Apply to All Floors in building or campus
  const setAllFloorsPreset = useCallback((bulbsPct, fansPct, acsPct) => {
    setFloorApplianceStates(prev => {
      const updated = { ...prev };
      Object.keys(updated).forEach(fId => {
        const bCount = Math.round((bulbsPct / 100) * APPLIANCE_SPECS.bulbs.count);
        const fCount = Math.round((fansPct / 100) * APPLIANCE_SPECS.fans.count);
        const aCount = Math.round((acsPct / 100) * APPLIANCE_SPECS.acs.count);
        updated[fId] = {
          ...updated[fId],
          bulbsPct,
          fansPct,
          acsPct,
          activeBulbsCount: bCount,
          activeFansCount: fCount,
          activeAcsCount: aCount,
          bulbs: Array(APPLIANCE_SPECS.bulbs.count).fill(false).map((_, i) => i < bCount),
          fans: Array(APPLIANCE_SPECS.fans.count).fill(false).map((_, i) => i < fCount),
          acs: Array(APPLIANCE_SPECS.acs.count).fill(false).map((_, i) => i < aCount)
        };
      });
      return updated;
    });
  }, []);

  // Compute Power Sums directly from real-time floor states
  // Floor power (W) = (bulbs * 20W) + (fans * 75W) + (acs * 2000W)
  const campusTotals = useMemo(() => {
    let totalCampusW = 0;
    const buildingPowers = {};

    CAMPUS_CONFIG.buildings.forEach(b => {
      let bW = 0;
      b.floors.forEach(f => {
        const fState = floorApplianceStates[f.id];
        const fUsage = calculateFloorConsumption(fState);
        bW += fUsage.totalW;
      });
      buildingPowers[b.id] = {
        totalW: bW,
        totalKW: Number((bW / 1000).toFixed(2))
      };
      totalCampusW += bW;
    });

    // Add baseline facility load (pumps, elevators, servers, security lighting) ~ 12 kW
    const facilityBaseloadW = 12000;
    const totalWithBaseloadW = totalCampusW + facilityBaseloadW;
    const totalCampusKW = Number((totalWithBaseloadW / 1000).toFixed(2));

    return {
      totalCampusW: totalWithBaseloadW,
      totalCampusKW,
      buildingPowers
    };
  }, [floorApplianceStates]);

  // Current active view power (Floor or Building or Campus)
  const currentViewPower = useMemo(() => {
    if (selectedFloor !== "all") {
      const fState = floorApplianceStates[selectedFloor];
      return calculateFloorConsumption(fState);
    }
    if (selectedBuilding !== "all") {
      return campusTotals.buildingPowers[selectedBuilding] || { totalW: 0, totalKW: 0 };
    }
    return {
      totalW: campusTotals.totalCampusW,
      totalKW: campusTotals.totalCampusKW
    };
  }, [selectedFloor, selectedBuilding, floorApplianceStates, campusTotals]);

  // Primary Power Metric (kW)
  const currentPowerKW = useMemo(() => {
    if (activeAnomaly) return 128.4;
    if (isPeakLoadActive) return 118.0;
    return campusTotals.totalCampusKW;
  }, [activeAnomaly, isPeakLoadActive, campusTotals.totalCampusKW]);

  // Electrical Parameters
  const electricalParams = useMemo(() => {
    const voltage = Number((231.2 + Math.sin(tick * 0.5) * 1.4).toFixed(1));
    const pf = Number((0.95 + Math.cos(tick * 0.3) * 0.02).toFixed(2));
    const current = Number(((currentPowerKW * 1000) / (Math.sqrt(3) * (voltage * 1.732) * pf)).toFixed(1));
    const frequency = Number((50.0 + Math.sin(tick * 0.2) * 0.08).toFixed(2));

    return {
      voltage,
      current: Math.max(15, current),
      powerFactor: Math.min(0.99, Math.max(0.88, pf)),
      frequency
    };
  }, [tick, currentPowerKW]);

  // Environmental Parameters
  const environmentalParams = useMemo(() => {
    const ambientTemp = Number((32.0 + tempOffset + Math.sin(tick * 0.2) * 0.6).toFixed(1));
    const totalOccupancyHeadcount = Math.round(
      (CAMPUS_CONFIG.totalStudents + CAMPUS_CONFIG.totalFacultyStaff) * 0.72 * occupancyMultiplier
    );
    const occupancyPct = Math.min(100, Math.round(72 * occupancyMultiplier));

    return {
      ambientTemp,
      totalOccupancyHeadcount,
      occupancyPct
    };
  }, [tick, tempOffset, occupancyMultiplier]);

  // Cumulative today energy (kWh)
  const todayEnergyKWh = useMemo(() => {
    let energy = 1284;
    energy += Math.round((currentPowerKW - 82.4) * 4);
    energy += Math.round(tick * 0.15);
    return Math.max(500, energy);
  }, [currentPowerKW, tick]);

  // Wastage evaluation
  const wastageEvaluation = useMemo(() => {
    return evaluateWastageAndAnomalies({
      campusPowerKW: currentPowerKW,
      occupancyMultiplier,
      tempOffset,
      activeAnomaly,
      activeWastageScenario,
      tariffINR,
      selectedBuilding,
      selectedFloor
    });
  }, [
    currentPowerKW,
    occupancyMultiplier,
    tempOffset,
    activeAnomaly,
    activeWastageScenario,
    tariffINR,
    selectedBuilding,
    selectedFloor
  ]);

  const potentialWastageKWh = useMemo(() => {
    let wastage = 186;
    if (activeAnomaly) wastage += 95;
    if (activeWastageScenario) wastage += 48;
    if (appliedRecommendations.size > 0) {
      wastage = Math.max(15, wastage - appliedRecommendations.size * 34);
    }
    return wastage;
  }, [activeAnomaly, activeWastageScenario, appliedRecommendations]);

  const energyEfficiencyPct = useMemo(() => {
    const raw = Math.round(((todayEnergyKWh - potentialWastageKWh) / todayEnergyKWh) * 100);
    return Math.min(98, Math.max(65, raw || 87));
  }, [todayEnergyKWh, potentialWastageKWh]);

  const predictions = useMemo(() => {
    return calculateEnergyPredictions({
      currentPowerKW,
      occupancyMultiplier,
      tempOffset,
      tariffINR
    });
  }, [currentPowerKW, occupancyMultiplier, tempOffset, tariffINR]);

  const estimatedCostINR = useMemo(() => {
    return Math.round(todayEnergyKWh * tariffINR);
  }, [todayEnergyKWh, tariffINR]);

  const potentialSavingsINR = useMemo(() => {
    return Math.round(potentialWastageKWh * tariffINR);
  }, [potentialWastageKWh, tariffINR]);

  const carbonEmissionKg = useMemo(() => {
    return Number((todayEnergyKWh * CAMPUS_CONFIG.co2Factor).toFixed(1));
  }, [todayEnergyKWh]);

  const carbonSavingsKg = useMemo(() => {
    return Number((potentialWastageKWh * CAMPUS_CONFIG.co2Factor).toFixed(1));
  }, [potentialWastageKWh]);

  const sustainabilityScore = useMemo(() => {
    const f1 = (energyEfficiencyPct / 100) * 30;
    const wastageRatio = Math.max(0, 1 - (potentialWastageKWh / todayEnergyKWh));
    const f2 = wastageRatio * 20;
    const f3 = (isPeakLoadActive ? 0.6 : 0.95) * 15;
    const f4 = (electricalParams.powerFactor / 1.0) * 15;
    const f5 = (activeAnomaly ? 0.3 : 1.0) * 10;
    const f6 = (0.7 + Math.min(0.3, appliedRecommendations.size * 0.1)) * 10;
    return Math.min(100, Math.max(40, Math.round(f1 + f2 + f3 + f4 + f5 + f6)));
  }, [
    energyEfficiencyPct,
    potentialWastageKWh,
    todayEnergyKWh,
    isPeakLoadActive,
    electricalParams.powerFactor,
    activeAnomaly,
    appliedRecommendations
  ]);

  const hourlyData = useMemo(() => {
    return generateHourlyEnergyProfile("2026-10-08", {
      includeSpike: activeAnomaly,
      includeWastage: Boolean(activeWastageScenario)
    });
  }, [activeAnomaly, activeWastageScenario]);

  const weeklyData = useMemo(() => generateWeeklyData(), []);
  const monthlyData = useMemo(() => generateMonthlyData(), []);
  const complaintAnalytics = useMemo(() => analyzeComplaintsNLP(complaints), [complaints]);

  // Simulation Controls
  const startSimulation = useCallback(() => setIsSimulating(true), []);
  const pauseSimulation = useCallback(() => setIsSimulating(false), []);
  const resetSimulation = useCallback(() => {
    setIsSimulating(true);
    setOccupancyMultiplier(1.0);
    setTempOffset(0);
    setIsPeakLoadActive(false);
    setActiveAnomaly(false);
    setActiveWastageScenario(null);
    setFloorApplianceStates(createInitialCampusFloorStates());
    setElapsedSimulationSeconds(0);
    setHasAutoDownloaded1Hr(false);
    setOneHourCompletedNotification(false);
  }, []);

  // 1-Hour Telemetry Helpers
  const triggerFastForward1Hour = useCallback((format = "csv") => {
    setElapsedSimulationSeconds(3600);
    setHasAutoDownloaded1Hr(true);
    setOneHourCompletedNotification(true);
    export1HourSecondTelemetry(format);
  }, []);

  const download1HourDataset = useCallback((format = "csv") => {
    export1HourSecondTelemetry(format);
  }, []);

  const resetOneHourTimer = useCallback(() => {
    setElapsedSimulationSeconds(0);
    setHasAutoDownloaded1Hr(false);
    setOneHourCompletedNotification(false);
  }, []);

  const triggerIncreaseOccupancy = useCallback(() => {
    setOccupancyMultiplier(prev => (prev >= 1.5 ? 1.0 : Number((prev + 0.25).toFixed(2))));
  }, []);

  const triggerIncreaseTemperature = useCallback(() => {
    setTempOffset(prev => (prev >= 6 ? 0 : prev + 2));
  }, []);

  const triggerPeakLoad = useCallback(() => {
    setIsPeakLoadActive(prev => !prev);
  }, []);

  const triggerAnomaly = useCallback(() => {
    setActiveAnomaly(prev => !prev);
  }, []);

  const triggerWastageScenario = useCallback((scenarioKey) => {
    setActiveWastageScenario(prev => (prev === scenarioKey ? null : scenarioKey));
  }, []);

  const applyRecommendation = useCallback((recId) => {
    setAppliedRecommendations(prev => {
      const copy = new Set(prev);
      copy.add(recId);
      return copy;
    });
  }, []);

  const dismissAlert = useCallback((alertId) => {
    setAlerts(prev => prev.filter(a => a.id !== alertId));
  }, []);

  const addComplaint = useCallback((newCmp) => {
    setComplaints(prev => [
      {
        id: `cmp-${Date.now()}`,
        status: "Open",
        date: new Date().toISOString().replace("T", " ").substring(0, 16),
        ...newCmp
      },
      ...prev
    ]);
  }, []);

  const toggleComplaintStatus = useCallback((cmpId) => {
    setComplaints(prev =>
      prev.map(c =>
        c.id === cmpId ? { ...c, status: c.status === "Resolved" ? "Open" : "Resolved" } : c
      )
    );
  }, []);

  const startAiDemo = useCallback(() => {
    setIsAiDemoModalOpen(true);
    setAiDemoCurrentStep(1);
  }, []);

  const closeAiDemo = useCallback(() => {
    setIsAiDemoModalOpen(false);
  }, []);

  const value = {
    // Campus Configuration
    campusConfig: CAMPUS_CONFIG,
    applianceSpecs: APPLIANCE_SPECS,
    tariffINR,
    setTariffINR,

    // Hierarchy Selection
    selectedBuilding,
    setSelectedBuilding,
    selectedFloor,
    setSelectedFloor,

    // Floor-Wise Appliance Simulation State & Controls (4 Buildings × 3 Floors)
    floorApplianceStates,
    updateFloorBulbsPct,
    updateFloorFansPct,
    updateFloorAcsPct,
    toggleSingleBulb,
    toggleSingleFan,
    toggleSingleAc,
    setAllFloorsPreset,
    campusTotals,
    currentViewPower,

    // Real-Time Simulation Engine
    isSimulating,
    startSimulation,
    pauseSimulation,
    resetSimulation,
    occupancyMultiplier,
    triggerIncreaseOccupancy,
    tempOffset,
    triggerIncreaseTemperature,
    isPeakLoadActive,
    triggerPeakLoad,
    activeAnomaly,
    triggerAnomaly,
    activeWastageScenario,
    triggerWastageScenario,
    lastUpdated,

    // 1-Hour Second-by-Second Telemetry Simulation (1 Hz Refresh Rate)
    elapsedSimulationSeconds,
    hasAutoDownloaded1Hr,
    oneHourCompletedNotification,
    setOneHourCompletedNotification,
    triggerFastForward1Hour,
    download1HourDataset,
    resetOneHourTimer,

    // Core KPIs
    currentPowerKW,
    todayEnergyKWh,
    predictedTomorrowKWh: predictions.predictedTomorrowKWh,
    potentialWastageKWh,
    energyEfficiencyPct,
    estimatedCostINR,
    potentialSavingsINR,
    carbonEmissionKg,
    carbonSavingsKg,
    sustainabilityScore,

    // Sensor Streams
    electricalParams,
    environmentalParams,

    // Datasets
    predictions,
    wastageEvaluation,
    hourlyData,
    weeklyData,
    monthlyData,

    // Actions & Tickets
    alerts,
    dismissAlert,
    recommendations,
    appliedRecommendations,
    applyRecommendation,
    complaints,
    addComplaint,
    toggleComplaintStatus,
    complaintAnalytics,
    customCsvDataset,
    setCustomCsvDataset,

    // AI Demo
    isAiDemoModalOpen,
    aiDemoCurrentStep,
    setAiDemoCurrentStep,
    startAiDemo,
    closeAiDemo
  };

  return <EnergyContext.Provider value={value}>{children}</EnergyContext.Provider>;
}

export function useEnergy() {
  const context = useContext(EnergyContext);
  if (!context) {
    throw new Error("useEnergy must be used within an EnergyProvider");
  }
  return context;
}
